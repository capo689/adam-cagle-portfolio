# X5 — Operational Templates

> The canonical FINISHER artifact templates. When the method or a check says to use a template,
> use the matching section here verbatim rather than inventing a structure. Replace {{PLACEHOLDERS}}.

**Sections:** `ADR.md` · `ARCHITECTURE.md` · `INCIDENT-POSTMORTEM.md` · `README-template.md` · `RUNBOOK.md` · `SCORECARD.md` · `THREAT-MODEL.md` · `run-report.template.md` · `context.template.json` · `context.example.json` · `state.template.json` · `actions.template.json`

---

## section `ADR.md`

# ADR-{{NNN}}: {{TITLE}}

- **Date:** {{DATE}}
- **Status:** Proposed | Accepted | Superseded by ADR-___
- **Deciders:** {{NAMES}}

## Context

What forced a decision. Constraints, deadlines, what we knew and did not know.

## Decision

What we are doing. Present tense, specific.

## Alternatives considered

| Option | Why not |
|---|---|

## Consequences

**Good:**

**Bad / accepted costs:**

**What this makes harder later:**

## Reversal plan

How we undo this if it turns out wrong. What it would cost. What signal would tell us to.

## FINISHER impact

Which checks this affects, and how their scores should change.


---

## section `ARCHITECTURE.md`

# Architecture: {{PROJECT}}

Last updated: {{DATE}}

## 1. What this is

Two sentences. What it does and who uses it.

## 2. Stack

| Layer | Technology | Version | Hosted where |
|---|---|---|---|
| Frontend | | | |
| Backend | | | |
| Database | | | |
| Object storage | | | |
| Cache | | | |
| Queue / jobs | | | |
| Auth | | | |
| Payments | | | |
| Email / SMS | | | |
| AI providers | | | |
| Error tracking | | | |
| Analytics | | | |
| CI/CD | | | |

## 3. Request path

Browser → edge/CDN → app → auth → data. Numbered list or diagram. Include where auth happens and where anything is cached.

## 4. Data model

Entities, relationships, and — importantly — which tables carry ownership columns (`user_id`, `tenant_id`) and which have row-level security policies.

| Table | Owner column | RLS? | Holds personal data? | Retention |
|---|---|---|---|---|

## 5. Auth and permission model

Roles × resources × actions.

| Role | Resource | Create | Read | Update | Delete | Export |
|---|---|---|---|---|---|---|

Where each is enforced: middleware / data layer / database policy.

## 6. API map

| Method | Path | Public? | Authz rule | Rate limited | Notes |
|---|---|---|---|---|---|

## 7. Vendor map

| Vendor | Purpose | Data it receives | Account owner | If it is down | DPA? |
|---|---|---|---|---|---|

## 8. Background jobs and schedules

| Job | Trigger | What it touches | Idempotent? | On failure |
|---|---|---|---|---|

## 9. AI calls

| Feature | Provider | Model | Context sent | Tools available | Fallback | Est. cost |
|---|---|---|---|---|---|---|

For agentic features, note which of {untrusted input, sensitive data, external communication} each workflow holds.

## 10. Caching

| What | Where | Key includes identity? | TTL | Invalidated by |
|---|---|---|---|---|

## 11. Where money flows

Diagram or sequence: checkout → provider → webhook → entitlement.

## 12. Where personal data flows

Diagram: collection point → stores → third parties → deletion path.

## 13. Environments

| | Development | Staging | Production |
|---|---|---|---|
| URL | | | |
| Database | | | |
| Storage | | | |
| Payment mode | | | |
| Email | | | |

## 14. Known limitations

What is not handled, what breaks at scale, what was deliberately deferred and the trigger for revisiting it.


---

## section `INCIDENT-POSTMORTEM.md`

# Incident: {{TITLE}}

- **Date:** {{DATE}} · **Severity:** Sev _ · **Duration:** __ · **Author:** {{NAME}}

## Impact

Who was affected, how many, for how long, and what they experienced. Include revenue, data, and trust impact if any.

## Timeline

| Time (UTC) | Event |
|---|---|
| | First bad deploy / trigger |
| | First user impact |
| | First detection |
| | Escalated |
| | Mitigated |
| | Resolved |

## What happened

Plain narrative. No blame, no names attached to mistakes.

## Root cause

The technical cause, and the systemic reason it was possible.

## Why detection was slow

The most valuable question. What signal existed and was not alerted on? What signal did not exist?

## Why recovery was slow

Was the rollback path known? Rehearsed? Did the runbook cover it? Did the right person get reached?

## What went well

## Actions

| # | Action | Owner | Due | FINISHER check |
|---|---|---|---|---|
| 1 | | | | |

Every action should map to a check whose score will change. An action that does not change a score is a promise, not a fix.


---

## section `README-template.md`

# {{PROJECT}}

{{One or two sentences: what it does and who uses it.}}

## Stack

- Frontend:
- Backend:
- Database:
- Hosting:
- Auth:
- Payments:

## Prerequisites

- Node / Python / etc. version:
- Database:
- Other services:

## Local setup

```bash
git clone {{REPO}}
cd {{DIR}}
cp .env.example .env      # then fill in values — see below
npm ci
npm run db:migrate
npm run db:seed
npm run dev
```

## Environment variables

Names and purposes only. **Never commit values.**

| Name | Required | Purpose | Where to get it |
|---|---|---|---|
| `DATABASE_URL` | yes | Postgres connection | provider console |
| `SESSION_SECRET` | yes | Session signing (32+ random bytes) | generate locally |
| | | | |

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | |
| `npm test` | |
| `npm run test:e2e` | |
| `npm run lint` | |
| `npm run typecheck` | |
| `npm run build` | |
| `npm run db:migrate` | |

## Deploying

```
# exact steps
```

## Rolling back

```
# exact steps
```
What rollback does not undo: ____

## Documentation

- Architecture: `docs/ARCHITECTURE.md`
- Runbook: `docs/RUNBOOK.md`
- Decisions: `docs/adr/`
- Production readiness score: `finisher/SCORE.md`

## Known limitations

-


---

## section `RUNBOOK.md`

# Runbook: {{PROJECT}}

Last reviewed: {{DATE}} · Owner: {{NAME}}

> Written calm, used panicked. Every step is a command you can paste, not a description of a command.

## Quick reference

| | |
|---|---|
| Production URL | |
| Status page | |
| Error tracking | |
| Logs | |
| Metrics dashboard | |
| Hosting console | |
| Database console | |
| Payment provider dashboard | |
| On-call / who to contact | |
| Escalation (2nd) | |
| Lawyer (data incidents) | |

## Severity

- **Sev 1** — total outage, data loss, or active security incident. Drop everything. Notify customers.
- **Sev 2** — major feature broken or significant degradation. Same day.
- **Sev 3** — minor issue with a workaround. Next business day.

---

## App is down

1. Confirm externally: `curl -sS -o /dev/null -w "%{http_code} %{time_total}s\n" https://{{HOST}}/health`
2. Check hosting status page and your provider's incident feed
3. Check the last deploy — what shipped and when?
4. Check error tracking for a spike and its first-seen timestamp
5. Check database connectivity and connection count
6. If the last deploy correlates: **roll back** (below)
7. If not: check third-party status, then logs

## Roll back

```
# exact command here
```
Elapsed time when last rehearsed: ____ · Last rehearsed: ____

**What rollback does NOT undo:** migrations, sent emails, external side effects, webhook deliveries, cache state.

## Database down or unreachable

1. Provider status page
2. `SELECT count(*), state FROM pg_stat_activity GROUP BY state;` — connection exhaustion?
3. Check pooler health
4. Check for a long-running lock: `SELECT * FROM pg_locks WHERE NOT granted;`
5. Failover procedure: ____

## Restore from backup

1. Latest backup: where, how to list
2. Restore command: ____
3. Verification queries: ____
4. Expected duration (measured): ____
5. Cutover steps: ____

## Payment webhooks failing

1. Provider dashboard → webhook delivery log
2. Check signature verification errors in our logs
3. Replay failed events: ____
4. Reconcile entitlements: ____

## Third-party provider outage

| Provider | Critical? | Degraded behavior | How to enable |
|---|---|---|---|

## Runaway spend

1. Which provider — check the cost dashboard
2. Kill switch: ____
3. Identify the source: query cost logs grouped by user and feature
4. Block the abusing account: ____
5. Lower the global cap: ____

## Secret leaked

1. Identify which key and where it appeared
2. **Rotate at the provider first**, before anything else
3. Deploy the new value
4. Revoke the old value
5. Check provider logs for use during the exposure window
6. Record in the rotation log
7. Assess whether data was accessed → data exposure procedure

## Suspected data exposure

1. **Contain** — revoke credentials, disable the path, block the actor
2. **Preserve** — snapshot logs before rotation deletes them
3. **Assess** — what data, whose, how much, over what period, accessed or exfiltrated
4. **Decide** — {{NAME}} decides on notification; contact {{LAWYER}}
5. **Notify** — regulators and customers per obligation; clocks start at awareness
6. **Remediate and post-mortem**

## Queue backed up

1. Check depth and oldest message age
2. Check worker health and error rate
3. Scale workers: ____
4. Drain safely (do not drop): ____

---

## Post-incident

1. Timeline with timestamps
2. What made **detection** slow?
3. What made **recovery** slow?
4. What would have prevented it? What would have contained it?
5. Actions with owners and dates
6. Update the FINISHER state file — a post-mortem that does not change a check score did not change anything


---

## section `SCORECARD.md`

# FINISHER Scorecard — {{PROJECT}}

> Generated by `finisher_score.py commit` into `finisher/SCORE.md`.
> This file documents the shape and how to read it.

**FINISHER Score: __ / 100 — {{BAND}}**

- Uncapped weighted score: __
- Capped at __ because: ____
- Assessment coverage: __% (__/__ applicable checks assessed)
- Open blockers: P0 __ | P1 __ | P2 __

## How to read this

- **The capped composite is what you may claim.** Any open P0 caps it at 39, any open P1 at 69, any open P2 at 89.
- **The uncapped score is how much work is genuinely done.** A large gap between the two means real progress that has not yet unblocked anything.
- **Coverage below 80% means the score reflects what was examined, not what is true.** Do not quote it to anyone making a launch decision.

## Domain scores

| Domain | Score | Weight | Checks | Open P0 | Open P1 |
|---|---:|---:|---:|---:|---:|

## Open P0 — blocks any launch

## Open P1 — blocks paid or public launch

## Open P2 — blocks scale

## Trend

| Run | Score | Delta | P0 | Coverage | Band |
|---|---:|---:|---:|---:|---|


---

## section `THREAT-MODEL.md`

# Threat Model: {{PROJECT}}

Last updated: {{DATE}}

One page is enough. The point is to choose controls deliberately rather than by habit.

## Assets — what is worth stealing or breaking

| Asset | Why someone wants it | Worst case if lost |
|---|---|---|
| Customer personal data | | |
| Payment capability | | |
| Inference budget | | |
| Production database | | |
| Admin access | | |
| Source code / IP | | |
| Domain and email reputation | | |

## Actors

| Actor | Motivation | Capability | Most likely path |
|---|---|---|---|
| Opportunistic scanner | Anything exploitable | Automated, broad | Known CVE, exposed endpoint, default credential |
| Abusive user | Free resources | Scripting | Signup abuse, quota bypass, scraping |
| Curious user | Other users' data | Browser devtools | ID substitution in URLs and API calls |
| Targeted attacker | Specific data | Persistent, skilled | Phishing a maintainer, supply chain, injection |
| Compromised dependency | Credentials | Runs at install time | Registry compromise, install script |
| Prompt injection via content | Exfiltration | Whatever the agent can do | Untrusted content in the model context |
| Insider / departed staff | Varies | Standing access | Credentials that were never revoked |

## Trust boundaries

Where untrusted input crosses into trusted execution. List them all — request handlers, file uploads, webhooks, retrieved documents, tool outputs, third-party callbacks, model output.

## Controls and gaps

| Threat | Control | Detects it? | Gap |
|---|---|---|---|

## The three things most likely to actually happen

1.
2.
3.

For each: is the control at level 4 (enforced), or is it something someone has to remember?


---

## section `run-report.template.md`

# FINISHER Run {{RUN_ID}}

> Generated by `finisher_score.py commit`. This template documents the shape;
> the script produces the real thing. Edit the summary afterwards if useful.

- Date:
- **Pre-run score:**
- **Post-run score:**
- **Delta:**
- Band: ____ → ____
- Coverage: __% → __%
- Open P0: __ → __

## Scope of this run

Triage / full audit / domain deep-dive / regression / pre-launch gate. Which domains were examined.

## Summary

Two or three sentences. What was done, what it bought, what is next.

## What changed the score

| Check | Tier | Before | After | What was done |
|---|---|---:|---:|---|

## Regressions

| Check | Tier | Before | After | Why |
|---|---|---:|---:|---|

## Work done that did not move a score

## Findings not yet fixed

| Check | Tier | Finding | Recommended fix | Effort |
|---|---|---|---|---|

## Next run: highest-value targets

| ID | Tier | Check | Now | Points available |
|---|---|---|---:|---:|

## Notes for whoever picks this up


---

## section `context.template.json`

```json
{
  "_HOW_TO_USE": "Set ONLY the conditions you are certain about. DELETE any key you are unsure of — an absent condition INCLUDES its checks and flags them 'assumed applicable', which is the safe direction. Writing false is an explicit decision to remove checks from scoring, so only write false when you are sure. See context.example.json for a filled-in example.",
  "_CONDITIONS": ["has_users", "is_public", "is_multi_tenant", "has_admin", "has_pii", "has_payments", "has_uploads", "has_ugc", "has_ai", "has_agents", "has_third_party", "has_jobs", "has_email", "has_mobile", "eu_users", "us_state_privacy", "is_regulated", "has_team"]
}

```

---

## section `context.example.json`

```json
{
  "_NOTE": "Example only — a multi-tenant B2B SaaS with payments and an AI feature, no mobile app. Copy, edit, and delete anything you are not sure about rather than guessing false.",
  "has_users": true,
  "is_public": true,
  "is_multi_tenant": true,
  "has_admin": true,
  "has_pii": true,
  "has_payments": true,
  "has_uploads": true,
  "has_ugc": true,
  "has_ai": true,
  "has_agents": false,
  "has_third_party": true,
  "has_jobs": true,
  "has_email": true,
  "has_mobile": false,
  "eu_users": true,
  "us_state_privacy": true,
  "is_regulated": false,
  "has_team": true
}

```

---

## section `state.template.json`

```json
{
  "_comment": "Generated by: finisher_score.py init. This file documents the shape.",
  "project": "myapp",
  "catalog_version": "1.0.0",
  "created": "2026-07-25T00:00:00+00:00",
  "context": {
    "has_users": true,
    "is_public": true,
    "has_pii": true
  },
  "checks": {
    "AUTHZ-01": {
      "score": 3,
      "evidence": "Ran the User A / User B script from knowledge file X1-manual-test-scripts.md against staging. All 18 attempts returned 403 or 404 with no data in the body, and each was logged with the actor and target.",
      "artifact": "tests/security/authz.spec.ts::cross-user-object-access (14 cases, passing) + docs/evidence/2026-07-25-authz-run.txt",
      "enforcement": null,
      "na": false,
      "na_reason": null,
      "notes": "The CSV export endpoint was the one that failed initially. Fixed in a1b2c3d."
    },
    "SEC-01": {
      "score": 4,
      "evidence": "Built the production bundle and grepped for every provider key prefix. No matches. DevTools Network shows no outbound request carrying a credential the server did not add.",
      "artifact": "scripts/scan-bundle.sh output in CI run #482",
      "enforcement": "CI job `build-scan` fails the build on any secret-pattern match in dist/",
      "na": false,
      "na_reason": null,
      "notes": null
    },
    "MOB-01": {
      "score": 0,
      "evidence": null,
      "artifact": null,
      "enforcement": null,
      "na": true,
      "na_reason": "Web application only; no mobile app is shipped to any store.",
      "notes": null
    }
  }
}

```

---

## section `actions.template.json`

```json
{
  "summary": "Second hardening pass. Closed the remaining auth P0s and verified the restore path. Cost controls next.",
  "actions": {
    "AUTHZ-01": "Moved ownership filtering into the repository layer so an unscoped query is unrepresentable. Added 14 IDOR cases derived from the manual script.",
    "DATA-02": "Restored the 2026-07-24 snapshot into a scratch project, booted the app against it, verified row counts on the three largest tables and one known record. 11 minutes end to end - that is our real RTO, not the 2 minutes we assumed.",
    "SEC-02": "gitleaks found a Stripe test key in commit 4f2a1c from March. Rotated at the provider despite it being test mode, and logged the rotation.",
    "DOC-01": "Started the README rewrite. Not finished - deliberately not scored."
  }
}

```

---

