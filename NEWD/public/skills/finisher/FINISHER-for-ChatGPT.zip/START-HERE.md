# FINISHER for ChatGPT — setup

Everything needed to run FINISHER inside a ChatGPT Project. Nothing else to download.

## 1. Create a Project

ChatGPT → Projects → new Project. (A Custom GPT works too; same files, same instructions.)

## 2. Upload the knowledge files

Upload **all 28 files in `knowledge/`** as Project files.

They are split one-per-domain deliberately. A single 300KB document retrieves unreliably — the model
gets a summary chunk and misses the controlling detail three sections away. Separate, clearly-named
documents retrieve far better, and `01-MANIFEST-check-index.md` gives the model an explicit index
from any check ID to the file that explains it.

## 3. Upload the tool files

Upload everything in `tools/`:

| File | Purpose |
|---|---|
| `finisher_score.py` | The scoring engine. Runs in ChatGPT's code interpreter. |
| `checks.yaml` | The catalog the scorer reads. Must be uploaded alongside it. |
| `test_finisher_score.py` | Its 66-test suite. Run it if you change anything. |
| `context.template.json` | Starting point. It deliberately sets **no** conditions — delete-what-you-don't-know is the safe default, and unset conditions include their checks. |
| `context.example.json` | A filled-in example: multi-tenant SaaS with payments and an AI feature |
| `actions.template.json` | Shape of the per-run change log |
| `schemas/*.json` | JSON Schemas for context, state, actions, and ledger entries |

The scorer resolves `checks.yaml` from its own directory, so no path flags are needed.

## 4. Paste the instructions

Copy **all of `PROJECT-INSTRUCTIONS.md`** into the Project's instructions box. The whole file,
nothing added.

## 5. Verify the setup

Ask: *"What is your FINISHER triage list, and which knowledge file explains AUTHZ-01?"*

Correct response: the P0 triage set, and `D01-auth-and-authorization.md`. If it answers vaguely or
cannot name the file, the knowledge upload did not take.

Then, in the code interpreter, run `python3 test_finisher_score.py`. It should print
`ALL TESTS PASSED`. That confirms the scorer and catalog arrived intact.

---

## Running it

Give it your project — a repo zip without `node_modules`, or the specific files under audit, plus a
schema dump and your CI workflow files.

First prompt:

> Run a FINISHER intake on the attached project. Read the method and intake knowledge files first.
> Inspect what I gave you before asking questions. Then give me the risk level, the applicability
> context you inferred, the P0 triage findings, and exactly what runtime evidence you need from me
> to score the rest.

## What ChatGPT cannot do on its own

Unless you have connected a tool and verified it works, ChatGPT cannot reach your running app, your
database console, your hosting dashboard, your CI, or your production logs. Roughly a third of the
weighted score sits behind "running app" evidence and another sixth behind vendor consoles.

That is not a defect, it is the design. Those checks score 0 and the coverage figure drops, so the
report says *"48/100 at 34% coverage"* rather than pretending it looked. Gather the runtime evidence
yourself — `curl -I` output, a backup config screenshot, the User A / User B test result from
`X1-manual-test-scripts.md` — and paste it back. Coverage climbs as you do.

If you have a connected GitHub, browser, or database tool, say so and ask it to verify what it can
actually reach before scoring.

## When the catalog is updated

If you upload a newer `checks.yaml` and try to score an old `state.json` against it, the scorer
refuses the commit and lists what is missing. Reconcile first:

    python3 finisher_score.py migrate --state state.json

That adds the new checks unscored, flags stale entries without deleting your evidence, and updates
the recorded catalog hash. Expect the score to dip — new unscored checks lower coverage, correctly.

## Keeping the score

Download `state.json` and `ledger.jsonl` after each run and re-upload them next time. That is your
run history. The scoring is deterministic, so you can audit in ChatGPT this week and continue in a
terminal or another tool next week off the same state file, and the numbers stay comparable.

Every committed run also writes `runs/<id>.state.json` — a snapshot of exactly what was scored — so
any historical run can be reproduced rather than taken on trust.

## Verifying the package

`MANIFEST.sha256` lists every file with its SHA-256 and size:

    grep -v '^#' MANIFEST.sha256 | awk '{print $1"  "$3}' > /tmp/sums && sha256sum -c /tmp/sums
