# Intake, Risk Tiering and Scoping

The first ten minutes of a FINISHER run decide whether the rest of it is useful. Get the context wrong and you will either terrorize someone's weekend project or wave through a payments app.

## 1. Do not ask; look first

Read before you interview. The repository answers most intake questions faster and more honestly than the owner will.

```bash
# shape of the thing
ls -la; cat README* 2>/dev/null | head -60
cat package.json requirements.txt pyproject.toml go.mod Gemfile composer.json 2>/dev/null

# what it talks to
grep -rEl "stripe|paddle|lemonsqueez|openai|anthropic|gemini|supabase|firebase|clerk|auth0|twilio|sendgrid|resend|s3|cloudinary" \
  --include="*.{ts,tsx,js,jsx,py,go,rb,java,php}" . 2>/dev/null | head -40

# secret names only, never values
grep -rhoE "(process\.env\.|import\.meta\.env\.|os\.environ\[?.?)[A-Z_][A-Z0-9_]*" . 2>/dev/null \
  | grep -oE "[A-Z_][A-Z0-9_]*$" | sort -u

# surface area
find . -path ./node_modules -prune -o \( -name "*route*" -o -name "*controller*" -o -name "*api*" \) -print 2>/dev/null | head -40
ls migrations/ prisma/migrations/ supabase/migrations/ db/migrate/ alembic/versions/ 2>/dev/null
ls .github/workflows/ 2>/dev/null
```

Then ask only what the code cannot tell you: user counts, launch date, who the users are, what data is genuinely sensitive, and what the owner is actually afraid of.

## 2. Build the context object

Everything downstream keys off this. Write it to `finisher/context.json`.

```json
{
  "has_users": true, "is_public": true, "is_multi_tenant": false,
  "has_admin": true, "has_pii": true, "has_payments": true,
  "has_uploads": false, "has_ugc": true, "has_ai": true, "has_agents": false,
  "has_third_party": true, "has_jobs": true, "has_email": true,
  "has_mobile": false, "eu_users": true, "us_state_privacy": true,
  "is_regulated": false, "has_team": true
}
```

Getting these wrong is the most consequential error in the whole process, because a false condition silently removes checks from the denominator. Two rules:

- **When unsure, set it true.** A false positive costs a conversation. A false negative hides a P0.
- **`has_pii` is true more often than people think.** Email addresses are personal data. IP addresses in logs are personal data. "We don't collect PII, just accounts" is wrong.

## 3. Risk levels

The level sets expectations, not the check list. The check list is set by the context conditions. The level tells you how hard to push and what "done" means for this project right now.

| Level | Shape | Target band | What a FINISHER run should do |
|---|---|---|---|
| **L0** Local demo | No users, no real data, no public URL | n/a | Confirm no secrets committed, confirm it is genuinely not exposed, then stop. Do not run the full catalog. |
| **L1** Private prototype | Invited users, low-risk data, no money | 40+ | P0s only, plus error tracking and backups. A weekend of work. |
| **L2** Paid beta | Real users, real money, real data | 60+ | All P0, most P1. Staging, CI, monitoring, restore test, spend caps. |
| **L3** Production SaaS | Public, private data, support expectation | 75+ | All P0 and P1. Runbook, rate limits, security scanning, handoff docs. |
| **L4** Enterprise / regulated | Compliance, large orgs, sensitive data | 90+ | Everything, plus audit logging, access reviews, formal compliance mapping, vendor risk. |

Choosing a level is a business decision, not a technical one. Ask directly: *"if this leaked every user's data tomorrow, what happens?"* The honest answer sets the level faster than any questionnaire.

**The one rule that overrides the level:** if the product touches money, personal data, or production systems belonging to someone else, it is at least L2 regardless of user count. Ten users is not a safety property.

## 4. Scoping a run

A full first pass on a real application is genuinely hours of work. Scope deliberately:

| Run type | Scope | Typical duration |
|---|---|---|
| **Triage** | P0 checks only, all domains | 1–2 hours |
| **Full audit** | Every applicable check, evidence gathered | half a day to two days |
| **Domain deep-dive** | One domain, every check, to level 3–4 | 2–4 hours |
| **Regression run** | Re-verify checks at 3+ whose evidence is over 90 days old | 1 hour |
| **Pre-launch gate** | Every P0 and P1, evidence refreshed | half a day |

Always record the scope in the run report's summary. A score computed from a triage run is not comparable to one from a full audit — coverage percentage makes that visible, which is exactly why coverage is reported.

## 5. What to do first, always

Regardless of level, in this order:

1. **Stop feature work.** Not forever. Until the P0 list is known. You cannot assess a moving target, and every new feature added during an audit is unassessed surface.
2. **Create a branch and take a backup.** Before touching anything. Especially the database.
3. **Run the secrets check.** It is the only P0 that gets worse with every hour of delay, because exposure time is the variable.
4. **Establish the score baseline** with honest coverage, even if the honest answer is "we have looked at 12% of this."

## 6. When to say the project is fine

FINISHER is a tool for protecting people, not a ritual. A weekend project with no users, no real data, no public URL, and no secrets in git is **finished**. Say so, record it as L0, and give the owner the two-line list of what would change if they ever put it online.

Applying L3 discipline to an L0 project wastes the owner's time and trains them to ignore you when it matters.
