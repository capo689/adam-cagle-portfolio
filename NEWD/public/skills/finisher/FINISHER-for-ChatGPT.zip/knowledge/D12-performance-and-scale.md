# Performance, Caching and Scale

> Covers checks PERF-01..07. Domain D12, weight 5.

Success is the most common cause of the first real outage. The goal is not to be fast — it is to **know where it breaks** before your users find out for you.

---

## 1. Connections are the first wall

Serverless plus a connection-per-invocation pattern exhausts database connections at traffic levels far below what anyone expects. It is the most common first-scale failure and it is arithmetic:

```
max_concurrent_instances x connections_per_instance < db_max_connections - headroom
```

Fifty concurrent function instances at 10 connections each is 500 connections against a database that allows 100.

Use a pooler in transaction mode: PgBouncer, Supavisor, RDS Proxy, or your provider's built-in. Understand the constraints transaction-mode pooling imposes — prepared statements and session-level settings do not survive between transactions, which affects how you set row-level-security context.

Alert on pool saturation. That metric predicts the outage instead of reporting it.

## 2. Find the slow queries with data

```sql
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

SELECT calls,
       round(mean_exec_time::numeric, 2)  AS avg_ms,
       round(total_exec_time::numeric)    AS total_ms,
       rows / GREATEST(calls,1)           AS rows_per_call,
       query
FROM pg_stat_statements
ORDER BY total_exec_time DESC
LIMIT 20;
```

**Sort by total time, not average.** The 30ms query executed a million times matters more than the 3-second report nobody runs.

Then look for the N+1 pattern — the same query shape with a high call count and one row per call. ORMs generate these effortlessly and AI-generated data access is particularly prone to them, because the natural way to express "get the author for each post" in a loop is exactly wrong.

```sql
EXPLAIN (ANALYZE, BUFFERS) SELECT ...;   -- Seq Scan on a large table is the finding
```

Add indexes from measurement. Then check for indexes nobody uses — they cost write throughput and storage for nothing:

```sql
SELECT relname, indexrelname, idx_scan
FROM pg_stat_user_indexes WHERE idx_scan = 0 ORDER BY relname;
```

## 3. Cache carefully — this is a security surface

Caching private data with the wrong key is a data breach caused by a header. It has happened to large, competent companies.

Rules:

- Authenticated responses: `Cache-Control: private, no-store` unless you have thought hard about it
- Any cache key for user-scoped data **must include the user or tenant identity**
- Audit CDN and edge rules for paths that bypass authentication — a rule caching `/api/*` will happily cache one user's data and serve it to the next
- Define the invalidation trigger *before* adding the cache. "We will figure out invalidation later" produces stale data forever.

What is safe and worth caching: content-hashed static assets with long max-age, public read-only content, expensive aggregate computations with a defined staleness tolerance, and third-party responses that do not vary by user.

## 4. Load testing

Run it before launch, against staging, and ramp until something breaks. The output you want is not "it handled 100 users" — it is **the number where it stops working and what breaks first**.

```js
// k6: ramp to find the knee, not to prove a number
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  stages: [
    { duration: '2m', target: 50 },
    { duration: '3m', target: 200 },
    { duration: '3m', target: 500 },
    { duration: '2m', target: 0 },
  ],
  thresholds: {
    http_req_duration: ['p(95)<1000'],
    http_req_failed:   ['rate<0.01'],
  },
};

export default function () {
  const res = http.get(`${__ENV.BASE_URL}/api/dashboard`, {
    headers: { Authorization: `Bearer ${__ENV.TOKEN}` },
  });
  check(res, { 'status 200': (r) => r.status === 200 });
  sleep(1);
}
```

```bash
k6 run --env BASE_URL=https://staging.example.com --env TOKEN=$T load-test.js
```

Model realistic behavior, not a single endpoint hammered in a loop. Mix reads and writes in the proportions your product produces. Include the scenarios that actually hurt:

- Fifty signups in the same minute (a launch post)
- Concurrent expensive operations — reports, exports, inference calls
- A cold cache
- One user pulling a very large dataset

Record where latency degrades, where connections saturate, where third-party rate limits trigger, and where costs spike. **Never load test production.**

## 5. Frontend performance

Field data over lab data. Track LCP, INP, and CLS at the 75th percentile from real users; verify current thresholds against Google's published guidance rather than from memory.

The levers, in the order they usually pay:

1. Ship less JavaScript — analyze the bundle; the biggest single win is almost always one heavy dependency imported by accident
2. Images: modern formats, correct dimensions, lazy loading below the fold, explicit width and height to prevent layout shift
3. Fonts: preload, `font-display: swap`, subset
4. Route-level code splitting
5. A bundle-size budget enforced in CI — without a gate, bundle size only grows

## 6. Know the next bottleneck

You do not need to build for ten times the traffic. You need to know what breaks at ten times and what you would do about it.

One page, three entries: the next three bottlenecks in the order they will arrive, and the response to each. Revisit whenever traffic doubles.

Typical order for a small SaaS: database connections, then a single unindexed hot query, then a single-threaded worker, then an external API rate limit, then storage egress cost.
