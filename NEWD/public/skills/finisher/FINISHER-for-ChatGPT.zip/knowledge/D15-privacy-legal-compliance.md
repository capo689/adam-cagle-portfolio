# Privacy, Legal and Compliance

> Covers checks LEG-01..10. Domain D15, weight 6. Applies when `has_pii` is true.

**This is not legal advice, and the assistant using this skill must not present it as such.** Privacy and consumer-protection law changes faster than any checklist can track: statutes take effect on staggered dates, regulations get amended, and several notable rules have been altered or vacated by courts after publication. Treat everything below as *the set of questions to answer*, and verify every specific obligation against primary sources and qualified counsel before relying on it.

The engineering work, however, is stable. Almost every regime asks for the same underlying capabilities: know what data you hold, be able to delete it, be able to export it, be honest about it, and be able to say what happened when something goes wrong. Build those and most compliance work becomes paperwork rather than engineering.

---

## 1. The data inventory is the foundation

Everything else depends on it. You cannot honor a deletion request, answer a security questionnaire, assess breach scope, or write an accurate privacy policy without knowing where data lives.

| Data element | Purpose | Where stored | Retention | Who receives it |
|---|---|---|---|---|
| Email address | account identity, transactional mail | Postgres `users`, email provider | life of account + 30d | email provider, error tracking |
| IP address | abuse prevention | application logs | 30 days | log provider |
| Uploaded documents | core product function | object storage | life of account | model provider (inference) |
| Payment method | billing | **provider only, never ours** | provider policy | payment provider |

The rows people forget, every time: **error tracking** (which attaches request bodies and headers by default), **analytics**, **model providers** (anything sent for inference), **support tooling**, and **log aggregation**. Each of those is a third party receiving personal data, which usually means a processor agreement is required.

Two notes on scope. Email addresses are personal data. IP addresses are personal data in most regimes. "We don't collect PII, just accounts" is almost always wrong.

## 2. The privacy policy must be true

A generic template that misdescribes your actual processing is worse than nothing — it is a written, published, inaccurate statement about your own systems.

Derive it from the inventory. It should state what you collect, why, the basis on which you do so, who you share it with (name the categories, and in some regimes the specific processors), how long you keep it, how users exercise their rights, and how to contact you. Update it when the data flows change — make that a step in the pull request template for schema and vendor changes.

## 3. Make the rights operable

Access, deletion, correction, portability, and objection all carry statutory response deadlines somewhere. A manual process nobody has ever run will miss them.

The engineering requirement for deletion is the hard one, because "delete the row" is not deletion:

- Primary datastore
- Object storage
- Search indexes
- Caches
- Analytics platform
- Error tracking payloads
- Model provider logs and any fine-tuning data
- Support and CRM tools
- **Backups** — the honest hard case. A deleted record persists until the backup expires. State the window, make it finite, and document it in the policy.

Build it as a real deletion job with a checklist, ideally self-service in product. Run it end to end against a test account and time it. That run is the evidence.

Note that account deletion is not only a privacy obligation — it is also a standing app store review requirement for any app that allows account creation.

## 4. Consent and tracking

Where consent is required for non-essential cookies and trackers, the requirements are consistent across regimes even when the details differ: no non-essential tracker fires before consent, refusing must be as easy as accepting, and consent must be recorded and revocable.

Verify with a network trace, not by looking at the banner. Load the page with a clean profile, decline, and check what fired. Analytics and session-replay scripts loading before the consent decision is the most common finding, and it is usually because the tag was added directly to the layout rather than gated.

Several US state regimes require honoring a browser-level opt-out signal. Detecting `navigator.globalPrivacyControl` and the corresponding `Sec-GPC` header, and treating it as an opt-out of sale and sharing, is a small piece of code and a specific, testable requirement. **Verify which states apply to you and what their current thresholds are** — the list has been growing every year.

## 5. Processor agreements and transfers

Every third party processing personal data on your behalf generally needs a written agreement. Most major vendors publish a standard one you can accept online — the work is enumerating the vendors, which the data inventory already did.

International transfers need a valid mechanism. This has been litigated repeatedly and mechanisms have been invalidated before. **Check the current status rather than assuming the arrangement in place when you built the app still stands.**

## 6. Payments

The single most consequential architectural decision is where card data touches. A hosted checkout or the provider's iframe-based fields keeps card data off your servers and out of your DOM entirely, which dramatically reduces your compliance scope. Building your own card form on your own page expands it, including obligations around managing and monitoring the scripts on payment pages.

Whatever you choose: never log card numbers, never store them, and confirm which self-assessment path actually applies to your integration rather than assuming the simplest one does. **Verify current PCI DSS requirements directly** — requirements have been phased in over time and dates matter.

Subscription rules — disclosure before purchase, ease of cancellation, renewal reminders — vary by jurisdiction and have been in flux. The defensible position is simple and does not depend on tracking the litigation: disclose clearly before purchase, and make cancelling as easy as subscribing, through the same channel.

## 7. Accessibility as a legal matter

Accessibility requirements now carry legal force in multiple jurisdictions, with staggered deadlines, sector scoping, and exemptions that may or may not cover you. **Verify current scope and dates for your markets.**

The engineering answer is stable regardless: WCAG 2.2 Level AA is the practical target, and the work is described in knowledge file `D05-frontend-ux-accessibility.md`. Publish an accessibility statement if your regime requires one, and make it honest about known gaps rather than claiming full conformance you have not verified.

## 8. Sector and enterprise regimes

If you handle health, financial, educational, or children's data, or if you sell to enterprises that will ask, identify the regime early. The pattern is consistent:

- Obtain the necessary agreement **before** any regulated data flows — not after the pilot starts
- Map each required control to a specific implementation, not to an intention
- Collect evidence continuously; compliance automation platforms help with collection and monitoring but do not implement the controls for you
- Expect the audit to test whether the control operated over a period, not whether it exists today

A useful sequencing note: most of the controls an audit will ask about are already in this catalog — access control, logging, backups, change management, vendor review, incident response. Getting to a high FINISHER score is most of the preparation.

## 9. User-generated content

Any surface where users publish to other users attracts abuse, illegal content, and copyright claims. Platform obligations vary by jurisdiction and by scale, and small services are not always exempt.

The minimum that is defensible: a reporting mechanism, a defined review process with an owner, a takedown path, terms that permit removal, and a record of what you did. If you host user content at any scale, identify whether a designated copyright agent registration applies to you.

## 10. Breach response

Notification obligations have clocks measured in hours, and they start when you become *aware*, not when you finish investigating. Section 4 of knowledge file `D11-reliability-and-incidents.md` covers the operational sequence.

The two things to settle before you need them: **who decides whether a notification is required**, and **which lawyer you call**. Both are five-minute decisions now and impossible ones at 2am.
