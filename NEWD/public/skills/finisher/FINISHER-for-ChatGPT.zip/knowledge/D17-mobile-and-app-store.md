# Mobile and App Store Readiness

> Covers checks MOB-01..10. Domain D17, weight 6. Applies when `has_mobile` is true.

**Store policies change frequently and materially** — target API level deadlines, privacy declaration requirements, payment and external-link rules, age rating systems, and platform technical requirements have all moved repeatedly, sometimes as a result of litigation and sometimes by region. Verify every specific requirement against the current Apple App Store Review Guidelines and Google Play policy pages before submission. This file is the checklist of *what to check*, not a snapshot of the rules.

Mobile adds a constraint web apps do not have: **you cannot hotfix.** A bad release lives on users' devices until they update, which is why forced updates, staged rollouts, and server-side kill switches matter far more here.

---

## 1. Account deletion

If the app supports account creation, it must support account deletion **initiated in-app**. Not deactivation, not "email us," not buried in a web dashboard the app never links to. This is a standing requirement on both platforms and one of the most common avoidable rejections.

The deletion must be real — see knowledge file `D15-privacy-legal-compliance.md` §3 for what "real" means across every store the data touches. Provide a web-accessible deletion path as well where the platform requires it.

## 2. Privacy declarations must match reality, including SDKs

Both stores require you to declare what data the app collects and how it is used, and both require those declarations to cover **third-party SDK behavior**, not just your own code. Analytics, ads, crash reporting, attribution, and support SDKs all collect things, and you are responsible for declaring them.

Additional platform mechanisms exist for declaring the reason certain sensitive APIs are used and for SDK-level privacy manifests and signatures. Requirements and enforcement dates have shifted; verify current obligations directly.

The work:

1. Enumerate every SDK and transitive SDK in the build
2. For each, determine what it collects and why
3. Map that to the declaration categories honestly
4. Re-run this whenever a dependency is added — make it part of the pull request template

Mismatches cause rejection at review time and enforcement later, and "our analytics vendor collects that, not us" is not a defense.

## 3. Monetization

Purchase rules — when in-app purchase is mandatory, when external payment links are permitted, and what you may say about alternatives — have changed repeatedly through litigation and vary by region. Assumptions here get apps removed rather than rejected.

Determine which mechanism your content actually requires, verify the current rules for every region you ship to directly from the store policies, and implement **server-side receipt validation**. Client-side validation is trivially bypassed, and the resulting revenue loss is silent.

## 4. Technical requirements and deadlines

Both stores enforce rolling minimums: a target API level, a build SDK version, and periodic platform technical requirements. Missing one blocks updates entirely — including security fixes, which is the part that turns an administrative deadline into an incident.

Check the current required values for both stores, set them in the build configuration, and **put the next announced deadline in a calendar with a reminder**. This is the only item in the catalog whose failure mode is purely a missed date.

## 5. Forced updates and kill switches

Because you cannot hotfix, you need server-side control:

- **Minimum supported version check** on launch, served from your backend, that blocks the app with an update prompt below the threshold
- **Feature kill switches** so a misbehaving client feature can be disabled without a release
- **API versioning** so old clients degrade gracefully rather than breaking when the backend moves

Test the block by lowering the client version locally. An untested forced-update mechanism is worse than none, because you will rely on it.

## 6. Crash reporting and release health

Mobile crashes are invisible without instrumentation, and crash rate is a signal the stores themselves surface. Install crash reporting with symbolication and per-release tagging, and watch crash-free session rate per release.

Alert on crash-rate regression after a release. Combined with staged rollout, that gives you an abort path.

## 7. The binary is public

Mobile binaries are trivially decompiled. Anything shipped in the app is public — API keys, endpoints, business logic, and any "secret" constant.

- No privileged credentials in the binary. String-extract the built artifact and confirm.
- Every mobile-facing endpoint enforces authentication and authorization independently. The app is a client, not a trust boundary.
- Sensitive data goes in Keychain or Keystore, not in preferences or an unencrypted local database.
- Platform attestation (App Attest, Play Integrity) can raise the cost of API abuse, but **never as the only control** — treat it as a rate-limiting signal, not authentication.
- Certificate pinning is a real trade-off: it defeats interception but can brick your app on a certificate rotation. If you pin, pin to a CA or use backup pins, and have a remote kill switch for the pinning itself.

## 8. Offline and degraded behavior

Define what works with no connectivity, what happens to in-flight actions, and how conflicts resolve on reconnect. Then walk the core screens in airplane mode. "Infinite spinner with no message" is the default outcome and it looks identical to a crash from the user's side.

## 9. Deep links

A broken universal or app link silently falls back to the browser and breaks every email, notification, and share flow — and it fails silently, so nobody reports it.

Verify the association files are served correctly and test the matrix: cold start, warm start, logged out, expired session, invalid target, and the link arriving while a modal is open.

## 10. Release mechanics

- **Staged or phased rollout on both platforms**, with a defined halt criterion (crash rate, error rate, a specific user report threshold) and a known halt procedure
- **Push credentials have expiry dates.** Record them with calendar reminders; silently expired push credentials are a classic slow-burn outage.
- Store listing assets, age ratings, export compliance declarations, and any required business or trader information change over time — verify current requirements before each submission rather than reusing last year's answers
- Budget for review time and know the expedited path exists before you need it
