# Environments, Config and Infrastructure

> Covers checks ENV-01..06. Domain D09, weight 5.

---

## 1. Genuine separation

Three environments, and the separation must be real at every layer:

| Resource | Why sharing it burns you |
|---|---|
| Database | A dev seed script wipes customer data |
| Object storage | Test uploads appear in production; deletion tests delete real files |
| Payment provider | Test mode vs live mode; a wrong key charges real cards |
| Email/SMS | Test sends reach real customers. Use a sandbox or a separate sending domain. |
| Queues and crons | A dev worker consumes production jobs |
| Third-party API keys | Rate limits and quota shared; a staging leak reaches production data |
| Error tracking | Dev noise buries real production errors |
| Feature flags | A staging toggle changes production behavior |

Email is the one people miss most often. A staging environment pointed at a production email provider sends real messages to real customers during testing.

## 2. Fail fast on configuration

Validate every environment variable at boot and refuse to start when something is wrong. A missing variable that silently falls back to a development default is a data-leak vector, and it is the failure mode most likely to be invisible.

```ts
const Env = z.object({
  NODE_ENV: z.enum(["development", "staging", "production"]),
  DATABASE_URL: z.string().url(),
  SESSION_SECRET: z.string().min(32),
  STRIPE_SECRET_KEY: z.string().startsWith("sk_"),
  APP_URL: z.string().url(),
}).superRefine((v, ctx) => {
  if (v.NODE_ENV === "production" && v.STRIPE_SECRET_KEY.startsWith("sk_test_"))
    ctx.addIssue({ code: "custom", message: "Test payment key in production" });
});
export const env = Env.parse(process.env);   // throws at import time, not at first request
```

Cross-field assertions like that last one — test key in production, localhost URL in production, debug mode enabled in production — catch the deploy mistakes that are otherwise found by a customer.

## 3. Reproducible infrastructure

Clicked infrastructure cannot be recreated after an account loss, a region failure, or a departure. Infrastructure as code where practical; where not, a written inventory of every manually configured resource and setting.

The minimum viable version of this is a markdown table listing each resource, what it is for, who owns the account, and any non-default setting. That is enough to rebuild. Nothing is enough to guess.

## 4. TLS and domains

- HTTPS enforced, HTTP redirecting to it
- HSTS set, with preload only if you understand it is difficult to reverse
- Automated certificate renewal — plus an independent expiry monitor as a backstop, because renewal automation fails silently
- Registrar: auto-renew on, registrar lock on, MFA on the account, ownership documented
- Domain and certificate expiry both monitored

An expired certificate or a lapsed domain is a total outage with a countdown you could have seen coming. Domain expiry has also been used as an account-takeover vector: an attacker who acquires a lapsed domain can receive password resets for accounts registered on it.

## 5. Timeouts and compute limits

Know the hard limits of your platform: request timeout, memory ceiling, payload size, concurrent execution cap, cold start latency. Then measure p95 for every endpoint and compare.

Anything within striking distance of the timeout moves to a background job. This is not a scaling optimization; a timeout mid-write leaves partial state and returns a 504 with no explanation.

Serverless-specific traps worth checking explicitly:

- Cold starts on the login path make the product feel broken for the first user each period
- Connection-per-invocation exhausts database connections (see knowledge file `D03-data-migrations-backups.md`)
- Response size limits truncate large payloads silently in some platforms
- Regional placement: a function in one region talking to a database in another adds latency to every query

## 6. Cost visibility at the infrastructure layer

Set budget alerts on every provider — hosting, database, storage, egress, log ingestion, and inference. Egress and log ingestion are the two that surprise people; both scale with success rather than with usage you feel.

Model cost per active user and project it forward ninety days. The useful output is not the total — it is knowing which line item grows fastest, because that is the one that will force an architecture change.
