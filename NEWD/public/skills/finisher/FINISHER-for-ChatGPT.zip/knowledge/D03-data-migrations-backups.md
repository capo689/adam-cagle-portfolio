# Data Layer, Migrations and Backups

> Covers checks DATA-01..12. Domain D03, weight 9.

Three facts drive this domain: an untested backup is a hypothesis; a schema change that is not a migration file will be lost; and an agent with production database credentials will eventually use them.

---

## 1. Backups and the restore drill

**DATA-01 (backups configured) and DATA-02 (restore verified) are separate P0 checks on purpose.** Teams conflate them constantly. Configuration is a checkbox. Restoration is a fact.

The drill, which is the artifact that makes DATA-02 a 3:

1. Take the most recent production snapshot
2. Restore it into a scratch environment — a new database, a branch, a fresh project
3. Point a running copy of the application at it
4. Verify: row counts on the three biggest tables, a specific known record, extensions and enums present, sequences correct
5. **Write down the elapsed time.** That number is your real RTO, and it is almost always several times what people guess.

Cover every datastore, not just the primary: object storage buckets, search indexes, cache warm-up requirements, and any managed service holding state you cannot regenerate.

Backup failures must alert. A backup job that has been silently failing for six weeks is the classic discovery-during-incident.

## 2. Environment separation

Development, staging, and production get separate databases. Not separate schemas in one instance — separate instances or managed branches, with different credentials.

The defensive pattern worth adding:

```ts
// refuse to run destructive tooling against production
const host = new URL(process.env.DATABASE_URL!).host;
if (process.env.NODE_ENV !== "production" && /prod/i.test(host)) {
  throw new Error(`Refusing: non-production process pointed at ${host}`);
}
```

Then: **no standing write access to production for humans or agents.** Read-only by default. Break-glass elevation that is time-boxed, logged, and alerts on use. AI coding tools get development credentials, full stop — the best-documented AI data-loss incident happened because an agent had production access at all, not because it chose to delete something.

## 3. Migrations

Every schema change is a versioned file in the repository. No console DDL. The property to protect: **a fresh database, created from migrations alone, must produce a working application.** Verify it in CI:

```yaml
- run: createdb ci_test
- run: npm run migrate          # from zero
- run: npm run seed
- run: npm test
```

### Migration linting is the highest-value control here

AI-written migrations take exclusive locks and drop data without hesitation. A linter catches both mechanically:

```bash
npx squawk migrations/*.sql            # Postgres: locks, missing CONCURRENTLY, unsafe types
atlas migrate lint --dev-url "docker://postgres/16/dev" --latest 10
```

Squawk flags the classics: creating an index without `CONCURRENTLY` (blocks writes for the duration), adding a unique constraint (exclusive lock, blocks everything), changing a column type (table rewrite), `serial` instead of identity, and adding a `NOT NULL` column without a safe default. Atlas adds destructive-change detection and drift.

Make it a required PR check. It costs nothing and it catches the specific class of mistake that turns a routine deploy into an outage.

### Expand and contract

Down migrations are a trap. They are rarely exercised, frequently wrong, and destructive down migrations lose data on exactly the worst day. Prefer roll-forward with backwards-compatible changes:

1. **Expand** — add the new column/table, nullable, no constraint
2. **Dual write** — deploy code that writes both old and new
3. **Backfill** — in batches, off the request path
4. **Switch reads** — deploy code that reads the new
5. **Contract** — a later deploy removes the old

The property this buys you: **at every step, the previous version of the application still works against the current schema.** That is what makes a code rollback safe, which is the rollback you will actually perform. Test it explicitly — run version N-1's test suite against version N's schema.

## 4. Constraints and indexes

AI-generated schemas routinely omit foreign keys, unique constraints, and `NOT NULL`, pushing integrity enforcement into application code that forgets it. The database is the only place a constraint cannot be bypassed by a new code path.

Deliberate choices to make explicitly:

- Foreign keys with chosen `ON DELETE` behavior — `CASCADE` is convenient and occasionally catastrophic
- Unique constraints on natural keys and on idempotency keys
- `NOT NULL` where a null genuinely has no meaning
- Check constraints on enumerated values
- Ownership columns (`user_id`, `tenant_id`) on every table holding user data, indexed, and non-nullable

Index from measurement, not intuition:

```sql
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;
SELECT calls, round(mean_exec_time::numeric,2) AS avg_ms,
       round(total_exec_time::numeric) AS total_ms, query
FROM pg_stat_statements ORDER BY total_exec_time DESC LIMIT 20;

-- indexes nobody uses (they cost write throughput)
SELECT relname, indexrelname, idx_scan FROM pg_stat_user_indexes
WHERE idx_scan = 0 ORDER BY relname;
```

Sort by `total_exec_time`, not `mean_exec_time` — the query that takes 30ms and runs a million times is the problem, not the one that takes 3 seconds once a day.

## 5. Idempotency

Duplicate side effects are the signature failure of AI-generated handlers: double charges, duplicate orders, duplicate emails. The cause is always the same — retries, double clicks, and webhook re-delivery are normal, and nothing in the handler accounts for them.

```sql
CREATE TABLE idempotency_keys (
  key         text PRIMARY KEY,
  scope       text NOT NULL,
  response    jsonb,
  created_at  timestamptz NOT NULL DEFAULT now()
);
```

Insert the key inside the same transaction as the side effect. On conflict, return the stored response instead of doing the work again. Apply it to payments, outbound messages, external API calls with side effects, and anything a user can trigger twice by being impatient.

Test it with genuine concurrency, not two sequential requests — the race is the interesting case.

## 6. File uploads

Unrestricted file upload is CWE-434 and sits at #12 on the 2025 CWE Top 25. Extension checks are trivially bypassed.

- Server-side size limit, enforced before buffering the whole file
- Content-type determined by inspecting bytes, not by trusting the header or extension
- Allowlist of types, never a denylist
- Randomized stored filename; never use the client's filename on disk
- Store in object storage with private ACLs; serve via short-lived signed URLs
- Never serve uploads from a path that can execute
- **SVG is an XSS vector** — sanitize it or serve it with `Content-Disposition: attachment`
- Strip EXIF from images (it contains GPS coordinates)
- For anything user-shared, virus scanning is worth the integration
- Image and document processing libraries are a rich CVE source — run them out-of-process or in a sandbox

## 7. Retention and deletion

Classify every table and bucket: what it holds, why, how long, who can read it. Then implement the purge job, and make deletion actually propagate — primary store, caches, search indexes, analytics, error tracking payloads, AI provider logs, and downstream processors.

Backups are the honest hard case: a deleted record persists in backups until they expire. State the window, document it in your privacy notice, and make sure the window is finite.

## 8. Connection pooling — the first scaling wall

Serverless plus a connection-per-invocation pattern exhausts Postgres connections at traffic levels far below what people expect. Do the arithmetic before launch:

```
max_concurrent_instances x connections_per_instance  <  db_max_connections - headroom
```

Use a pooler — PgBouncer, Supavisor, RDS Proxy, or your provider's built-in — in transaction mode for serverless. Note that transaction-mode pooling breaks prepared statements and session-level settings, which is a real constraint on how you set RLS context. Alert on pool saturation; it is the metric that predicts the outage rather than reporting it.
