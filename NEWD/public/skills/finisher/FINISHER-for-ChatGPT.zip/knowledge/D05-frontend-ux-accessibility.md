# Frontend, UX and Accessibility

> Covers checks FE-01..08. Domain D05, weight 6.

The demo works because the demo is the happy path on a fast laptop with clean data. Production is slow networks, old phones, Safari, empty states, apostrophes, and people clicking the button twice.

---

## 1. The four states

Every component that fetches data has four states, and AI-generated components typically implement one.

| State | The failure when it is missing |
|---|---|
| **Loading** | Blank screen; user assumes it is broken and reloads, doubling the load |
| **Error** | Blank screen or a raw error object; no way to recover |
| **Empty** | Looks identical to loading; new users conclude the product does not work |
| **Success** | The one that exists |

Error states must be actionable: what happened in human language, what the user can do, and a retry that does not require a page reload. "Something went wrong" with no retry trains people to leave.

Empty states are a product surface, not an edge case. A new user's first screen is almost always the empty state — it should explain what goes here and how to add the first one.

## 2. Error boundaries

An unhandled render error white-screens the entire application. Boundaries at route level and around major independent sections turn a total outage into a broken panel.

```tsx
<ErrorBoundary
  fallback={<Panel>This section could not load. <button onClick={retry}>Retry</button></Panel>}
  onError={(err, info) => reportError(err, { component: info.componentStack })}
>
  <Dashboard />
</ErrorBoundary>
```

Boundaries must report, not just catch. A silently swallowed error is worse than a crash, because now it is invisible in both directions.

Note the limits: React error boundaries do not catch errors in event handlers, async code, or SSR. Those need explicit try/catch and a global handler (`window.onerror`, `unhandledrejection`).

## 3. The real device matrix

Test the top three journeys on:

- **An actual phone**, not a resized browser window. Touch targets, keyboard overlay behavior, and viewport units differ.
- **Safari.** Date parsing, `100vh` behavior, storage restrictions in private mode, and IndexedDB quirks break apps that work everywhere else.
- **A throttled network.** Slow 4G in devtools. Race conditions and missing loading states surface immediately.
- **An older device** if your audience has one. A three-year-old Android is a different performance class.

Record the matrix with pass/fail and notes. That table is the artifact for FE-03.

## 4. Hostile input

The reliable crash set, all of which should be tested on every form:

- Empty submission
- Apostrophes and quotes: `O'Brien`, `"quoted"`
- Emoji and non-Latin scripts (a 4-byte emoji breaks anything assuming 1 byte per character)
- 10,000 characters pasted into a text field
- Leading and trailing whitespace
- Double submit — click the button twice fast
- Browser back during a submission
- Session expiring mid-form
- Slow network: submit, then wait

Fixes: disable the submit control while in flight, preserve entered data on failure, enforce `maxlength` server-side as well as in the input, and make the form recoverable after an auth expiry rather than dumping the user to a login page with their work gone.

## 5. Accessibility

Two numbers set the strategy. The WebAIM Million study of the top million home pages in February 2026 found **95.9% had detectable WCAG failures**, and **six mechanical defects accounted for about 96% of all detected errors**: low-contrast text, missing image alt text, missing form labels, empty links, empty buttons, and missing document language.

All six are automatable. Wiring `axe-core` into your test suite eliminates nearly all of them for near-zero ongoing effort:

```ts
import AxeBuilder from '@axe-core/playwright';

test('dashboard has no automatically detectable a11y violations', async ({ page }) => {
  await page.goto('/dashboard');
  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();
  expect(results.violations).toEqual([]);
});
```

The honest limit: automated tooling covers roughly 20–30% of WCAG success criteria, even though that represents around 57% of issue *instances*. Both numbers are true and they answer different questions. Everything conceptual is invisible to a scanner — focus order, whether alt text is meaningful rather than merely present, heading hierarchy semantics, keyboard traps in custom widgets, and whether a screen reader announcement makes sense.

So there is a small mandatory manual layer, roughly 30–60 minutes per release:

1. **Unplug the mouse.** Tab through each critical journey. Visible focus at every step, logical order, no traps, `Esc` closes modals, focus returns to where it came from.
2. **One screen reader pass** on the top two flows — VoiceOver with Safari, or NVDA with Firefox.
3. **200% zoom and a 320px-wide viewport.** Content must reflow without horizontal scrolling.

That plus axe in CI puts a small team ahead of most of the market, and it is the difference between a legal exposure and a defensible position.

## 6. Performance

Measure on real users, not just in the lab. Lab tools tell you what is possible on a good connection; field data tells you what your users actually get.

Track Largest Contentful Paint, Interaction to Next Paint, and Cumulative Layout Shift at the 75th percentile. Verify the current recommended thresholds against Google's published guidance rather than assuming — they have changed, and INP replaced FID.

Practical levers, in the order they usually pay:

- Ship less JavaScript. Analyze the bundle; the biggest win is usually one accidentally-imported heavy dependency.
- Modern image formats, correct dimensions, lazy loading below the fold, and explicit width/height to prevent layout shift.
- `font-display: swap` and preloaded fonts.
- Code-split by route.
- Set a bundle-size budget and fail the build when it is exceeded. Without a gate, bundle size only goes one direction.

## 7. Five users

Watch five people from your target audience attempt the core task with no explanation and no help. Say nothing while they do it — this is the hard part.

Record: did they complete it, how long, and where they stalled. Three people stalling in the same place is not a coincidence and it is not their fault.

This is the cheapest high-value check in the entire catalog and the one most consistently skipped, because the builder can always use their own product and mistakes that for evidence.
