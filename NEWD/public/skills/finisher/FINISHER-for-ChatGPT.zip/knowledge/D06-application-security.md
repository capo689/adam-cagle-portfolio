# Application Security

> Covers checks APPSEC-01..11. Domain D06, weight 9.

The 2025 OWASP Top 10 reordered around what actually happens: Broken Access Control first, Security Misconfiguration second, and a new **Software Supply Chain Failures** category third — voted the number one risk by half of surveyed practitioners. SSRF was folded into Broken Access Control, and a new category was added for **Mishandling of Exceptional Conditions**.

Access control lives in knowledge file `D01-auth-and-authorization.md`; supply chain in knowledge file `D07-supply-chain.md`. This file covers the rest.

---

## 1. Injection: structural prevention only

**SQL injection** is CWE-89, second on the 2025 CWE Top 25. Parameterize, always, without exception. An ORM handles this until someone reaches for a raw query — grep for those specifically.

The dynamic-identifier case is the one that catches people, because parameters cannot bind identifiers:

```ts
// Cannot parameterize a column name. Allowlist it.
const SORTABLE = new Set(["created_at", "name", "updated_at"]);
if (!SORTABLE.has(sort)) throw badRequest();
const rows = await sql`SELECT * FROM docs ORDER BY ${sql(sort)} LIMIT ${limit}`;
```

**Command injection** is CWE-78 at #9. Never pass user input to a shell. Use the array form of process spawning, never string concatenation, and never `shell: true`. If a filename must reach a command, validate it against a strict pattern first.

Also in the family: LDAP, XPath, template injection (a user-controlled template string in Jinja or Handlebars is remote code execution), and NoSQL operator injection (`{"$ne": null}` submitted where a string was expected).

## 2. Output encoding — the AI weak spot

This deserves its own emphasis because the data is stark. Veracode's longitudinal study of AI-generated code found models pass SQL-injection defense tests around 82% of the time, and **XSS defense tests around 15%**. Models learned to parameterize queries and never learned to encode output. XSS is CWE-79, first on the 2025 CWE Top 25.

**If you test one thing in an AI-built codebase, test output encoding.**

- Use the framework's automatic escaping and audit every escape hatch: `dangerouslySetInnerHTML`, `v-html`, `innerHTML`, `outerHTML`, `document.write`, `insertAdjacentHTML`, `{{{ }}}`.
- Sanitize rich text with DOMPurify — server-side, since client-side sanitization is bypassable.
- Encode for the specific context. HTML-escaping a value that lands in a JavaScript string or a URL does not protect it.
- Validate URL schemes before rendering user-supplied links — `javascript:` and `data:` are the payload.
- Markdown renderers must have raw HTML disabled, or the output must be sanitized.
- A strict CSP is your compensating control when encoding fails, which is why the two belong together.

```bash
grep -rn "dangerouslySetInnerHTML\|v-html\|innerHTML\s*=\|insertAdjacentHTML\|document.write" \
  --include="*.{ts,tsx,js,jsx,vue,svelte}" src/
```

Every hit needs a justification and a sanitizer.

## 3. Security headers

The current baseline, verified against the OWASP Secure Headers project:

```
Strict-Transport-Security: max-age=63072000; includeSubDomains
X-Content-Type-Options: nosniff
Referrer-Policy: no-referrer
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Resource-Policy: same-origin
X-Frame-Options: DENY
Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()
Content-Security-Policy: script-src 'nonce-{RANDOM}' 'strict-dynamic'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'
```

Notes that matter:

- **The strict, nonce-based CSP is the current recommendation**, not an allowlist of domains. Allowlist CSPs are routinely bypassable via JSONP endpoints and hosted script CDNs.
- The nonce must be **unique per response** and cryptographically random. Do not build middleware that auto-injects the nonce into every `<script>` tag — it will helpfully nonce the attacker's injected script too.
- Deploy with `Content-Security-Policy-Report-Only` first, collect violations for a week, then enforce. Going straight to enforcement breaks production.
- `frame-ancestors` supersedes `X-Frame-Options`, but keep sending both for older-browser compatibility. `ALLOW-FROM` is obsolete and causes the whole header to be ignored.
- **Do not set `X-XSS-Protection`.** It is deprecated and can itself introduce vulnerabilities. Use CSP.
- `Expect-CT` and HPKP are obsolete. Do not add them.
- HSTS preloading requires `max-age` of at least one year plus `includeSubDomains` and `preload`, and every subdomain — including internal ones — must serve HTTPS. Understand that before submitting; it is hard to undo.

Verify with `curl -I https://yourapp.com` and a header-scanning service.

## 4. CORS

The dangerous configuration is reflecting the request's `Origin` header while allowing credentials — that is a complete same-origin-policy bypass with extra steps.

```ts
const ALLOWED = new Set(["https://app.example.com", "https://admin.example.com"]);
app.use(cors({
  origin: (o, cb) => cb(null, !o || ALLOWED.has(o)),
  credentials: true,
  methods: ["GET", "POST", "PATCH", "DELETE"],
}));
```

`Access-Control-Allow-Origin: *` with credentials is rejected by browsers, which is the only reason more applications are not compromised by it. Never build the "reflect and allow" version.

## 5. CSRF

CSRF sits at #3 on the 2025 CWE Top 25 — unusually high, and a reminder that it did not go away when everyone adopted SPAs.

You need protection when the browser attaches credentials automatically, which means cookie-based sessions. `SameSite=Lax` blocks the classic cross-site form POST but does not cover everything: same-site subdomains, GET-triggered state changes, and older browsers. Add tokens for state-changing operations, or verify `Origin`/`Sec-Fetch-Site`.

Bearer tokens in an `Authorization` header are not automatically attached and so are not CSRF-vulnerable — but that trade buys you XSS-based token theft instead. Pick deliberately.

## 6. SSRF

Now part of A01 in the 2025 Top 10, and CWE-918 at #22. Anywhere your server fetches a URL the user influenced — webhooks, image imports, link previews, PDF rendering, RSS, avatar-by-URL — is a candidate.

Cloud metadata endpoints turn SSRF into credential theft, and harvesting instance metadata was a named behavior of the 2025 npm worms.

```ts
async function safeFetch(raw: string) {
  const url = new URL(raw);
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("scheme");
  if (!ALLOWED_HOSTS.has(url.hostname)) throw new Error("host");
  const { address } = await dns.promises.lookup(url.hostname);
  if (isPrivate(address)) throw new Error("private range");   // 10/8, 172.16/12, 192.168/16,
  return fetch(url, { redirect: "manual", signal: AbortSignal.timeout(5000) });
  //                  ^ each redirect hop must be re-validated
}
```

Three things people miss: DNS rebinding (resolve, validate, then connect to the validated address — or re-check after each redirect), IPv6 and IPv4-mapped forms of private ranges, and the metadata address specifically. Block egress at the network layer as well; application-layer validation is one bug away from failing.

## 7. Scanning

Layer it, and scan diffs rather than the whole repository on pull requests. A check that is red by default gets ignored within two weeks, at which point it is worse than nothing.

```bash
semgrep scan --config auto .                                 # SAST, free, no login
trivy fs --scanners vuln,secret,misconfig .                   # deps + secrets + IaC, one binary
osv-scanner scan source -r .                                  # dependency vulns
gitleaks git -v .                                             # secrets, full history
docker run -t ghcr.io/zaproxy/zaproxy:stable \
  zap-baseline.py -t https://staging.example.com              # DAST, passive
```

Placement:

| Stage | Where | Blocking |
|---|---|---|
| Secret scanning | pre-commit + CI + server-side push protection | yes, all three |
| SAST | pull request, diff-scoped | on new high/critical |
| Dependency scanning | pull request + nightly | on known-exploited; warn otherwise |
| IaC scanning | pull request | on high |
| Container scanning | build | on critical |
| DAST | nightly against staging | report only |

Baseline the existing findings rather than trying to zero them on day one. Block only on *new* high and critical. Prioritize by exploitability — KEV listing and EPSS score — rather than raw CVSS, or you will spend a week on a critical in a dev-only dependency.

Run active DAST scans against staging, never production. Passive baseline scans are safe anywhere.

## 8. Manual testing still finds what scanners cannot

No scanner reliably finds broken object-level authorization, because it requires understanding what the object means. The manual test scripts in knowledge file `X1-manual-test-scripts.md` are not optional supplements — they cover the highest-severity class in the entire catalog.

## 9. Threat model and disclosure

A one-page threat model beats none. For each high-value asset: who wants it, how they would reach it, what stops them, what would detect them. Use `knowledge file X5-operational-templates.md section `THREAT-MODEL.md``. Revisit when the architecture changes materially — especially when adding an integration, a file upload, or an agent with tools.

Publish `/.well-known/security.txt` with a monitored contact. Researchers who cannot reach you disclose publicly instead, and you find out from Twitter.
