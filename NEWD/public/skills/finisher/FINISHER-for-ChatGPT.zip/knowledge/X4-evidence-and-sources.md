# Evidence, Sources and Volatile Facts

Two jobs. **Part 1** cites every quantitative claim made anywhere in this skill, so a reader can
tell established evidence from summarised interpretation. **Part 2** lists the claims that are
date-sensitive by nature, with where to re-verify them.

If you are using this skill and a number matters to your argument, follow the link. If a source
here has been superseded, update this file — that is a legitimate contribution to the catalog.

All sources verified July 2026 unless noted.

---

# Part 1: Cited claims

## AI-generated code security

**"Roughly 45% of AI-generated code contains a vulnerability, and that has not improved."**
Veracode GenAI Code Security Report (July 2025) and Spring 2026 GenAI Code Security Update
(24 March 2026). Method: 80 coding tasks, 4 languages (Java, JS, C#, Python), 4 CWE classes,
5 instances per language-CWE pair, detected with Veracode SAST. 100+ models in 2025, 150+ by 2026.
Security pass rate ~55% in both, i.e. ~45% vulnerable; syntactic correctness rose above 95%.
- https://www.veracode.com/blog/genai-code-security-report/
- https://www.veracode.com/blog/spring-2026-genai-code-security/

**"XSS defense passes ~15%, log injection ~13%, SQL injection ~82%, insecure crypto ~86%."**
Same source, Spring 2026 update, per-CWE breakdown. By language: Python 62%, C# 58%, JavaScript 57%,
Java 29%. Reasoning-focused models reached 70–72% overall — better, still not production-acceptable.

**"Privilege escalation paths +322%, architectural design flaws +153%, syntax errors −76%,
logic bugs −60%, ~10x more security findings, ~2x exposed credentials."**
Apiiro, *4x Velocity, 10x Vulnerabilities* (September 2025). Method: tens of thousands of
repositories, several thousand developers at Fortune 50 organisations, December 2024 baseline
against June 2025. Reported at The Register, 5 September 2025.
- https://apiiro.com/blog/4x-velocity-10x-vulnerabilities-ai-coding-assistants-are-shipping-more-risks/
- https://www.theregister.com/2025/09/05/ai_code_assistants_security_problems/

**"Duplicated blocks +81%, moved code (refactoring proxy) 21% → 3.8%, copy/paste 9.4% → 15.7%,
cross-file function calls −35%."**
GitClear, *The Maintainability Gap: 2026 AI Code Quality Research*. Method: 623 million changed
lines of code, 2023 through 2026 year-to-date, eight quality signals.
- https://www.gitclear.com/the_ai_code_quality_maintainability_gap

**"Developers were 19% slower with AI assistance while predicting a 24% speedup, and still
believed afterwards they had been sped up by 20%."**
METR randomised controlled trial, published 10 July 2025. 16 experienced open-source developers,
246 real issues on repositories averaging 22k+ stars and 1M+ lines, ~2 hours per task, screen-recorded,
primarily Cursor Pro. Note the sample is small and the population specific (experienced developers on
codebases they already know well) — do not over-generalise it to all AI-assisted work.
- https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/

**"Developers with an AI assistant wrote less secure code and were more likely to believe it was
secure."** Perry, Srivastava, Kumar, Boneh, *Do Users Write More Insecure Code with AI Assistants?*
ACM CCS 2023.
- https://arxiv.org/abs/2211.03622

**"Package hallucination: ~5% for commercial models, up to 21.7% for open models, 205,474 unique
fabricated names, and ~43% of hallucinated names reproduced consistently across repeated runs."**
Spracklen et al., *We Have a Package for You!*, USENIX Security 2025. Method: 16 models, 576,000
code samples, Python and JavaScript, validated against PyPI and npm. The reproducibility figure is
the attack-enabling one: a stable hallucination can be predicted and pre-registered.
- https://arxiv.org/abs/2406.10279

**"An AI agent deleted a production database during a code freeze."**
Replit incident, July 2025. The agent made unauthorised changes to live infrastructure, deleted
production data, and initially gave incorrect recovery information. Remediation shipped afterwards
included automatic dev/production database separation and a planning-only mode.
- https://fortune.com/2025/07/23/ai-coding-tool-replit-wiped-database-called-it-a-catastrophic-failure

## Prompt injection and agent security

**"Above 90% attack success against published injection defenses under adaptive attack."**
*The Attacker Moves Second* (arXiv, 10 October 2025), 14 authors with OpenAI, Anthropic and Google
DeepMind participation. Tested 12 published defenses under adaptive rather than static attack;
most fell above 90%. A parallel human red-teaming exercise with 500 participants reached 100%.
Conclusion: static-example evaluation of injection defenses is close to meaningless.

**"78–93% defense bypass across six agentic coding platforms; detection-based defenses under 50%
mitigation."** *Prompt Injection Attacks on Agentic Coding Assistants*, arXiv:2601.17548 (2026).

**The lethal trifecta** — private data + untrusted content + external communication.
Simon Willison, 16 June 2025. https://simonwillison.net/2025/Jun/16/the-lethal-trifecta/

**The Agents Rule of Two** — at most two of: processes untrustworthy input, accesses sensitive
systems, can change state or communicate externally. Meta, 31 October 2025.

**Six design patterns for securing LLM agents** — action-selector, plan-then-execute, map-reduce,
dual LLM, code-then-execute, context minimisation. Beurer-Kellner, Debenedetti, Fischer, Tramèr,
Paverd et al., arXiv:2506.08837. The code-then-execute lineage includes CaMeL,
*Defeating Prompt Injections by Design*, arXiv:2503.18813 (Google DeepMind).
- https://arxiv.org/pdf/2506.08837 · https://arxiv.org/abs/2503.18813
- Summary: https://simonwillison.net/2025/Jun/13/prompt-injection-design-patterns/

**Real MCP and agent incidents** — GitHub MCP private repository exfiltration via an injected issue
(May 2025); Supabase/Cursor exfiltration via a support ticket (July 2025); CVE-2025-6514 in
`mcp-remote`, CVSS 9.6, arbitrary command execution (July 2025); Postmark-mimicking MCP package
silently BCC'ing all mail (September 2025).
- https://www.upguard.com/blog/mcp-security-incidents

## Standards and lists

**OWASP Top 10:2025** — A01 Broken Access Control, A02 Security Misconfiguration,
A03 Software Supply Chain Failures (new), A04 Cryptographic Failures, A05 Injection,
A06 Insecure Design, A07 Authentication Failures, A08 Software or Data Integrity Failures,
A09 Security Logging and Alerting Failures, A10 Mishandling of Exceptional Conditions (new).
Release candidate announced 6 November 2025 at Global AppSec Washington DC. SSRF was merged into
A01. A03 was ranked #1 by roughly half of community survey respondents.
- https://owasp.org/Top10/2025/ · https://owasp.org/Top10/2025/A03_2025-Software_Supply_Chain_Failures/

**CWE Top 25 (2025 edition)**, published 4 December 2025; CISA alert 11 December 2025.
Top five: CWE-79 XSS, CWE-89 SQL injection, CWE-352 CSRF, CWE-862 Missing Authorization,
CWE-787 out-of-bounds write. Also referenced in this skill: CWE-434 (#12, unrestricted upload),
CWE-770 (#25, allocation without limits), CWE-918 (#22, SSRF), CWE-78 (#9, OS command injection).
- https://cwe.mitre.org/data/definitions/1435.html
- https://www.cisa.gov/news-events/alerts/2025/12/11/2025-cwe-top-25-most-dangerous-software-weaknesses

**OWASP ASVS 5.0.0**, released 30 May 2025. ~350 requirements across 17 chapters. Level 1 was
deliberately reduced; Level 3 significantly expanded. Direct CWE mappings were removed.
- https://owasp.org/www-project-application-security-verification-standard/

**OWASP API Security Top 10** — current edition remains 2023. No 2025/2026 edition exists.
- https://owasp.org/API-Security/editions/2023/en/0x11-t10/

**OWASP Top 10 for LLM Applications (2025)** — LLM01 Prompt Injection, LLM02 Sensitive Information
Disclosure, LLM03 Supply Chain, LLM04 Data and Model Poisoning, LLM05 Improper Output Handling,
LLM06 Excessive Agency, LLM07 System Prompt Leakage, LLM08 Vector and Embedding Weaknesses,
LLM09 Misinformation, LLM10 Unbounded Consumption. https://genai.owasp.org/llm-top-10/

**OWASP Top 10 for Agentic Applications (2026)**, released 9–10 December 2025 — ASI01 Agent Goal
Hijack, ASI02 Tool Misuse, ASI03 Identity and Privilege Abuse, ASI04 Agentic Supply Chain,
ASI05 Unexpected Code Execution, ASI06 Memory and Context Poisoning, ASI07 Insecure Inter-Agent
Communication, ASI08 Cascading Failures, ASI09 Human-Agent Trust Exploitation, ASI10 Rogue Agents.
- https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/

**OWASP Secure Headers Project** — the header set and the deprecation of `X-XSS-Protection`,
`Expect-CT`, and HPKP. Machine-readable values:
- https://owasp.org/www-project-secure-headers/ci/headers_add.json
- CSP guidance: https://cheatsheetseries.owasp.org/cheatsheets/Content_Security_Policy_Cheat_Sheet.html

**Authentication, session, and secrets guidance** — OWASP Cheat Sheet Series. Note the cheat sheets
give no numeric access-token lifetime; any specific TTL in circulation is convention, not standard.
- https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html
- https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html
- https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html
- https://cheatsheetseries.owasp.org/cheatsheets/MCP_Security_Cheat_Sheet.html

## Accessibility

**"95.9% of the top million home pages had detected WCAG 2 failures; 56.1 errors per page on
average, up 10.1% year over year; six defect types account for ~96% of all detected errors."**
WebAIM Million, tested February 2026, Tranco top one million home pages, WAVE against the rendered
DOM. The six: low contrast text 83.9%, missing alt text 53.1%, missing form input labels 51%,
empty links 46.3%, empty buttons 30.6%, missing document language 13.5%.
- https://webaim.org/projects/million/

**"Automation catches ~20–30% of WCAG success criteria, representing ~57% of issue instances."**
The 57% figure is Deque's, measured across 2,000+ audits and ~13,000 pages using axe-core, and
counts *volume of issues*. The 20–30% figure is the traditional criteria-based benchmark. Both are
true and answer different questions.
- https://www.deque.com/blog/automated-testing-study-identifies-57-percent-of-digital-accessibility-issues/

## Supply chain incidents

**npm `chalk`/`debug` compromise, 8 September 2025** — maintainer phished via a fake npm 2FA-reset
email; 19 packages with roughly 2–3 billion combined weekly downloads; payload was a browser-side
crypto clipper. https://socket.dev/blog/npm-author-qix-compromised-in-major-supply-chain-attack

**Shai-Hulud worm, 16–23 September 2025** — first self-replicating npm worm, 500+ packages,
harvested cloud and GitHub credentials and republished itself. CISA alert 23 September 2025.
- https://www.cisa.gov/news-events/alerts/2025/09/23/widespread-supply-chain-compromise-impacting-npm-ecosystem

**Shai-Hulud 2.0, 24 November 2025** — 796 packages, 20M+ weekly downloads; used a `preinstall`
script under an alternative runtime to evade Node-based monitoring; harvested cloud instance
metadata. https://securitylabs.datadoghq.com/articles/shai-hulud-2.0-npm-worm/

**PyPI LiteLLM / Telnyx incident, 2 April 2026** — install-time credential harvester injected into
established packages. LiteLLM was exposed for 2 hours 32 minutes and downloaded 119,000+ times.
This is the specific evidence behind the dependency-cooldown recommendation.
- https://blog.pypi.org/posts/2026-04-02-incident-report-litellm-telnyx-supply-chain-attack/

## Testing practice

**Mutation testing as the honest measure of a test suite**, and the caution against complacency
with AI-generated code — Thoughtworks Technology Radar Vol. 34, April 2026. Mutation testing is
placed in Trial and called out specifically for evaluating AI-generated tests that may be
"logically hollow."
- https://www.thoughtworks.com/radar/techniques

**Testing trophy / "mostly integration"** — Kent C. Dodds. https://kentcdodds.com/blog/write-tests

---

# Part 2: Volatile facts — verify before relying on

Everything in this section was accurate when written and has a realistic chance of being wrong by
the time you read it. The skill's operating principle #12 exists because of this list.

| Claim | Where it appears | Verify at |
|---|---|---|
| npm 12 disables install scripts by default; `npm approve-scripts` is the allowlist mechanism | knowledge file `D07-supply-chain.md`, SUP-01 | `npm view npm dist-tags`, https://github.blog/changelog/ |
| Dependency cooldown flag names and units (`min-release-age` days, `minimumReleaseAge` minutes, `npmMinimalAgeGate`, `--uploaded-prior-to`, `--exclude-newer`) | knowledge file `D07-supply-chain.md`, SUP-03 | each package manager's own config docs |
| Dependabot default cooldown behaviour | knowledge file `D07-supply-chain.md` | https://docs.github.com/en/code-security/dependabot |
| OAuth 2.1 is a **draft**, not an RFC | knowledge file `D01-auth-and-authorization.md` | https://datatracker.ietf.org/doc/draft-ietf-oauth-v2-1/ |
| Prompt caching minimums, TTLs, and discount multipliers; batch API discounts | knowledge file `D14-ai-and-agents.md`, AI-11 | each provider's pricing and caching docs |
| EU AI Act obligation dates, including amendments | knowledge file `D14-ai-and-agents.md`, AI-13 | https://artificialintelligenceact.eu/ and the Official Journal |
| EU Cyber Resilience Act dates and SaaS scope | knowledge file `D07-supply-chain.md` | https://digital-strategy.ec.europa.eu/en/policies/cyber-resilience-act |
| US state privacy law count, thresholds, and universal opt-out requirements | knowledge file `D15-privacy-legal-compliance.md`, LEG-05 | state AG sites; IAPP tracker |
| PCI DSS version and which requirements are in force | knowledge file `D15-privacy-legal-compliance.md`, LEG-06 | https://www.pcisecuritystandards.org/ |
| Accessibility legal deadlines and exemptions by market | knowledge file `D15-privacy-legal-compliance.md`, LEG-09 | the relevant regulator |
| Subscription cancellation rules (litigated repeatedly) | LEG-07 | current regulator guidance |
| App store target API levels, privacy manifest requirements, payment and anti-steering rules, age rating systems | knowledge file `D17-mobile-and-app-store.md`, all MOB checks | Apple App Store Review Guidelines; Google Play policy centre |
| Core Web Vitals metric set and thresholds | knowledge file `D05-frontend-ux-accessibility.md`, FE-07 | https://web.dev/vitals/ |
| SBOM regulatory requirements (moving in different directions by jurisdiction) | knowledge file `D07-supply-chain.md`, SUP-08 | CISA; EU CRA; your contracts |
| Tool versions, flags, and free-tier limits throughout | knowledge file `X3-command-appendix.md` | each tool's repository |
| MCP specification version and authorization requirements | knowledge file `D14-ai-and-agents.md`, AI-14 | https://modelcontextprotocol.io/ |
| OpenTelemetry GenAI semantic conventions (not yet stable) | knowledge file `D10-observability.md`, AI tracing | https://opentelemetry.io/ |

## The rule that replaces guessing

When a check depends on one of these, the assessment should say so explicitly:

> *"MOB-04 scored 0 — the current required target API level was not verified against Google Play's
> policy page during this run. Verify before submission."*

That is more useful than a confident number derived from a stale document, and it is what the
coverage metric is for.

## On tool access and what an assistant can actually see

Do not assert what a given assistant can or cannot reach. Capability varies by product, tier,
connected tools, and configuration.

**Assume no runtime access unless a connected tool is present and its access has been verified in
this session.** A model with a browser tool, a GitHub connector, a database connector, or a shell
may well be able to reach a staging URL, a repository, a console, or a log stream. A model without
them cannot. Test the specific capability, state what was actually reachable, and score accordingly.
