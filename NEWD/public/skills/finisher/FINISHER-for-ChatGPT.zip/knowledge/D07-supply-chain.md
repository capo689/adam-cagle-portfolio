# Supply Chain and Dependency Integrity

> Covers checks SUP-01..09. Domain D07, weight 6.

**Software Supply Chain Failures entered the OWASP Top 10 in 2025 at A03**, and was ranked the number one risk by half the practitioners surveyed. That is not abstract: 2025 and 2026 produced a continuous run of registry compromises, including self-replicating worms that stole credentials and republished themselves through hundreds of packages.

The pattern that matters for your architecture: in the significant incidents, **compromise happened at install time, before any application code imported the package.** Your linting, your review, and your tests never ran. That single fact determines which defenses are worth building.

---

## 1. Kill install scripts — the highest-leverage control

`preinstall` and `postinstall` hooks were the execution vector in the major npm incidents. Disabling them defeats most of that class outright.

```bash
# npm 12+ disables install scripts by default; approve only what genuinely needs to build
npm approve-scripts --allow-scripts-pending     # then COMMIT the allowlist in package.json

# older npm
npm ci --ignore-scripts

# pnpm: onlyBuiltDependencies in pnpm-workspace.yaml
# yarn: enableScripts: false in .yarnrc.yml
```

An allowlist is strictly better than blanket disabling: native modules still build, but only for packages you named and reviewed. Check `npm view npm dist-tags` for the current release line before assuming a default.

## 2. Frozen, reproducible installs

```bash
npm ci                      # not `npm install` — errors on lockfile drift, never rewrites it
pnpm install --frozen-lockfile
yarn install --immutable
uv sync --frozen
pip install --require-hashes -r requirements.txt
```

Commit the lockfile. A floating install lets a compromised version enter with zero change to your repository — nothing to review, nothing to diff.

Yarn's hardened mode additionally validates the lockfile against the registry, which catches malicious *lockfile edits* — a vector frozen installs alone do not cover.

## 3. Cooldown: do not install code published this morning

In the March 2026 PyPI incident, a malicious version of a widely-used package was live for about two and a half hours and was downloaded over 119,000 times. A three-day delay would have caught it entirely.

```ini
# .npmrc  — units are DAYS
min-release-age=3
```
```yaml
# pnpm-workspace.yaml — units are MINUTES
minimumReleaseAge: 4320
minimumReleaseAgeStrict: true
```
```yaml
# .yarnrc.yml
npmMinimalAgeGate: "1w"
enableHardenedMode: true
enableScripts: false
```
```bash
uv sync --exclude-newer 2026-07-22
pip install --uploaded-prior-to P3D -r requirements.txt
```

Dependabot applies a default cooldown, configurable per severity, and **security updates bypass it** — which is the right behavior. Verify current flag names and defaults against the tool's documentation; this area is moving fast.

## 4. Verify the dependency exists and is the one you meant

**Slopsquatting** is the attack this defends against. Research presented at USENIX Security 2025, over 576,000 generated code samples, found commercial models hallucinate package names about 5% of the time and open-source models up to 21.7%, producing more than 205,000 unique fabricated names.

The detail that makes it exploitable: **around 43% of hallucinated names are reproduced consistently across repeated runs.** The hallucination is stable, so an attacker can predict the name and register it. Real cases exist where a fabricated package name accumulated tens of thousands of downloads.

For every dependency an AI added:

- Does it exist and is it the package you actually meant (`dayjs`, not `easy-day-js`)?
- Publish date, download count, repository link, maintainer history
- Is it a recently created package with a plausible name? That is the signature.
- Does the repository link actually resolve to real, corresponding source?

A useful CI check: assert that every newly added dependency was first published before the pull request was opened.

## 5. Scan, and prioritize by exploitability

```bash
trivy fs --scanners vuln,secret,misconfig .
osv-scanner scan source -r .
npm audit --audit-level=high --omit=dev
npm audit signatures --include-attestations   # verifies registry signatures and provenance
```

`npm audit signatures` is underused and directly relevant: it verifies registry signatures and provenance attestations, which is the concrete control for the new A03 category.

Scan on pull requests **and** on a schedule — new CVEs land against code that has not changed. Prioritize by KEV listing and EPSS score rather than CVSS alone; a critical in a build-only dev dependency is not the same as a high in your request path.

## 6. Harden CI

The 2026 incident record is full of compromises that ran through CI rather than through the application.

**Pin actions to full commit SHAs.** Tags are mutable and controlled by someone else.

```yaml
- uses: actions/checkout@a81bbbf8298c0fa03ea29cdc473d45aeea3b3e7f  # v4.1.7
```

**Least-privilege tokens.**

```yaml
permissions:
  contents: read          # workflow-level floor
jobs:
  deploy:
    permissions:
      contents: read
      id-token: write     # escalate per job, only where needed
```

**Never interpolate untrusted event data into a shell.** `${{ }}` is substituted before the shell sees it, so a pull request title is executable code:

```yaml
# vulnerable
run: echo "${{ github.event.pull_request.title }}"

# correct
env:
  TITLE: ${{ github.event.pull_request.title }}
run: echo "$TITLE"
```

Treat as hostile: issue and PR titles and bodies, comment bodies, review bodies, commit messages, author names and emails, and branch names.

**`pull_request_target` is privileged.** It has repository write access and secrets. Checking out the PR head and building it in that context is complete compromise. Correct pattern: build and test untrusted code under plain `pull_request` with no secrets and a read-only token, upload an artifact, and consume it in a separate privileged `workflow_run` job.

**Protect the workflow files themselves.** `.github/workflows/` in CODEOWNERS with required review is the specific control for the most common CI compromise path.

Run OpenSSF Scorecard for an honest baseline — `Token-Permissions`, `Pinned-Dependencies`, `Dangerous-Workflow`, and `Branch-Protection` map directly to real attack paths:

```bash
docker run -e GITHUB_AUTH_TOKEN=$TOKEN ghcr.io/ossf/scorecard:stable \
  --show-details --repo=https://github.com/org/repo
```

## 7. SBOM and provenance

Generate an SBOM at build time from the build context, not by scanning a finished image afterwards — a post-hoc scan misses build-time-only dependencies and loses provenance linkage.

```bash
syft ./my-project -o cyclonedx-json=sbom.cdx.json
trivy fs --format cyclonedx --output sbom.cdx.json .
npm sbom --sbom-format cyclonedx > sbom.cdx.json
```

Store it with the release. The practical value is speed of answer: when the next worm lands, "are we affected" becomes a grep instead of an afternoon.

If you publish artifacts, attach signed provenance:

```yaml
permissions: { id-token: write, contents: read, attestations: write }
steps:
  - uses: actions/attest-build-provenance@<sha>
    with: { subject-path: 'dist/*' }
```
```bash
gh attestation verify ./dist/app -R org/repo
cosign verify ghcr.io/org/app@sha256:... \
  --certificate-identity-regexp="^https://github\.com/org/repo/\.github/workflows/.+" \
  --certificate-oidc-issuer="https://token.actions.githubusercontent.com"
```

Publishing to npm or PyPI: use **trusted publishing** (OIDC) rather than a long-lived publish token. Under trusted publishing on the major CI platforms, provenance attestations are generated automatically.

Be honest about the limits — some 2026 attacks defeated OIDC by modifying workflow files directly or extracting tokens from runner memory. Trusted publishing raises the bar substantially; it is not a terminus. That is why CODEOWNERS on workflow files matters as much as the publishing mechanism.

## 8. Regulatory pressure

Requirements around SBOM, vulnerability reporting, and product security obligations are in active flux across jurisdictions, with different instruments moving in different directions. **Verify current obligations against primary sources** rather than trusting any checklist, including this one.

The durable advice regardless of regime: be able to produce an SBOM on request, have a named contact and process for handling a reported vulnerability, and be able to state within a day whether a given CVE affects your product.
