#!/usr/bin/env python3
"""Test suite for the FINISHER scoring engine. Run: python3 scripts/test_finisher_score.py"""
import importlib.util, json, os, shutil, subprocess, sys, tempfile, builtins

HERE = os.path.dirname(os.path.abspath(__file__))
def _find_catalog():
    for c in (os.environ.get("FINISHER_CATALOG"),
              os.path.join(HERE, "checks.yaml"),
              os.path.join(HERE, "..", "assets", "checks.yaml"),
              os.path.join(os.getcwd(), "checks.yaml")):
        if c and os.path.exists(c):
            return os.path.normpath(c)
    raise SystemExit("checks.yaml not found next to the tests or in ../assets/")


CATALOG = _find_catalog()


def load(block_yaml=False):
    real = builtins.__import__
    def fake(n, *a, **k):
        if block_yaml and n == "yaml":
            raise ImportError("blocked")
        return real(n, *a, **k)
    builtins.__import__ = fake
    try:
        spec = importlib.util.spec_from_file_location(f"fs{block_yaml}",
                                                      os.path.join(HERE, "finisher_score.py"))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
    finally:
        builtins.__import__ = real
    return m


M = load()
CAT = M.validate_catalog(M.load_yaml(CATALOG), CATALOG)
CAT["_path"], CAT["_hash"] = CATALOG, M.file_sha(CATALOG)
FAILS = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + (f"  [{detail}]" if detail and not cond else ""))
    if not cond:
        FAILS.append(name)


def state(context, checks=None):
    return {"context": context, "checks": checks or {}}


def run(*argv, cwd=None):
    return subprocess.run([sys.executable, os.path.join(HERE, "finisher_score.py"), *argv],
                          capture_output=True, text=True, cwd=cwd)


print("\n== catalog integrity ==")
check("catalog validates", True)
check("no unused conditions", not (set(CAT["conditions"]) - {
    c for chk in CAT["checks"] for c in
    ((chk["when"] if isinstance(chk["when"], list) else [chk["when"]]))} - {"always"}
    - {w for d in CAT["domains"] for w in d["when"]}),
    "unused: " + str(sorted(set(CAT["conditions"]) - {
        str(c).lstrip("!") for chk in CAT["checks"] for c in
        (chk["when"] if isinstance(chk["when"], list) else [chk["when"]])}
        - {str(w).lstrip("!") for d in CAT["domains"] for w in d["when"]})))
check("all domains have checks",
      all(any(c["domain"] == d["id"] for c in CAT["checks"]) for d in CAT["domains"]))

print("\n== applicability is fail-closed ==")
inc, assumed = M.applies(["has_payments"], {})
check("absent condition INCLUDES the check", inc is True)
check("absent condition is flagged assumed", assumed is True)
check("explicit false EXCLUDES", M.applies(["has_payments"], {"has_payments": False})[0] is False)
check("explicit true includes, not assumed", M.applies(["has_payments"], {"has_payments": True}) == (True, False))
r = M.compute(CAT, state({"has_users": True}))
check("assumed conditions surfaced in result", len(r["assumed_conditions"]) > 0)
check("assumed checks listed", len(r["assumed_checks"]) > 0)
p0_all = sum(1 for c in CAT["checks"] if c["tier"] == "P0")
check("empty context keeps every P0 in scope", len(r["open"]["P0"]) == p0_all,
      f"{len(r['open']['P0'])} of {p0_all}")

print("\n== scoring math ==")
full = {c["id"]: {"score": 4, "evidence": "e", "artifact": "tests/x.spec.ts::y",
                  "enforcement": "CI job gate"} for c in CAT["checks"]}
ctx = {k: True for k in CAT["conditions"]}
r = M.compute(CAT, state(ctx, full))
check("all-4s scores 100", r["composite"] == 100.0, str(r["composite"]))
check("all-4s has no open blockers", not any(r["open"].values()))
r0 = M.compute(CAT, state(ctx, {c["id"]: {"score": 0} for c in CAT["checks"]}))
check("all-0s scores 0", r0["composite"] == 0.0)
check("all-0s capped at 39", r0["cap"] == 39)
one_p0 = dict(full)
p0id = next(c["id"] for c in CAT["checks"] if c["tier"] == "P0")
one_p0[p0id] = {"score": 2, "evidence": "partial"}
r1 = M.compute(CAT, state(ctx, one_p0))
check("one open P0 caps composite at 39", r1["composite"] == 39.0, str(r1["composite"]))
check("uncapped score still reported high", r1["raw_composite"] > 90, str(r1["raw_composite"]))
check("N/A checks leave the denominator",
      M.compute(CAT, state(ctx, {**full, p0id: {"na": True, "na_reason": "x"}}))["applicable_checks"]
      == r["applicable_checks"] - 1)

print("\n== coverage semantics ==")
c0 = {c["id"]: {"score": 0} for c in CAT["checks"]}
check("bare zeros count as unassessed", M.compute(CAT, state(ctx, c0))["coverage"] == 0.0)
c0e = {c["id"]: {"score": 0, "evidence": "looked; genuinely absent"} for c in CAT["checks"]}
check("documented zeros count as assessed", M.compute(CAT, state(ctx, c0e))["coverage"] == 100.0)
c0a = {c["id"]: {"score": 0, "assessed": True} for c in CAT["checks"]}
check("assessed:true counts", M.compute(CAT, state(ctx, c0a))["coverage"] == 100.0)

print("\n== validation ==")
def errs(st):
    return M.validate(CAT, st)[0]
check("score 2 without evidence errors",
      any("requires evidence" in e for e in errs(state(ctx, {p0id: {"score": 2}}))))
check("score 3 without artifact errors",
      any("artifact" in e for e in errs(state(ctx, {p0id: {"score": 3, "evidence": "e"}}))))
check("score 4 without enforcement errors",
      any("enforcement" in e for e in errs(state(ctx, {p0id: {"score": 4, "evidence": "e",
                                                              "artifact": "t/x.ts"}}))))
check("na on applicable P0 is an ERROR",
      any("says it APPLIES" in e for e in errs(state(ctx, {p0id: {"na": True, "na_reason": "later"}}))))
p2id = next(c["id"] for c in CAT["checks"] if c["tier"] == "P2")
w = M.validate(CAT, state(ctx, {p2id: {"na": True, "na_reason": "later"}}))
check("na on applicable P2 is only a WARNING",
      not any("says it APPLIES" in e for e in w[0]) and any("says it APPLIES" in x for x in w[1]))
check("na without reason errors",
      any("na_reason" in e for e in errs(state(ctx, {p0id: {"na": True}}))))
check("string score is a clean error, not a crash",
      any("must be a number" in e for e in errs(state(ctx, {p0id: {"score": "three"}}))))
check("score 9 is a clean error",
      any("integer 0-4" in e for e in errs(state(ctx, {p0id: {"score": 9}}))))
check("undocumented zero warns about coverage",
      any("UNASSESSED" in x for x in M.validate(CAT, state(ctx, {p0id: {"score": 0}}))[1]))
check("unset condition warns", any("is unset" in x for x in M.validate(CAT, state({}, {}))[1]))

print("\n== actions file robustness ==")
with tempfile.TemporaryDirectory() as td:
    p = os.path.join(td, "a.json")
    open(p, "w").write('[{"AUTH-01": "x"}]')
    try:
        M.load_actions(p); ok = False
    except M.FinisherError as e:
        ok = "must be a JSON object" in str(e)
    check("JSON array actions -> clean error, not AttributeError", ok)
    open(p, "w").write('{"summary":"s","actions":{"AUTH-01":"did a thing"}}')
    a, n = M.load_actions(p)
    check("well-formed actions parse", a == {"AUTH-01": "did a thing"} and n == "s")
    open(p, "w").write("{not json")
    try:
        M.load_actions(p); ok = False
    except M.FinisherError:
        ok = True
    check("malformed actions JSON -> clean error", ok)

print("\n== markdown escaping ==")
check("pipes escaped", M.cell("a|b") == "a\\|b")
check("newlines collapsed", "\n" not in M.cell("a\nb"))
check("long text truncated", len(M.cell("x" * 500)) <= 160)

print("\n== end to end ==")
with tempfile.TemporaryDirectory() as td:
    ctxf = os.path.join(td, "ctx.json")
    json.dump({"has_users": True, "is_public": True, "has_pii": True}, open(ctxf, "w"))
    fdir = os.path.join(td, "finisher")
    sfile = os.path.join(fdir, "state.json")
    r = run("init", "--catalog", CATALOG, "--context", ctxf, "-o", sfile, cwd=td)
    check("init succeeds", r.returncode == 0, r.stderr)
    check("init reports assumed conditions", "treated as APPLICABLE" in r.stdout)

    st = json.load(open(sfile))
    for cid in list(st["checks"]):
        if not st["checks"][cid]["na"]:
            st["checks"][cid].update(score=3, evidence="ok", artifact="tests/x.spec.ts::y")
    json.dump(st, open(sfile, "w"))
    af = os.path.join(td, "act.json")
    json.dump({"summary": "pipes | and\nnewlines", "actions": {"AUTH-01": "a | b\nc"}}, open(af, "w"))

    r = run("commit", "--catalog", CATALOG, "--state", sfile, "--dir", fdir,
            "--run-id", "r1", "--actions", af, cwd=td)
    check("commit succeeds", r.returncode == 0, r.stderr)
    check("SCORE.md written", os.path.exists(os.path.join(fdir, "SCORE.md")))
    check("state snapshot written", os.path.exists(os.path.join(fdir, "runs", "r1.state.json")))
    led = [json.loads(l) for l in open(os.path.join(fdir, "ledger.jsonl"))]
    check("ledger records context", led[0]["context"] == {"has_users": True, "is_public": True,
                                                          "has_pii": True})
    check("ledger records hashes", all(k in led[0] for k in
                                       ("context_hash", "catalog_hash", "state_hash")))
    report = open(os.path.join(fdir, "runs", "r1.md")).read()
    check("report table rows are not broken by pipes", "a \\| b c" in report)

    r = run("commit", "--catalog", CATALOG, "--state", sfile, "--dir", fdir, "--run-id", "r1", cwd=td)
    check("duplicate run-id rejected", r.returncode == 1 and "already exists" in r.stderr, r.stderr)

    st["context"]["has_payments"] = True
    json.dump(st, open(sfile, "w"))
    r = run("commit", "--catalog", CATALOG, "--state", sfile, "--dir", fdir, "--run-id", "r2", cwd=td)
    led = [json.loads(l) for l in open(os.path.join(fdir, "ledger.jsonl"))]
    check("context change flagged as scope change", led[1]["scope_changed"] is True)
    check("scope change suppresses the delta", "not computed" in
          open(os.path.join(fdir, "runs", "r2.md")).read())

    st["checks"][p0id] = {"score": 4, "evidence": "e", "artifact": "t.ts", "enforcement": ""}
    json.dump(st, open(sfile, "w"))
    before = len(open(os.path.join(fdir, "ledger.jsonl")).readlines())
    r = run("commit", "--catalog", CATALOG, "--state", sfile, "--dir", fdir,
            "--run-id", "bad", "--force", cwd=td)
    after = len(open(os.path.join(fdir, "ledger.jsonl")).readlines())
    check("--force does not touch the authoritative ledger", before == after)
    check("--force writes an UNOFFICIAL report",
          os.path.exists(os.path.join(fdir, "unofficial", "bad-UNOFFICIAL.md")))
    check("--force report is marked unofficial",
          "UNOFFICIAL RUN" in open(os.path.join(fdir, "unofficial", "bad-UNOFFICIAL.md")).read())
    check("--force exits non-zero", r.returncode == 2)

    open(os.path.join(fdir, "ledger.jsonl"), "a").write("{corrupt\n")
    r = run("history", "--dir", fdir, cwd=td)
    check("history survives a corrupt ledger line with a warning",
          r.returncode == 0 and "corrupt ledger line" in r.stderr)

print("\n== catalog auto-resolution (flat upload layout) ==")
with tempfile.TemporaryDirectory() as td:
    shutil.copy(os.path.join(HERE, "finisher_score.py"), td)
    shutil.copy(CATALOG, os.path.join(td, "checks.yaml"))
    json.dump({"has_users": True}, open(os.path.join(td, "ctx.json"), "w"))
    r = subprocess.run([sys.executable, "finisher_score.py", "init", "--context", "ctx.json",
                        "-o", "state.json"], capture_output=True, text=True, cwd=td)
    check("scorer finds checks.yaml beside itself with no --catalog",
          r.returncode == 0 and "applicable checks" in r.stdout, r.stderr)

print("\n== fallback YAML parser (no PyYAML) ==")
MF = load(block_yaml=True)
catf = MF.load_yaml(CATALOG)
check("fallback parses every check", len(catf["checks"]) == len(CAT["checks"]))
check("fallback and PyYAML agree on scores",
      MF.compute(catf, state(ctx, full))["composite"] == r"" or
      MF.compute(catf, state(ctx, full))["composite"] == M.compute(CAT, state(ctx, full))["composite"])
with tempfile.TemporaryDirectory() as td:
    bad = os.path.join(td, "bad.yaml")
    open(bad, "w").write("meta:\n  a: 1\nthis line has no colon\n")
    try:
        MF.load_yaml(bad); ok = False
    except MF.FinisherError:
        ok = True
    check("fallback RAISES on unparseable content instead of skipping", ok)

print("\n== catalog drift and migration ==")
with tempfile.TemporaryDirectory() as td:
    ctxf = os.path.join(td, "ctx.json"); json.dump({"has_users": True}, open(ctxf, "w"))
    sfile = os.path.join(td, "state.json")
    run("init", "--catalog", CATALOG, "--context", ctxf, "-o", sfile, cwd=td)
    st = json.load(open(sfile))
    removed = sorted(st["checks"])[:3]
    for cid in removed:
        del st["checks"][cid]
    st["checks"]["GHOST-99"] = {"score": 4, "evidence": "e", "artifact": "a", "enforcement": "CI job"}
    st["catalog_hash"] = "deadbeefdeadbeef"; st["catalog_version"] = "0.9.0"
    json.dump(st, open(sfile, "w"))
    d = M.catalog_drift(CAT, json.load(open(sfile)))
    check("drift detects a changed catalog hash", d["hash_changed"] is True)
    check("drift lists checks missing from state", set(removed) <= set(d["missing_from_state"]))
    check("drift lists stale state entries", d["stale_in_state"] == ["GHOST-99"])
    r = run("validate", "--catalog", CATALOG, "--state", sfile, cwd=td)
    check("validate warns about catalog mismatch", "CATALOG MISMATCH" in r.stdout)
    r = run("commit", "--catalog", CATALOG, "--state", sfile, "--dir", os.path.join(td, "f"),
            "--run-id", "x", cwd=td)
    check("commit refuses a state missing catalog checks",
          r.returncode == 1 and "CATALOG MISMATCH" in r.stdout)
    r = run("migrate", "--catalog", CATALOG, "--state", sfile, cwd=td)
    check("migrate succeeds", r.returncode == 0 and "check(s) added" in r.stdout, r.stderr)
    d2 = M.catalog_drift(CAT, json.load(open(sfile)))
    check("migrate closes the gap", not d2["hash_changed"] and not d2["missing_from_state"])
    check("migrate flags stale entries rather than deleting data",
          "[not in current catalog]" in json.load(open(sfile))["checks"]["GHOST-99"]["notes"])
    r = run("commit", "--catalog", CATALOG, "--state", sfile, "--dir", os.path.join(td, "f"),
            "--run-id", "x", cwd=td)
    check("commit proceeds after migrate", r.returncode == 0, r.stdout + r.stderr)

print("\n== context template safety ==")
with tempfile.TemporaryDirectory() as td:
    allfalse = os.path.join(td, "c.json")
    json.dump({k: False for k in CAT["conditions"]}, open(allfalse, "w"))
    r = run("init", "--catalog", CATALOG, "--context", allfalse, "-o",
            os.path.join(td, "s.json"), cwd=td)
    check("all-false context is rejected", r.returncode == 1 and "every condition" in r.stderr)
    r = run("init", "--catalog", CATALOG, "--context", allfalse, "--allow-empty-context",
            "-o", os.path.join(td, "s.json"), cwd=td)
    check("--allow-empty-context permits it deliberately", r.returncode == 0)
    shipped = os.path.join(HERE, "..", "assets", "context.template.json")
    if os.path.exists(shipped):
        tmpl = json.load(open(shipped))
        check("shipped context template sets no conditions",
              not any(k in CAT["conditions"] for k in tmpl))

print("\n== crash recovery and concurrency ==")
with tempfile.TemporaryDirectory() as td:
    ctxf = os.path.join(td, "ctx.json"); json.dump({"has_users": True}, open(ctxf, "w"))
    sfile = os.path.join(td, "state.json"); fdir = os.path.join(td, "f")
    run("init", "--catalog", CATALOG, "--context", ctxf, "-o", sfile, cwd=td)
    st = json.load(open(sfile))
    for cid in st["checks"]:
        if not st["checks"][cid]["na"]:
            st["checks"][cid].update(score=3, evidence="e", artifact="tests/x.spec.ts")
    json.dump(st, open(sfile, "w"))
    run("commit", "--catalog", CATALOG, "--state", sfile, "--dir", fdir, "--run-id", "ok1", cwd=td)
    # simulate a crash after staging but before the ledger append
    orphan = os.path.join(fdir, "runs", "never-committed.md" + M.PENDING)
    open(orphan, "w").write("staged but never committed")
    # and a crash after the ledger append but before promotion
    led = [json.loads(l) for l in open(os.path.join(fdir, "ledger.jsonl"))]
    os.replace(os.path.join(fdir, "runs", "ok1.md"), os.path.join(fdir, "runs", "ok1.md" + M.PENDING))
    M.promote_pending(fdir)
    check("orphan from a pre-commit crash is discarded", not os.path.exists(orphan))
    check("staged file for a committed run is promoted",
          os.path.exists(os.path.join(fdir, "runs", "ok1.md")))
    lock = os.path.join(fdir, ".commit.lock")
    open(lock, "w").write("99999")
    r = run("commit", "--catalog", CATALOG, "--state", sfile, "--dir", fdir,
            "--run-id", "blocked", cwd=td)
    check("a held lock blocks a concurrent commit",
          r.returncode == 1 and "could not acquire" in r.stderr)
    os.unlink(lock)

print("\n== shipped schemas ==")
sd = os.path.join(HERE, "..", "assets", "schemas")
if os.path.isdir(sd):
    for f in ("context.schema.json", "state.schema.json", "actions.schema.json",
              "ledger-entry.schema.json"):
        try:
            j = json.load(open(os.path.join(sd, f))); ok = "$schema" in j and "properties" in j
        except Exception:
            ok = False
        check(f"{f} is valid JSON Schema-shaped", ok)
    ctx_schema = json.load(open(os.path.join(sd, "context.schema.json")))
    check("context schema covers every catalog condition",
          set(CAT["conditions"]) <= set(ctx_schema["properties"]))

print(f"\n{'ALL TESTS PASSED' if not FAILS else str(len(FAILS)) + ' FAILURE(S): ' + ', '.join(FAILS)}")
sys.exit(1 if FAILS else 0)
