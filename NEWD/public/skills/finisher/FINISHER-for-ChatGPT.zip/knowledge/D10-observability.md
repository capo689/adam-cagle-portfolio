# Observability and Error Tracking

> Covers checks OBS-01..07. Domain D10, weight 7.

**A09:2025 is Security Logging and Alerting Failures.** The name changed from "monitoring" to "alerting" for a reason: collecting telemetry nobody looks at is not observability. The test is whether the system tells a human that something is wrong before a customer does.

---

## 1. Error tracking first

This is the single highest-value hour in the domain. Install Sentry or an equivalent on both frontend and backend, upload source maps, and tag releases.

Without release tagging and source maps you get minified stack traces with no version, which is roughly as useful as knowing that something, somewhere, broke.

Then reduce the noise immediately, or the tool becomes wallpaper:

- Filter browser extension errors and known third-party script noise
- Group by fingerprint so one bug is one issue
- **Alert on new issue types and on rate spikes, not on every occurrence**
- Scrub request bodies and headers — error trackers attach them by default and that is how personal data ends up in a third-party system

## 2. Structured logs with a correlation ID

Unstructured logs are unsearchable at exactly the moment you need them.

```json
{"ts":"2026-07-25T14:03:11Z","level":"error","request_id":"01J...","trace_id":"4bf9...",
 "route":"POST /api/orders","user_id":"u_123","account_id":"a_456","status":500,
 "duration_ms":842,"release":"a1b2c3d","msg":"payment authorization failed",
 "provider":"stripe","error_code":"card_declined"}
```

The property that makes logs useful is being able to reconstruct one request end to end. Generate a request ID at the edge, propagate it through every internal call, into background jobs, and out to third parties where the protocol allows. Then a support ticket becomes a query.

Discipline:

- One level per meaning — `error` means someone should look, `warn` means it is notable, `info` is the audit trail of what happened
- Never log secrets, tokens, full request bodies, or personal data beyond stable identifiers
- Sample high-volume `info` logs; never sample errors
- Set retention deliberately; log ingestion cost scales with success and surprises people

## 3. Alerts that are worth waking up for

The rule that keeps alerting healthy: **alert on symptoms users experience, not on causes.** High CPU is a cause and may be fine. Checkout failing is a symptom and is never fine.

A reasonable starting set:

| Alert | Condition | Why |
|---|---|---|
| Error rate spike | 5xx rate exceeds baseline over a short window | Broad breakage |
| Latency degradation | p95 above threshold for several minutes | Users are feeling it |
| Uptime failure | Synthetic check fails twice consecutively | Total outage |
| Payment failures | Failed charges above normal rate | Revenue plus a possible integration break |
| Job failure / DLQ depth | Any dead-letter growth | Silent work stoppage |
| Queue age | Oldest message older than threshold | Workers not keeping up |
| Spend anomaly | Daily spend above expected | Runaway loop or abuse |
| Certificate expiry | Within 14 days | Preventable total outage |
| Backup failure | Any failed backup job | Discovery-during-incident prevention |
| Auth failure spike | Failed logins above baseline | Credential stuffing |

Every alert must be actionable. If it fires and the response is "yeah, that happens," delete it or fix the threshold. Alert fatigue is not a personality flaw, it is a design failure, and it ends with the real alert being ignored.

Route to somewhere that produces a notification on a phone. An email to a shared inbox is not an alert.

## 4. Health checks

Three distinct things, commonly conflated:

- **Liveness** — is the process running? Cheap, no dependencies. The orchestrator restarts on failure, so it must not depend on a database that might be briefly slow.
- **Readiness** — can this instance serve traffic? Checks critical dependencies. Failure removes it from the load balancer.
- **Deep health** — a real end-to-end check, run by synthetic monitoring, not by the load balancer.

A health check that returns 200 while the database is unreachable is worse than none: it actively suppresses the alert. But a liveness check that fails on a transient database blip causes a restart storm. Keep them separate.

Add a synthetic check that performs an actual login and a core action on a schedule from outside your infrastructure. That is the check that catches "the site is up but nobody can sign in."

## 5. Tracing

Once there are more than about three hops — edge, app, database, queue, third party, inference — "it is slow" becomes unanswerable without traces.

OpenTelemetry auto-instrumentation gets you most of the way for Node and Python with very little code. Instrument database calls, external HTTP, job execution, and model calls. Sample: keep all errors and slow requests, sample the rest.

For AI features specifically, the emerging OpenTelemetry GenAI semantic conventions are useful and **not yet stable** — attribute names are still changing. Instrument anyway; renaming attributes later is much cheaper than not having the data.

## 6. Product analytics

System health and product health are different questions. Green dashboards with zero activation is the most common launch outcome for a technically sound product.

Instrument the funnel: signup started, signup completed, activation (whatever "they got value" means for your product), core action repeated, conversion. Define these before launch, because retrofitting a funnel means waiting another month for data.

Respect consent requirements — in several jurisdictions non-essential analytics must not fire before the user opts in, and "we set the cookie then asked" is the violation.

## 7. What good looks like

The two tests that matter for this domain:

1. **You learn about outages from your monitoring, not from a customer.** Check the last three incidents: how did you find out?
2. **A bug report can be traced to a request, route, release, and user context in under five minutes.** Try it with a real support ticket.

If both are true, the domain is at level 3 or better regardless of which tools you used.
