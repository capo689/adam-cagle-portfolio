# Testing and Verification

> Covers checks TEST-01..08. Domain D16, weight 6.

The evidence on AI-generated code points somewhere specific: **shallow defects are down sharply and structural defects are up sharply.** One large-scale enterprise study found syntax errors down 76% and logic bugs down 60% in AI-assisted repositories, alongside a roughly tenfold increase in security findings — privilege escalation paths up 322% and architectural design flaws up 153%.

That reshapes what to test. AI reliably produces plausible code and unreliably produces correct *wiring* — authorization checks, transaction boundaries, error paths, idempotency, N+1 access patterns. Those are integration-level defects, which means an integration-heavy strategy is not a stylistic preference here. It is aimed at where the bugs actually are.

---

## 1. What to test, in order

1. **Authorization on every endpoint.** The highest-value suite in an AI-built codebase, because missing authorization is the most common and most damaging omission.
2. **Money and state-mutating paths.** Payments, writes, deletes, idempotency.
3. **Multi-tenant isolation.** Can user A read user B's rows, in every query path including list, detail, search, and export?
4. **The three to six journeys that would put you on the phone with customers**, as end-to-end tests.
5. **Input validation at trust boundaries.**

Everything else is optional until those exist.

## 2. The authorization matrix

```ts
const ACTORS = [anonymous, otherUser, otherTenant, viewerRole, adminRole];

for (const ep of routerEndpoints()) {          // derived from the router, not hand-listed
  for (const actor of ACTORS) {
    it(`${ep.method} ${ep.path} :: ${actor.name}`, async () => {
      const res = await call(ep, actor);
      const expected = expectedStatus(ep, actor);
      expect(res.status).toBe(expected);
      if (expected !== 200) expect(JSON.stringify(res.body)).not.toContain(ep.fixtureSecret);
    });
  }
}
```

Two properties make this a level-4 control rather than a level-3 one:

- The endpoint list is **derived from the router**, so adding an unprotected route fails the build.
- It asserts on the **response body** too, not just the status. A 403 that still returns the object in an error payload is still a leak.

## 3. Coverage is a weak metric, and weaker here

Coverage measures execution, not assertion. AI-generated tests are disproportionately prone to executing code with vacuous or tautological assertions — inflating coverage while detecting nothing.

Two adjustments:

- **Gate on diff coverage**, not a global percentage. "New and changed lines at least X%" is actionable; "the repository is at 80%" is a Goodhart trap.
- **Run mutation testing once as an audit.** It mutates your production code and reports what fraction of mutants your tests kill. Run it on the core modules — it is too slow for every pull request — and it will find the hollow tests immediately. This is the honest measure of whether a test suite detects anything.

```bash
npx stryker run --mutate "src/{auth,billing,orders}/**/*.ts"
```

## 4. End-to-end tests

Playwright is the default recommendation in 2026 for a small team: free parallelization, cross-browser, trace viewer, and a healthy investment trajectory including AI-oriented tooling.

The practices that matter more than the tool:

- **Seed data via API or direct database access**, then reuse authenticated state. Do not drive login through the UI in every test — test login once, separately.
- **Per-worker data namespaces** so parallel workers cannot collide.
- **Web-first assertions and auto-waiting.** Never `waitForTimeout`. Fixed sleeps are the primary source of flake.
- **Control the clock** for time-dependent behavior rather than sleeping.
- **`trace: 'on-first-retry'`** so a flaky failure produces a diagnosable artifact instead of a shrug.
- **Smoke subset on every pull request** (3–8 journeys), full suite on merge and nightly. This is the single biggest lever on CI cost and PR latency.

Flake management: retries plus trace capture, then quarantine persistent flakes into a non-blocking project with an owner and an expiry. Never leave a permanently red check — the whole suite loses authority within two weeks.

## 5. Test against a real database

Mocked database tests validate your mocks. Constraint violations, transaction semantics, cascade behavior, and row-level-security policies only appear against the real engine — and those are exactly the properties this codebase most needs verified.

Use Testcontainers or a dedicated test database. Isolation strategies, fastest first:

1. **Transaction per test with rollback** — fastest, but breaks if the code under test manages its own transactions or you need post-commit behavior
2. **Postgres template databases** — migrate once into a template, then `CREATE DATABASE t TEMPLATE tmpl` per worker. Near-instant, fully isolated, survives commits. Best default for parallel suites.
3. Truncate between tests
4. Fresh container per test — cleanest, far too slow

Seed with factories rather than fixtures (fixtures rot and couple tests to each other) and use a fixed random seed so failures reproduce.

## 6. Fuzz the API against its schema

This is the highest return-on-effort item in the domain for an AI-built API. A schema-driven fuzzer generates inputs from your OpenAPI spec, chains operations into stateful workflows, and requires no test authoring:

```bash
uvx schemathesis run https://staging.example.com/openapi.json
```

It finds precisely the AI-generated handler failure profile: unhandled edge-case input producing 500s, responses that drift from the documented shape, and validation that accepts data it should reject.

## 7. Security testing in the pipeline

Placement and blocking behavior are covered in knowledge file `D06-application-security.md` §7. The two rules that keep it sustainable: **scan the diff on pull requests**, and **block only on new high and critical findings**. Baseline the existing set rather than trying to zero it out on day one.

Pre-commit secret scanning is local and bypassable with `--no-verify`, so pair it with CI scanning and server-side push protection. Defense in depth here is cheap.

## 8. The human layer

A randomized controlled trial of experienced open-source developers working on their own repositories found they took **19% longer** with AI assistance while predicting a 24% speedup — and, having been measurably slowed, still believed afterwards that they had been sped up by 20%. A separate controlled study found developers using an AI assistant wrote less secure code *and were more likely to believe it was secure*.

The conclusion is not that AI assistance is bad. It is that **self-assessment of AI-assisted work is unreliable**, which is the empirical case for external verification rather than developer judgement.

So: a human reads the security-critical code line by line. Auth, authorization, payments, migrations, anything touching secrets, and anything an agent can invoke. Use knowledge file `X2-ai-code-failure-modes.md` as the review checklist, and enforce it with CODEOWNERS so it cannot be skipped.

## 9. Failure injection, cheaply

You do not need a chaos platform. Four experiments cover most of the value:

- Point a third-party client at a black-hole endpoint. Does the request time out cleanly, or hang?
- Kill the database connection mid-request. Does the app return an error or corrupt state?
- Fill the queue. Does anything alert?
- Return a 429 from a provider. Does the retry back off, or hammer?

Each takes minutes and each finds a missing timeout, retry, or alert with high reliability.
