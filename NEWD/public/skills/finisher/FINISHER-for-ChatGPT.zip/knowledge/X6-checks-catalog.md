# X6 — The FINISHER Checks Catalog

> Machine-readable source of truth, identical to the `checks.yaml` tool file the scorer reads.

```yaml
# FINISHER Checks Catalog
# Machine-readable source of truth for scoring. Consumed by finisher_score.py.
#
# SCALE (per check, 0-4):
#   0 ABSENT     - not present, or unknown after looking
#   1 CLAIMED    - exists in some form; no evidence; manual only
#   2 IMPLEMENTED- present and works; evidence observed once
#   3 VERIFIED   - proven by a named artifact (test name, command output, file+line, URL)
#   4 ENFORCED   - automated so it cannot regress (CI gate, runtime policy, alert)
#
# TIER: P0 blocks any launch. P1 blocks paid/public launch. P2 blocks scale.
# WEIGHT: relative importance inside its domain (1-5).
# WHEN: applicability conditions from intake. `always` = every project.
#       Conditions are ANDed. Prefix `!` to negate.

meta:
  catalog_version: "1.1.0"
  updated: "2026-07-25"
  scale:
    0: ABSENT
    1: CLAIMED
    2: IMPLEMENTED
    3: VERIFIED
    4: ENFORCED
  # Minimum score required for a check to count as "closed" at each tier.
  closed_at:
    P0: 3
    P1: 3
    P2: 2
  # Composite score ceilings while tiers remain open.
  ceilings:
    open_P0: 39
    open_P1: 69
    open_P2: 89
  bands:
    - {min: 0,  max: 39,  label: "DO NOT LAUNCH"}
    - {min: 40, max: 59,  label: "PRIVATE BETA ONLY"}
    - {min: 60, max: 74,  label: "PAID BETA WITH FIXES"}
    - {min: 75, max: 89,  label: "PRODUCTION READY"}
    - {min: 90, max: 100, label: "SCALE READY"}

# Intake conditions. Set true/false in state.json -> context.
conditions:
  has_users:        "App has end users with accounts or sessions"
  is_public:        "Reachable from the public internet"
  is_multi_tenant:  "Data is partitioned by org/tenant/workspace"
  has_admin:        "There are privileged/admin users or internal tools"
  has_pii:          "Collects personal data of any kind"
  has_payments:     "Handles money, subscriptions, or payouts"
  has_uploads:      "Accepts user-uploaded files"
  has_ugc:          "Stores user-generated content shown to others"
  has_ai:           "Calls an LLM or other paid inference API"
  has_agents:       "AI can call tools, browse, or take actions"
  has_third_party:  "Calls paid or rate-limited third-party APIs"
  has_jobs:         "Has background jobs, queues, crons, or webhooks"
  has_email:        "Sends transactional email or SMS"
  has_mobile:       "Ships a native or hybrid app to an app store"
  eu_users:         "Serves users in the EU/EEA/UK"
  us_state_privacy: "Serves consumers in US states with privacy laws"
  is_regulated:     "HIPAA, PCI, FERPA, GLBA, SOC 2, or similar in scope"
  has_team:         "More than one person will maintain this"

domains:
  - {id: D01, name: "Identity, Auth & Authorization",        weight: 12, when: [has_users]}
  - {id: D02, name: "Secrets & Key Management",              weight: 8,  when: [always]}
  - {id: D03, name: "Data Layer, Migrations & Backups",      weight: 9,  when: [always]}
  - {id: D04, name: "API & Backend Correctness",             weight: 7,  when: [always]}
  - {id: D05, name: "Frontend, UX & Accessibility",          weight: 6,  when: [always]}
  - {id: D06, name: "Application Security",                  weight: 9,  when: [always]}
  - {id: D07, name: "Supply Chain & Dependency Integrity",   weight: 6,  when: [always]}
  - {id: D08, name: "CI/CD & Release Engineering",           weight: 6,  when: [always]}
  - {id: D09, name: "Environments, Config & Infrastructure", weight: 5,  when: [always]}
  - {id: D10, name: "Observability & Error Tracking",        weight: 7,  when: [always]}
  - {id: D11, name: "Reliability, Backup & Incident Response",weight: 7, when: [always]}
  - {id: D12, name: "Performance, Caching & Scale",          weight: 5,  when: [always]}
  - {id: D13, name: "Cost Control & Abuse Prevention",       weight: 5,  when: [always]}
  - {id: D14, name: "AI & Agent Safety and Economics",       weight: 6,  when: [has_ai]}
  - {id: D15, name: "Privacy, Legal & Compliance",           weight: 6,  when: [has_pii]}
  - {id: D16, name: "Testing & Verification",                weight: 6,  when: [always]}
  - {id: D17, name: "Mobile & App Store",                    weight: 6,  when: [has_mobile]}
  - {id: D18, name: "Documentation & Handoff",               weight: 4,  when: [always]}
  - {id: D19, name: "Product Truth & Outcome Measurement",   weight: 3,  when: [always]}

checks:

# ============================================================
# D01 - IDENTITY, AUTH & AUTHORIZATION
# ============================================================
- id: AUTH-01
  domain: D01
  tier: P0
  weight: 5
  when: [has_users]
  title: "Authentication uses a battle-tested provider or framework, not hand-rolled code"
  risk: "Custom auth is the single most common catastrophic flaw in AI-generated apps. Session fixation, timing attacks, and broken password reset are all default outcomes."
  fix: "Adopt a managed provider (Auth0, Clerk, WorkOS, Supabase Auth, Cognito, Firebase Auth, Better Auth, NextAuth/Auth.js with a vetted adapter) or your framework's first-party auth. If custom is unavoidable, document why and get it reviewed."
  evidence: "Name the provider and the file where the session is established. If custom: link the review."
  enforce: "Lint or CODEOWNERS rule blocking edits to auth files without a named reviewer."

- id: AUTH-02
  domain: D01
  tier: P0
  weight: 5
  when: [has_users]
  title: "Every non-public route and API endpoint enforces authentication server-side"
  risk: "AI scaffolds frequently protect the UI route but leave the underlying API open. The page redirects; the JSON endpoint does not."
  fix: "Default-deny middleware. Enumerate every route; whitelist public ones explicitly. Never rely on the client hiding a link."
  evidence: "A route inventory table (path, method, auth required, authz rule) plus a test hitting each protected endpoint unauthenticated and asserting 401/403."
  enforce: "Automated route-inventory test that fails CI when a new route lacks an explicit auth declaration."

- id: AUTHZ-01
  domain: D01
  tier: P0
  weight: 5
  when: [has_users]
  title: "Every resource access checks ownership, not just authentication"
  risk: "Broken Access Control is OWASP A01:2025 and CWE-862 is #4 on the 2025 CWE Top 25. Authentication proves who you are; it does not stop you loading /invoice/1234."
  fix: "Every read/update/delete/export filters by the acting user's id, tenant id, or an explicit permission grant. Push the filter into the data layer, not the controller."
  evidence: "The User A / User B test from knowledge file X1-manual-test-scripts.md, executed, with output. IDs enumerated in URL, body, query, and headers."
  enforce: "Automated IDOR test suite covering every object type, run in CI."

- id: AUTHZ-02
  domain: D01
  tier: P0
  weight: 4
  when: [is_multi_tenant]
  title: "Tenant isolation is enforced at the database layer, not only in application code"
  risk: "One forgotten WHERE clause leaks an entire customer's data. Application-layer-only isolation has no backstop."
  fix: "Postgres RLS policies, a per-tenant schema/database, or a query-builder wrapper that makes an unscoped query impossible to express. Test with a session set to tenant A querying tenant B rows."
  evidence: "Policy definitions plus a test that sets the tenant context to A and asserts zero rows returned for B's data."
  enforce: "CI test asserting RLS is enabled on every table carrying a tenant column; migration lint fails if a new tenant table lacks a policy."

- id: AUTHZ-03
  domain: D01
  tier: P0
  weight: 4
  when: [has_admin]
  title: "Admin capability is server-verified and cannot be obtained by client-side manipulation"
  risk: "isAdmin in localStorage, a role claim the client can edit, or an /admin route protected only by not being linked."
  fix: "Role lives server-side and is re-checked on every privileged operation. Admin routes are a separate, separately-authorized surface. Consider a distinct hostname and IP or SSO restriction."
  evidence: "Test: authenticate as a normal user, forge the role client-side, call every admin endpoint, assert 403."
  enforce: "Admin endpoints share a middleware with its own test suite; CI fails if an admin route bypasses it."

- id: AUTHZ-04
  domain: D01
  tier: P1
  weight: 3
  when: [has_users]
  title: "Authorization model is written down and matches the code"
  risk: "Undocumented permission logic drifts, and nobody can answer 'can a viewer export?' without reading source."
  fix: "A single table of roles x resources x actions. Generate it from code if possible."
  evidence: "knowledge file X5-operational-templates.md section `ARCHITECTURE.md` permission matrix, cross-checked against the enforcement points."
  enforce: "Permission matrix is generated from the policy definitions in a CI step."

- id: AUTH-03
  domain: D01
  tier: P0
  weight: 4
  when: [has_users]
  title: "Sessions expire, logout truly invalidates, and session IDs rotate on privilege change"
  risk: "OWASP requires regenerating the session identifier after any privilege change; failing to do so enables session fixation. Client-side-only logout leaves a valid token."
  fix: "Server-side session invalidation on logout. Idle and absolute timeouts enforced server-side. Regenerate the session ID immediately after login and after any role change."
  evidence: "Capture a session token, log out, replay the token, assert rejection. Confirm the ID differs pre/post login."
  enforce: "Integration test in CI covering logout invalidation and rotation."

- id: AUTH-04
  domain: D01
  tier: P1
  weight: 3
  when: [has_users]
  title: "Session cookies use Secure, HttpOnly, SameSite, and the __Host- prefix where possible"
  risk: "A cookie readable by JavaScript turns any XSS into full account takeover."
  fix: "Set Secure; HttpOnly; SameSite=Lax or Strict. Use the __Host- prefix (requires Secure, Path=/, no Domain attribute) for maximum protection."
  evidence: "Raw Set-Cookie header from a real login response."
  enforce: "Test asserting cookie attributes on the login response."

- id: AUTH-05
  domain: D01
  tier: P0
  weight: 4
  when: [has_users]
  title: "Password reset and email verification tokens are single-use, short-lived, and unguessable"
  risk: "A reusable or long-lived reset link is a permanent backdoor. AI-generated reset flows frequently omit invalidation after use."
  fix: "Cryptographically random token, hashed at rest, expiring in 15-60 minutes, invalidated on use and on password change. Invalidate all sessions on password change."
  evidence: "Test: use a reset link twice, assert second attempt fails. Test expiry."
  enforce: "Automated test for reuse, expiry, and session invalidation on reset."

- id: AUTH-06
  domain: D01
  tier: P1
  weight: 3
  when: [has_users]
  title: "Login, reset, signup, and OTP endpoints are rate limited per account and per IP"
  risk: "Credential stuffing and password spraying are automated and cheap. OWASP advises locking on account identity, not IP alone."
  fix: "Per-identity throttling with exponential backoff plus per-IP limits, tuned against DoS abuse. Generic error text that does not disclose account existence."
  evidence: "Script 200 failed logins; show the lockout or throttle response."
  enforce: "Rate limit is configured at the edge/gateway and covered by a test."

- id: AUTH-07
  domain: D01
  tier: P1
  weight: 2
  when: [has_users]
  title: "Password policy follows current guidance: length over composition, breach-list blocking"
  risk: "Composition rules produce predictable passwords and no security. Reused breached passwords are the actual attack."
  fix: "Minimum 8 with MFA or 15 without; maximum at least 64; allow spaces and Unicode; no forced rotation; check against a breached-password corpus (e.g. Pwned Passwords k-anonymity API)."
  evidence: "Policy code plus a test rejecting a known-breached password."
  enforce: "Test in CI."

- id: AUTH-08
  domain: D01
  tier: P1
  weight: 2
  when: [has_users, has_admin]
  title: "MFA or passkeys available for users, mandatory for admins"
  risk: "A single phished admin password is total compromise. The 2025 npm chalk/debug compromise began with one phished maintainer."
  fix: "Offer TOTP/passkeys (WebAuthn). Require a second factor for all admin and billing-privileged accounts."
  evidence: "Screenshot or config showing enforcement on an admin account."
  enforce: "Policy enforced by the identity provider, not optional in the UI."

- id: AUTH-09
  domain: D01
  tier: P2
  weight: 2
  when: [has_users]
  title: "OAuth/OIDC integrations use PKCE, exact redirect URI matching, and state/nonce binding"
  risk: "Pattern-matched redirect URIs and missing PKCE enable authorization code interception. OAuth 2.1 makes PKCE mandatory for all authorization-code clients."
  fix: "PKCE on every authorization code flow. Exact-string redirect URI registration. Bind state to the user agent; use nonce for OIDC."
  evidence: "Capture the authorization request; show code_challenge and exact redirect registration."
  enforce: "Integration test or provider configuration screenshot in the handoff docs."

- id: AUTH-10
  domain: D01
  tier: P1
  weight: 3
  when: [has_users]
  title: "Tokens are validated with a pinned algorithm and are revocable"
  risk: "alg:none and algorithm-confusion attacks remain live because libraries accept whatever the token declares. JWTs have no native revocation."
  fix: "Pin the expected algorithm at verification. Short access-token TTL plus refresh rotation, or server-side session lookup. Maintain a revocation list keyed by token digest if you must use long-lived tokens."
  evidence: "Verification code showing the pinned algorithm; a test forging alg:none and asserting rejection."
  enforce: "Test in CI."

- id: AUTH-11
  domain: D01
  tier: P1
  weight: 2
  when: [has_users]
  title: "Account deletion and data export exist and actually work end to end"
  risk: "Required by GDPR, CCPA, and Apple App Store guideline 5.1.1 for any app that supports account creation."
  fix: "In-product deletion that removes or irreversibly anonymizes across primary store, caches, search indexes, analytics, and downstream processors. Documented backup expiry window."
  evidence: "Delete a test account; show the rows/objects gone from every store; document the backup lag."
  enforce: "Scheduled job verifies deletion propagation; test covers the happy path."

- id: AUTH-12
  domain: D01
  tier: P2
  weight: 2
  when: [has_admin]
  title: "Privileged actions are recorded in an append-only audit log"
  risk: "Without an audit trail you cannot answer 'who deleted it' or satisfy an enterprise security review."
  fix: "Log actor, action, target, before/after, timestamp, request id, and source IP for every admin and destructive action. Store separately from application logs, write-once."
  evidence: "Sample audit entries for an admin action."
  enforce: "Audit write is inside the transaction for privileged mutations; missing-audit test fails CI."

# ============================================================
# D02 - SECRETS & KEY MANAGEMENT
# ============================================================
- id: SEC-01
  domain: D02
  tier: P0
  weight: 5
  when: [always]
  title: "No secret is reachable from browser or mobile client code"
  risk: "Anything shipped to a client is public. NEXT_PUBLIC_/VITE_/REACT_APP_ prefixed variables are compiled into the bundle."
  fix: "Move every privileged call behind a server route. Only publishable/anon keys designed for client exposure may ship."
  evidence: "Grep the built bundle for sk_, key, secret, token, and each provider's key prefix. Paste the (empty) result. Inspect DevTools Network for outbound calls carrying credentials."
  enforce: "CI step that greps the production build for secret patterns and fails on a hit."

- id: SEC-02
  domain: D02
  tier: P0
  weight: 5
  when: [always]
  title: "Secret scan of the full git history passes, and anything ever exposed has been rotated"
  risk: "git rm does not remove a secret from history. A leaked key is compromised the moment it is pushed, not when it is discovered."
  fix: "Run gitleaks and/or trufflehog over all history. Rotate every hit at the provider. Rewriting history is optional; rotating is not."
  evidence: "`gitleaks git -v .` output plus a rotation log listing key name, date rotated, and who did it."
  enforce: "gitleaks in pre-commit AND in CI AND server-side push protection enabled."

- id: SEC-03
  domain: D02
  tier: P1
  weight: 4
  when: [always]
  title: "Secrets live in a secret manager or platform env store, scoped per environment"
  risk: "A .env file shared over Slack becomes a permanent, unrotatable, unauditable credential."
  fix: "Platform env vars or a secret manager (AWS Secrets Manager, GCP Secret Manager, Azure Key Vault, HashiCorp Vault, Doppler, Infisical). Distinct values per environment. .env.example lists names only."
  evidence: "Show the store and the per-environment scoping; confirm .env is gitignored and .env.example has no values."
  enforce: "Deploy fails if a required secret name is missing; no plaintext secrets in the repo, verified by CI."

- id: SEC-04
  domain: D02
  tier: P1
  weight: 3
  when: [always]
  title: "CI/CD uses short-lived federated credentials (OIDC), not long-lived cloud keys"
  risk: "A static AWS key in CI is a permanent credential harvested by every npm supply-chain worm of the last two years."
  fix: "GitHub Actions OIDC to AWS/GCP/Azure with a role trust policy scoped to repo, branch, and environment. Set permissions: id-token: write only on the jobs that need it."
  evidence: "Workflow file showing the OIDC exchange and the scoped trust policy subject claim."
  enforce: "No long-lived cloud keys exist in repository or organization secrets."

- id: SEC-05
  domain: D02
  tier: P1
  weight: 3
  when: [always]
  title: "Service accounts and database credentials follow least privilege"
  risk: "One app-wide superuser credential turns any injection or SSRF into total control."
  fix: "Separate read/write roles. Migration credentials distinct from runtime credentials. Third-party API keys scoped to the minimum permission set and, where supported, IP-restricted."
  evidence: "Grant listing per role; note what each cannot do."
  enforce: "Infrastructure-as-code defines the grants; drift detection or periodic review scheduled."

- id: SEC-06
  domain: D02
  tier: P1
  weight: 3
  when: [always]
  title: "Secrets never appear in logs, error messages, traces, screenshots, or AI prompts"
  risk: "Redaction failures move a secret from a vault into a log aggregator with far broader access."
  fix: "Redaction middleware on the logger with a deny-list of key names and value patterns. Scrub request bodies and headers. Never paste .env contents into an AI chat."
  evidence: "Trigger an error carrying a secret-bearing payload; show the redacted log line."
  enforce: "Unit test on the redactor; log-sample scan in CI or a scheduled job."

- id: SEC-07
  domain: D02
  tier: P2
  weight: 2
  when: [always]
  title: "Key rotation is documented, rehearsed, and possible without downtime"
  risk: "If rotation requires downtime you will not do it during an incident, which is exactly when you must."
  fix: "Support two valid keys simultaneously during rollover. Write the rotation runbook. Rehearse once."
  evidence: "Rotation runbook plus a dated record of a rehearsal."
  enforce: "Rotation is automated or calendared with an owner."

- id: SEC-08
  domain: D02
  tier: P1
  weight: 3
  when: [has_payments]
  title: "Webhook endpoints verify provider signatures and reject replays"
  risk: "An unverified webhook endpoint lets anyone mark invoices paid or grant subscriptions. This is a top-tier P0 in payment systems."
  fix: "Verify the signature with the provider's library using the raw request body. Enforce a timestamp tolerance. Store processed event IDs for idempotency."
  evidence: "Send a forged webhook; show rejection. Send the same valid event twice; show one side effect."
  enforce: "Both tests run in CI."

# ============================================================
# D03 - DATA LAYER, MIGRATIONS & BACKUPS
# ============================================================
- id: DATA-01
  domain: D03
  tier: P0
  weight: 5
  when: [always]
  title: "Automated backups exist for every production datastore"
  risk: "Without backups, one bad migration or one deletion ends the business. AI agents have deleted production databases."
  fix: "Enable managed automated backups plus point-in-time recovery where available. Include object storage, not just the primary database."
  evidence: "Backup configuration screenshot/CLI output showing schedule and retention, for each datastore."
  enforce: "Backup failure raises an alert; monitored, not assumed."

- id: DATA-02
  domain: D03
  tier: P0
  weight: 5
  when: [always]
  title: "A restore has actually been performed and the result verified"
  risk: "An untested backup is a hypothesis. Silent corruption, missing extensions, and wrong retention windows only surface on restore."
  fix: "Restore to a scratch environment. Run the app against it. Verify row counts and a known record. Record elapsed time as your real RTO."
  evidence: "Dated restore log with elapsed time and verification queries."
  enforce: "Restore drill scheduled at a defined cadence with a named owner."

- id: DATA-03
  domain: D03
  tier: P0
  weight: 4
  when: [always]
  title: "Production, staging, and development use separate datastores"
  risk: "Shared databases mean a dev seed script can wipe customer data. This is the root cause of the best-known AI-agent data-loss incident."
  fix: "Separate instances or database branches. Different credentials. Production credentials are not present in any developer environment."
  evidence: "Connection string hostnames per environment (redacted) showing they differ."
  enforce: "Startup assertion that refuses to run destructive scripts against a production host; production credentials absent from dev tooling."

- id: DATA-04
  domain: D03
  tier: P0
  weight: 4
  when: [always]
  title: "No human or agent has standing write access to the production database"
  risk: "Direct production edits are unlogged, unrepeatable, and undo your migrations. Agents with production credentials is the highest-severity configuration in this entire catalog."
  fix: "Read-only by default. Break-glass write access requires an explicit, logged, time-boxed elevation. AI coding tools get development credentials only."
  evidence: "Access listing showing who has write, and the elevation procedure."
  enforce: "Break-glass access is time-boxed and alerts on use."

- id: DATA-05
  domain: D03
  tier: P1
  weight: 4
  when: [always]
  title: "Every schema change is a versioned migration file in the repo"
  risk: "Schema drift makes environments non-reproducible and rollback impossible."
  fix: "Use the framework's migration tool. No console DDL. A fresh database must be creatable from migrations alone."
  evidence: "Create an empty database, run migrations, boot the app. Paste the output."
  enforce: "CI job that migrates a clean database from zero on every PR."

- id: DATA-06
  domain: D03
  tier: P1
  weight: 4
  when: [always]
  title: "Migrations are linted for locking and destructive operations"
  risk: "An AI-written migration that adds a unique constraint or a non-concurrent index takes an exclusive lock and halts your app under load. Destructive column drops lose data silently."
  fix: "Run squawk (Postgres) or Atlas lint as a required PR check. Adopt expand/contract: additive change, dual-write, backfill, switch reads, then contract."
  evidence: "Lint output on the current migration set."
  enforce: "Migration lint is a required status check on PRs."

- id: DATA-07
  domain: D03
  tier: P1
  weight: 3
  when: [always]
  title: "Rollback strategy for schema changes is defined and it is roll-forward-safe"
  risk: "Down migrations are rarely exercised and frequently lose data on the worst possible day."
  fix: "Prefer backwards-compatible migrations so a code rollback is sufficient. Test that version N-1 of the app still works against version N of the schema."
  evidence: "Test or documented procedure showing the previous release runs against the new schema."
  enforce: "CI runs the previous release's test suite against the migrated schema."

- id: DATA-08
  domain: D03
  tier: P1
  weight: 3
  when: [always]
  title: "Constraints and indexes reflect real access patterns"
  risk: "AI-generated schemas routinely omit foreign keys, unique constraints, and NOT NULL, pushing integrity enforcement into application code that forgets it."
  fix: "Foreign keys with deliberate cascade rules, unique constraints on natural keys, NOT NULL where truly required, check constraints on enums. Index from measured slow queries, not guesses."
  evidence: "Schema dump plus the slow-query report the indexes were derived from."
  enforce: "pg_stat_statements or equivalent reviewed at a defined cadence; slow-query alert configured."

- id: DATA-09
  domain: D03
  tier: P1
  weight: 3
  when: [has_uploads]
  title: "File uploads enforce size, type, and content validation, and are stored outside the app server"
  risk: "Unrestricted file upload is CWE-434, #12 on the 2025 CWE Top 25. Extension checks are trivially bypassed."
  fix: "Server-side size cap, content-type sniffing against an allowlist, randomized stored filenames, storage in object storage with private ACLs and signed URLs, never executing uploaded content from a web-served path."
  evidence: "Attempt to upload an oversized file, a disguised executable, and an SVG containing script; show all three rejected or neutralized."
  enforce: "Upload validation tests in CI; bucket policy prevents public listing."

- id: DATA-10
  domain: D03
  tier: P1
  weight: 3
  when: [has_pii]
  title: "Data retention and deletion rules are defined per data class"
  risk: "Keeping everything forever maximizes breach impact and violates data-minimization principles."
  fix: "Classify each table/bucket: what it holds, why, how long, who can read it. Implement scheduled purges. Define backup expiry so deletion eventually propagates."
  evidence: "Data inventory table with retention periods and the job that enforces them."
  enforce: "Purge job runs on schedule and is monitored."

- id: DATA-11
  domain: D03
  tier: P2
  weight: 2
  when: [has_pii]
  title: "Sensitive fields are encrypted at rest beyond disk-level encryption where warranted"
  risk: "Disk encryption protects against stolen hardware, not against a leaked database credential."
  fix: "Application-level or column-level encryption for the highest-sensitivity fields (government IDs, health data, financial account numbers). Use a managed KMS."
  evidence: "Show the encrypted column and the key management path."
  enforce: "Encryption applied at the ORM/model layer so new writes cannot bypass it."

- id: DATA-12
  domain: D03
  tier: P1
  weight: 3
  when: [always]
  title: "Idempotency keys prevent duplicate side effects from retries and double-clicks"
  risk: "Double-charging, duplicate orders, and duplicate emails are the classic symptom of a missing idempotency layer. AI-generated handlers almost never include one."
  fix: "Client-supplied or server-derived idempotency key stored with a uniqueness constraint; return the prior result on replay. Apply to payments, sends, and any externally visible side effect."
  evidence: "Fire the same request twice concurrently; show one side effect."
  enforce: "Concurrency test in CI."

# ============================================================
# D04 - API & BACKEND CORRECTNESS
# ============================================================
- id: API-01
  domain: D04
  tier: P0
  weight: 5
  when: [always]
  title: "All privileged operations execute server-side; the client is never trusted"
  risk: "Business rules enforced only in the UI are advisory. Price, quantity, role, and entitlement must be recomputed server-side."
  fix: "Recompute prices and entitlements from server state. Never accept a client-supplied amount, role, tier, or ownership field."
  evidence: "Tamper with a request body (price, role, userId) via curl; show rejection or server-side override."
  enforce: "Tests for each mass-assignment-sensitive endpoint."

- id: API-02
  domain: D04
  tier: P1
  weight: 4
  when: [always]
  title: "Every input is validated against a schema at the trust boundary, at runtime"
  risk: "TypeScript types are erased at runtime. AI handlers routinely treat req.body as if the declared type were enforced."
  fix: "Zod/Valibot/Pydantic/JSON Schema validation on every request body, query, param, and header you read. Reject unknown fields (strict mode) to block mass assignment."
  evidence: "Schema definitions plus a test posting malformed and extra fields, asserting 400."
  enforce: "Framework-level validation so an unvalidated handler cannot be added; or a lint rule."

- id: API-03
  domain: D04
  tier: P1
  weight: 3
  when: [always]
  title: "Errors return safe messages; stack traces and internals never reach clients"
  risk: "OWASP added A10:2025 Mishandling of Exceptional Conditions specifically for this. CWE-209 leaks schema, paths, and library versions."
  fix: "Central error handler mapping internal errors to generic client messages plus a correlation ID. Full detail goes to logs only. Never fail open on an exception in an authorization path."
  evidence: "Force a 500; show the client response contains no stack trace and does contain a correlation ID."
  enforce: "Test asserting error shape; production config disables debug output."

- id: API-04
  domain: D04
  tier: P1
  weight: 3
  when: [has_third_party]
  title: "Every external call has a timeout, bounded retries with backoff and jitter, and a defined fallback"
  risk: "A hanging third-party call exhausts your connection pool and takes down endpoints that have nothing to do with it."
  fix: "Explicit timeout on every client. Retry only idempotent operations, with exponential backoff and jitter and a cap. Circuit breaker for repeated failure. Define the degraded behavior."
  evidence: "Point a client at a black-hole endpoint; show it times out cleanly and the app stays up."
  enforce: "Timeouts set in a shared HTTP client wrapper, not per call site."

- id: API-05
  domain: D04
  tier: P1
  weight: 3
  when: [has_third_party]
  title: "Each external provider is wrapped in a single service module"
  risk: "Provider calls scattered across 30 files make it impossible to add caching, retries, cost tracking, or to swap providers."
  fix: "One module per provider exposing domain-shaped functions. All logging, retries, and cost accounting live there."
  evidence: "Grep for direct SDK usage outside the wrapper; result should be empty."
  enforce: "Lint rule (e.g. no-restricted-imports) blocking direct SDK imports outside the wrapper."

- id: API-06
  domain: D04
  tier: P1
  weight: 3
  when: [has_jobs]
  title: "Work that can exceed the request timeout runs in a background job, not in the request"
  risk: "PDF generation, bulk email, imports, and multi-step AI chains routinely exceed serverless timeouts, producing 504s and half-completed state."
  fix: "Queue the work; return an accepted response with a status endpoint or a real-time channel. Jobs must be idempotent and retryable with a dead-letter queue."
  evidence: "List every operation exceeding 5 seconds at p95 and where it runs."
  enforce: "Alert on job failures and dead-letter depth."

- id: API-07
  domain: D04
  tier: P1
  weight: 3
  when: [has_jobs]
  title: "Background jobs, crons, and webhooks are observable and alert on failure"
  risk: "Silent job failure is the most common invisible outage: nothing 500s, work just stops happening."
  fix: "Emit metrics on success, failure, latency, and queue depth. Dead-man's-switch monitoring for crons. Retry with backoff, then dead-letter."
  evidence: "Show a failed job producing an alert."
  enforce: "Alert rules configured and tested."

- id: API-08
  domain: D04
  tier: P2
  weight: 2
  when: [is_public]
  title: "An API contract exists (OpenAPI or typed RPC) and responses conform to it"
  risk: "Response drift breaks clients silently and makes handoff and integration testing impossible."
  fix: "OpenAPI spec, tRPC, or equivalent as the single source of truth. Generate client types from it. Detect breaking changes in CI with oasdiff or similar."
  evidence: "Spec file plus a conformance run (e.g. schemathesis) showing responses match."
  enforce: "Breaking-change detection is a required check."

- id: API-09
  domain: D04
  tier: P2
  weight: 2
  when: [is_public]
  title: "Pagination, sorting, and filtering are bounded"
  risk: "An unbounded list endpoint is a denial-of-service primitive and a data-exfiltration convenience. CWE-770 is #25 on the 2025 CWE Top 25."
  fix: "Enforce a maximum page size server-side. Allowlist sortable and filterable fields to prevent injection via ORDER BY."
  evidence: "Request limit=1000000; show it clamped."
  enforce: "Default and max page size set in shared middleware."

# ============================================================
# D05 - FRONTEND, UX & ACCESSIBILITY
# ============================================================
- id: FE-01
  domain: D05
  tier: P1
  weight: 4
  when: [always]
  title: "Every async surface has loading, error, empty, and success states"
  risk: "The most common vibe-coded failure: the happy path is beautiful and everything else is a blank screen or an infinite spinner."
  fix: "Enumerate components fetching data; implement all four states. Errors must be actionable and offer a retry."
  evidence: "Screenshots or tests for the four states on the top five surfaces."
  enforce: "Storybook stories or component tests covering each state."

- id: FE-02
  domain: D05
  tier: P1
  weight: 3
  when: [always]
  title: "Error boundaries prevent one component failure from blanking the app"
  risk: "An unhandled render error in a sidebar widget white-screens the entire product."
  fix: "Error boundaries at route and major-section level, reporting to error tracking, with a recoverable fallback UI."
  evidence: "Throw deliberately in a child component; show the rest of the app survives and the error was reported."
  enforce: "Test that asserts the boundary catches and reports."

- id: FE-03
  domain: D05
  tier: P1
  weight: 3
  when: [always]
  title: "Core flows verified on real mobile devices, Safari, and a throttled network"
  risk: "Desktop Chrome on fast wifi is not the deployment environment. Safari-specific date, scroll, and storage behavior breaks apps routinely."
  fix: "Test the top three journeys on an actual phone, in Safari, and under a 3G/Slow-4G throttle profile. Include an older device if your audience has one."
  evidence: "Device/browser/network matrix with pass/fail and notes."
  enforce: "Cross-browser project matrix in the E2E suite."

- id: FE-04
  domain: D05
  tier: P1
  weight: 3
  when: [always]
  title: "Forms survive hostile and messy input"
  risk: "Apostrophes, emoji, 10k-character pastes, double submits, and back-button-mid-request are the reliable crash set."
  fix: "Test each. Disable submit while in flight. Preserve input on failure. Enforce maxlength server-side too."
  evidence: "Executed edge-case UX checklist from knowledge file X1-manual-test-scripts.md."
  enforce: "E2E tests covering double-submit and oversized input."

- id: FE-05
  domain: D05
  tier: P1
  weight: 3
  when: [is_public]
  title: "Automated accessibility scan passes on core pages"
  risk: "The WebAIM Million 2026 study found 95.9% of home pages had detected WCAG failures, and six mechanical defects account for ~96% of all errors. These are free to fix."
  fix: "Wire axe-core into the E2E suite scoped to wcag2a/wcag2aa/wcag21aa. Fix contrast, missing alt text, missing form labels, empty links, empty buttons, and missing document language first."
  evidence: "axe run output on core pages showing zero violations, or a documented exception list."
  enforce: "axe assertion in CI on the critical page set."

- id: FE-06
  domain: D05
  tier: P1
  weight: 3
  when: [is_public]
  title: "Keyboard-only and screen-reader passes completed on critical journeys"
  risk: "Automated tooling catches roughly 20-30% of WCAG success criteria. Focus order, keyboard traps, and meaningless labels are invisible to it."
  fix: "Unplug the mouse and complete each critical journey. Confirm visible focus, logical order, Esc closes modals, focus returns sensibly. One pass with VoiceOver or NVDA on the top flows. Check 200% zoom and 320px reflow."
  evidence: "Dated notes per journey listing what was found and fixed."
  enforce: "Repeat each release; recorded in the release checklist."

- id: FE-07
  domain: D05
  tier: P2
  weight: 2
  when: [is_public]
  title: "Core Web Vitals measured on real users and within thresholds"
  risk: "Lab scores mislead. Field data is what search ranking and actual experience reflect."
  fix: "Collect RUM for LCP, INP, and CLS. Target good thresholds at p75. Set a performance budget for bundle size and block regressions."
  evidence: "Field data report at p75 for the three metrics."
  enforce: "Bundle-size budget enforced in CI; RUM dashboard monitored."

- id: FE-08
  domain: D05
  tier: P2
  weight: 2
  when: [always]
  title: "Five target users complete the core flow unaided"
  risk: "The builder can always use their own app. That tells you nothing."
  fix: "Watch five people from the target audience attempt the core task with no explanation. Record where they stall."
  evidence: "Notes per participant: completed yes/no, time, stumbling points."
  enforce: "Repeat after major UX changes."

# ============================================================
# D06 - APPLICATION SECURITY
# ============================================================
- id: APPSEC-01
  domain: D06
  tier: P0
  weight: 4
  when: [always]
  title: "Injection is prevented structurally, not by escaping strings"
  risk: "SQL injection is CWE-89, #2 on the 2025 CWE Top 25. Command injection is #9. AI models parameterize SQL reasonably well and handle command construction badly."
  fix: "Parameterized queries or an ORM everywhere; never build SQL by concatenation. Never pass user input to a shell. Allowlist for any dynamic identifier (table, column, sort field)."
  evidence: "Grep for string-built queries and shell invocations; show the results are safe. SAST run clean on injection rules."
  enforce: "Semgrep or CodeQL injection rules in CI, blocking on new findings."

- id: APPSEC-02
  domain: D06
  tier: P0
  weight: 4
  when: [has_ugc]
  title: "Output encoding prevents XSS in every rendering context"
  risk: "Veracode's 2026 longitudinal study found AI models pass XSS defense tests only ~15% of the time, versus 82% for SQL injection. Models learned to parameterize queries and never learned to encode output. XSS is CWE-79, #1 on the 2025 CWE Top 25."
  fix: "Use framework auto-escaping. Audit every dangerouslySetInnerHTML / v-html / innerHTML. Sanitize rich text with DOMPurify server-side. Context-appropriate encoding for HTML, attribute, URL, JS, and CSS contexts. Never render user-controlled URLs without scheme validation."
  evidence: "Inventory of raw-HTML sinks with the sanitizer applied at each; a stored-XSS attempt showing neutralization."
  enforce: "Lint rule flagging raw HTML sinks; SAST XSS rules blocking in CI."

- id: APPSEC-03
  domain: D06
  tier: P1
  weight: 4
  when: [is_public]
  title: "Security headers are set, including a strict Content-Security-Policy"
  risk: "Missing headers turn a small injection into a full compromise and leak referrer data."
  fix: "Strict-Transport-Security with a long max-age and includeSubDomains; X-Content-Type-Options: nosniff; Referrer-Policy; frame-ancestors plus X-Frame-Options for compatibility; a nonce-based strict CSP with 'strict-dynamic', object-src 'none', base-uri 'none'; a restrictive Permissions-Policy. Do not use X-XSS-Protection (deprecated and itself a risk)."
  evidence: "curl -I output of production headers, plus a CSP report-only period showing no legitimate violations before enforcing."
  enforce: "Headers set in middleware/edge config with a test asserting their presence."

- id: APPSEC-04
  domain: D06
  tier: P1
  weight: 3
  when: [is_public]
  title: "CORS is restricted to known origins and credentials are not exposed to wildcards"
  risk: "Access-Control-Allow-Origin reflecting the request origin with credentials enabled is a full same-origin bypass."
  fix: "Explicit origin allowlist. Never reflect arbitrary origins with credentials. Restrict methods and headers."
  evidence: "Send a request from an unlisted origin; show the browser blocks it."
  enforce: "Config-driven allowlist with a test."

- id: APPSEC-05
  domain: D06
  tier: P1
  weight: 3
  when: [has_users]
  title: "CSRF protection is present on state-changing requests"
  risk: "CSRF is CWE-352, #3 on the 2025 CWE Top 25 — unusually high. Cookie-based sessions without SameSite=Strict or tokens are exposed."
  fix: "SameSite cookies plus anti-CSRF tokens for cookie-authenticated state changes, or a bearer-token scheme not carried automatically by the browser. Verify Origin/Referer on sensitive endpoints."
  evidence: "Cross-origin state-changing request from a test page; show rejection."
  enforce: "Framework CSRF middleware enabled globally with an explicit opt-out list."

- id: APPSEC-06
  domain: D06
  tier: P1
  weight: 3
  when: [always]
  title: "SAST runs on pull requests and blocks new high/critical findings"
  risk: "Apiiro measured a 322% increase in privilege-escalation paths and 153% increase in architectural flaws in AI-assisted repositories. Volume defeats manual review."
  fix: "Semgrep (Community Edition is free) or CodeQL, scoped to the diff on PRs. Baseline existing findings; block only on new high/critical to avoid alert fatigue."
  evidence: "CI run output plus the baseline file."
  enforce: "Required status check."

- id: APPSEC-07
  domain: D06
  tier: P1
  weight: 3
  when: [is_public]
  title: "SSRF is prevented anywhere the server fetches a user-supplied URL"
  risk: "SSRF was merged into A01 Broken Access Control in OWASP 2025 and remains CWE-918 at #22. Cloud metadata endpoints turn SSRF into credential theft — this was a named vector in the Shai-Hulud 2.0 worm."
  fix: "Allowlist destination hosts. Resolve DNS and reject private, loopback, link-local, and metadata ranges — re-check after redirects to defeat DNS rebinding. Disable redirects or re-validate each hop. Block the cloud metadata IP at the network level."
  evidence: "Attempt fetch of the metadata address and a private IP; show rejection."
  enforce: "Centralized URL-fetch helper; lint blocking direct HTTP clients for user-supplied URLs."

- id: APPSEC-08
  domain: D06
  tier: P1
  weight: 3
  when: [is_public]
  title: "A DAST baseline scan has been run against staging and findings triaged"
  risk: "Static analysis cannot see misconfiguration, missing headers, or exposed endpoints in the running system."
  fix: "Run a ZAP baseline (passive) scan against staging. Triage every alert as fix, accept-with-reason, or false positive."
  evidence: "Scan report plus the triage table."
  enforce: "Scheduled nightly scan against staging, non-blocking, reviewed."

- id: APPSEC-09
  domain: D06
  tier: P1
  weight: 3
  when: [always]
  title: "Manual authorization tampering has been attempted and failed"
  risk: "No scanner reliably finds broken object-level authorization. It requires a human trying it."
  fix: "Execute the full auth boundary script: ID substitution in URL, body, query, and headers; role escalation; admin endpoint access; expired session replay; cross-tenant access."
  evidence: "Completed test log from knowledge file X1-manual-test-scripts.md with each attempt and its result."
  enforce: "Automated IDOR regression suite derived from the manual findings."

- id: APPSEC-10
  domain: D06
  tier: P2
  weight: 2
  when: [always]
  title: "A written threat model exists for the highest-value assets"
  risk: "Without one, controls are chosen by habit rather than by what an attacker would actually do."
  fix: "For each key asset: who wants it, how they would reach it, what stops them, what detects them. One page is enough. Use knowledge file X5-operational-templates.md section `THREAT-MODEL.md`."
  evidence: "Completed threat model."
  enforce: "Reviewed when architecture changes materially."

- id: APPSEC-11
  domain: D06
  tier: P2
  weight: 2
  when: [is_public]
  title: "A vulnerability disclosure path exists"
  risk: "Researchers who cannot reach you post publicly instead."
  fix: "security.txt at /.well-known/security.txt and a monitored security@ address with a stated response commitment."
  evidence: "Live security.txt URL."
  enforce: "Inbox monitored with an owner."

# ============================================================
# D07 - SUPPLY CHAIN & DEPENDENCY INTEGRITY
# ============================================================
- id: SUP-01
  domain: D07
  tier: P0
  weight: 4
  when: [always]
  title: "Install scripts do not run for arbitrary transitive dependencies"
  risk: "Every major 2025-2026 npm worm executed at install time via preinstall/postinstall, before any application code imported the package. This single control defeats most of them."
  fix: "On npm 12+, install scripts are off by default; approve only the packages that genuinely need to build native code and commit the allowlist. On older npm use --ignore-scripts in CI with an explicit build step. pnpm: onlyBuiltDependencies. Yarn: enableScripts false."
  evidence: "The committed allowlist plus a CI install log showing scripts did not run for unapproved packages."
  enforce: "CI installs with scripts disabled; allowlist changes require review."

- id: SUP-02
  domain: D07
  tier: P1
  weight: 4
  when: [always]
  title: "Lockfile is committed and CI installs are frozen and reproducible"
  risk: "A floating install lets a compromised version enter without any change to your repository."
  fix: "npm ci / pnpm install --frozen-lockfile / yarn --immutable / uv sync --frozen. CI must fail if the lockfile and manifest disagree."
  evidence: "CI log showing the frozen install command."
  enforce: "Frozen install is the only install path in CI."

- id: SUP-03
  domain: D07
  tier: P1
  weight: 3
  when: [always]
  title: "A dependency cooldown / minimum release age is configured"
  risk: "In the March 2026 PyPI compromise, a malicious version was live for two and a half hours and was downloaded 119,000 times. A three-day delay would have caught it."
  fix: "npm min-release-age, pnpm minimumReleaseAge, Yarn npmMinimalAgeGate, pip --uploaded-prior-to, uv --exclude-newer. Dependabot applies a default cooldown; security updates bypass it, which is correct."
  evidence: "Config showing the cooldown value."
  enforce: "Set in the repo config and in the bot config."

- id: SUP-04
  domain: D07
  tier: P1
  weight: 3
  when: [always]
  title: "Dependency vulnerability scanning runs in CI and on a schedule"
  risk: "Software Supply Chain Failures is A03:2025, new to the OWASP Top 10 and voted #1 risk by half of surveyed practitioners."
  fix: "Trivy, OSV-Scanner, Grype, npm audit, or Snyk. Scan on PR and nightly, since new CVEs land against unchanged code. Prioritize by exploitability (KEV, EPSS) not raw CVSS."
  evidence: "Scan output plus the triage decisions for anything unfixed."
  enforce: "Blocking on new critical/known-exploited; warning otherwise."

- id: SUP-05
  domain: D07
  tier: P1
  weight: 3
  when: [always]
  title: "Every dependency actually exists and was not hallucinated"
  risk: "Slopsquatting. USENIX Security 2025 research over 576,000 samples found ~5% hallucination for commercial models and up to 21.7% for open models, with 43% of fabricated names reproduced consistently across runs — which is exactly what makes them registerable by attackers."
  fix: "For every dependency an AI added: confirm it is the package you meant, check publish date, download counts, repository link, and maintainer history. Be suspicious of any package created recently with a plausible name."
  evidence: "Review notes on newly added dependencies, or a CI check asserting each new dependency predates the PR."
  enforce: "New-dependency review is a required step in the PR template."

- id: SUP-06
  domain: D07
  tier: P2
  weight: 2
  when: [always]
  title: "GitHub Actions are pinned to full commit SHAs"
  risk: "Tags are mutable. @v4 is a moving target controlled by someone else."
  fix: "Pin every third-party action to a full-length commit SHA with a version comment. Dependabot updates SHA pins in place."
  evidence: "Workflow files showing SHA pins."
  enforce: "Scorecard Pinned-Dependencies check, or a lint rule."

- id: SUP-07
  domain: D07
  tier: P2
  weight: 2
  when: [always]
  title: "CI workflow token permissions are least-privilege and untrusted input is never interpolated into shell"
  risk: "Expression interpolation of a PR title into a run: block is remote code execution in your CI. pull_request_target with a checkout of the PR head is the classic total compromise."
  fix: "permissions: contents: read at workflow level, escalate per job. Pass untrusted event fields through env vars and quote them. Never check out untrusted code in a privileged workflow."
  evidence: "Workflow audit showing permissions blocks and no direct interpolation of event data."
  enforce: "Scorecard Token-Permissions and Dangerous-Workflow checks in CI."

- id: SUP-08
  domain: D07
  tier: P2
  weight: 2
  when: [always]
  title: "An SBOM is generated per release and retained"
  risk: "When the next registry worm lands you need to answer 'are we affected' in minutes, not days. Enterprise and public-sector customers increasingly require it contractually."
  fix: "Generate CycloneDX or SPDX at build time from the build context with syft, trivy, or npm sbom. Store it with the release artifact. Attach as a signed attestation if you publish artifacts."
  evidence: "SBOM file attached to the most recent release."
  enforce: "SBOM generation step in the release workflow."

- id: SUP-09
  domain: D07
  tier: P2
  weight: 2
  when: [always]
  title: "Published artifacts carry build provenance"
  risk: "Consumers cannot distinguish your build from an attacker's without attested provenance."
  fix: "Use platform attestations (e.g. actions/attest-build-provenance) or cosign keyless signing. If publishing to npm/PyPI, use trusted publishing (OIDC) rather than long-lived publish tokens."
  evidence: "Verification command output for the latest release."
  enforce: "Publishing without provenance is not possible in the release workflow."

# ============================================================
# D08 - CI/CD & RELEASE ENGINEERING
# ============================================================
- id: CI-01
  domain: D08
  tier: P0
  weight: 4
  when: [always]
  title: "Code is in version control with a clean, complete history"
  risk: "No repository means no rollback, no review, no history, no recovery."
  fix: "Git repository, meaningful commits, .gitignore covering env files, build output, and credentials. Lock files committed."
  evidence: "Repository URL and a clean git status."
  enforce: "N/A - foundational."

- id: CI-02
  domain: D08
  tier: P1
  weight: 4
  when: [always]
  title: "CI runs lint, typecheck, tests, and build on every pull request"
  risk: "Without an automated gate, broken code reaches production at the speed of a merge button."
  fix: "One workflow running the full gate. Fast (<10 min) or people will bypass it."
  evidence: "A CI run link showing all steps green."
  enforce: "Required status checks configured on the protected branch."

- id: CI-03
  domain: D08
  tier: P1
  weight: 3
  when: [has_team]
  title: "The main branch is protected: no direct pushes, no force pushes, review required"
  risk: "An unprotected main branch means any compromised credential or careless command rewrites production history."
  fix: "Branch protection or rulesets: require PR, require passing checks, require branches up to date, block force push and deletion, require Code Owner review on sensitive paths."
  evidence: "Screenshot or API output of the ruleset."
  enforce: "Ruleset applied; bypass list audited."

- id: CI-04
  domain: D08
  tier: P1
  weight: 3
  when: [always]
  title: "CODEOWNERS protects auth, payments, migrations, and CI workflow paths"
  risk: "Most CI compromises in the 2025-2026 incident record involved modifying workflow files. Those paths deserve mandatory review."
  fix: ".github/CODEOWNERS assigning .github/workflows/, auth, payment, and migration directories to a named reviewer, combined with required Code Owner review."
  evidence: "CODEOWNERS file plus the ruleset requiring it."
  enforce: "Required Code Owner review on the protected branch."

- id: CI-05
  domain: D08
  tier: P0
  weight: 4
  when: [is_public]
  title: "Deployments can be rolled back quickly, and rollback has been tested"
  risk: "Discovering that rollback does not work during an outage is the worst possible time to learn it."
  fix: "Document the exact rollback command or console action. Perform a rollback in a calm moment and time it. Account for migrations: a schema change may make a code rollback unsafe."
  evidence: "Dated rollback rehearsal with elapsed time and the command used."
  enforce: "Rollback procedure in the runbook, rehearsed at a defined cadence."

- id: CI-06
  domain: D08
  tier: P1
  weight: 3
  when: [always]
  title: "Changes are previewable before production"
  risk: "Deploying straight to production is a coin flip that you win most of the time, which is what makes it dangerous."
  fix: "Branch preview deployments or a staging environment that mirrors production configuration."
  evidence: "A preview URL from a recent pull request."
  enforce: "Preview deploy runs automatically on every PR."

- id: CI-07
  domain: D08
  tier: P1
  weight: 3
  when: [is_public]
  title: "Deploys are small, frequent, and attributable to a commit"
  risk: "Large batched deploys make attribution impossible: something broke, and it was one of forty changes."
  fix: "Deploy one meaningful change at a time. Tag releases. Record the deployed commit SHA in the app and in error tracking."
  evidence: "Release version visible in the running app and attached to error reports."
  enforce: "Build injects the commit SHA; error tracking receives release metadata."

- id: CI-08
  domain: D08
  tier: P2
  weight: 2
  when: [is_public]
  title: "Risky changes ship behind feature flags with a kill switch"
  risk: "Without a flag, backing out a bad feature requires a deploy — minutes you may not have."
  fix: "A flag system (OpenFeature-compatible, or a simple config-backed one). Every risky feature gets an off switch reachable without a deploy. Clean up stale flags."
  evidence: "Flag definition plus a demonstration of toggling in production."
  enforce: "Flag lifecycle tracked; stale flags removed on a cadence."

- id: CI-09
  domain: D08
  tier: P2
  weight: 2
  when: [is_public]
  title: "Post-deploy verification watches error rate, latency, and key funnels"
  risk: "A deploy that succeeds technically and breaks signup is still an outage."
  fix: "Define the watch window and metrics. Automate the rollback trigger if possible; otherwise a human watches for a defined period."
  evidence: "The post-deploy checklist plus a recent example of it being followed."
  enforce: "Automated canary analysis or alert thresholds tuned for post-deploy windows."

# ============================================================
# D09 - ENVIRONMENTS, CONFIG & INFRASTRUCTURE
# ============================================================
- id: ENV-01
  domain: D09
  tier: P0
  weight: 4
  when: [always]
  title: "Development, staging, and production are genuinely separate"
  risk: "Shared infrastructure means a test action has production consequences."
  fix: "Separate databases, storage buckets, API keys, queues, and third-party accounts (payment test mode, separate email sending domain or sandbox)."
  evidence: "Environment matrix listing each resource per environment."
  enforce: "Environment names asserted at boot; mismatched configuration refuses to start."

- id: ENV-02
  domain: D09
  tier: P1
  weight: 3
  when: [always]
  title: "Required configuration is validated at startup and the app refuses to boot if it is wrong"
  risk: "A missing environment variable that silently defaults to a development value is a data-leak vector."
  fix: "Schema-validate all environment variables at boot. Fail loudly and immediately. No silent fallbacks for security-relevant settings."
  evidence: "Boot with a required variable removed; show the explicit failure."
  enforce: "Config schema in code; startup validation is unconditional."

- id: ENV-03
  domain: D09
  tier: P1
  weight: 3
  when: [always]
  title: "Infrastructure changes are reproducible, not clicked"
  risk: "Console-configured infrastructure cannot be recreated after an account loss or a region failure, and nobody remembers what was changed."
  fix: "Infrastructure as code where practical, or at minimum a written inventory of every manually configured resource and setting."
  evidence: "IaC repository or the manual inventory document."
  enforce: "Drift detection, or a scheduled review of the inventory."

- id: ENV-04
  domain: D09
  tier: P1
  weight: 3
  when: [is_public]
  title: "TLS everywhere, HTTP redirects to HTTPS, and certificate renewal is automated"
  risk: "An expired certificate is a total outage with a countdown you could have seen."
  fix: "HTTPS enforced, HSTS set, automated renewal, and an expiry monitor as a backstop."
  evidence: "SSL Labs or equivalent result plus the renewal mechanism."
  enforce: "Certificate expiry alert configured."

- id: ENV-05
  domain: D09
  tier: P1
  weight: 3
  when: [always]
  title: "Serverless and platform timeouts are known and no core action exceeds them"
  risk: "Functions time out mid-write, leaving half-completed state and a 504 with no explanation."
  fix: "Document the timeout for each runtime. Measure p95 for every endpoint. Anything approaching the limit moves to a job."
  evidence: "Table of endpoint p95 latency against the platform timeout."
  enforce: "Alert when any endpoint p95 exceeds a fraction of the timeout."

- id: ENV-06
  domain: D09
  tier: P2
  weight: 2
  when: [always]
  title: "DNS, domains, and registrar access are documented and secured"
  risk: "A lapsed domain or a hijacked registrar account is an unrecoverable brand and security event. Domain resurrection is a documented account-takeover vector."
  fix: "Auto-renew on, registrar lock enabled, MFA on the registrar account, ownership recorded in the handoff docs, expiry monitored."
  evidence: "Registrar settings and the documented owner."
  enforce: "Expiry monitor plus MFA enforced."

# ============================================================
# D10 - OBSERVABILITY & ERROR TRACKING
# ============================================================
- id: OBS-01
  domain: D10
  tier: P0
  weight: 5
  when: [is_public]
  title: "Error tracking is installed on both frontend and backend and receives production errors"
  risk: "OWASP A09:2025 is Security Logging and Alerting Failures. If an error happens and nothing records it, you learn about outages from angry users."
  fix: "Sentry, Rollbar, Bugsnag, or your platform's equivalent, wired into both runtimes, with source maps uploaded and release tagging enabled."
  evidence: "A deliberately triggered production error appearing in the dashboard with a readable stack trace."
  enforce: "Alert on new issue types and on error-rate spikes."

- id: OBS-02
  domain: D10
  tier: P1
  weight: 4
  when: [always]
  title: "Logs are structured and carry a correlation ID across the request path"
  risk: "Unstructured logs are unsearchable at exactly the moment you need them. Without a request ID you cannot reconstruct what happened."
  fix: "JSON logs with timestamp, level, request/trace ID, route, user or account ID, and duration. Propagate the ID to background jobs and outbound calls."
  evidence: "A single request's log lines from entry through job completion, joined by one ID."
  enforce: "Logger wrapper enforces the shape; direct console logging is lint-blocked."

- id: OBS-03
  domain: D10
  tier: P1
  weight: 3
  when: [always]
  title: "Logs redact secrets and personal data and have a defined retention period"
  risk: "Logs are the most commonly over-shared datastore in any company."
  fix: "Redaction at the logger. Retention set deliberately. Access restricted and reviewed."
  evidence: "Redacted sample plus the retention configuration."
  enforce: "Redaction unit-tested; retention configured at the provider."

- id: OBS-04
  domain: D10
  tier: P1
  weight: 4
  when: [is_public]
  title: "Alerts exist for the failures that matter, and they reach a human"
  risk: "A dashboard nobody is watching at 2am is not monitoring."
  fix: "Alert on symptoms users feel: error-rate spike, latency at p95/p99, failed payments, failed jobs, queue depth, uptime failure, spend anomaly. Route to a channel that produces a notification. Every alert must be actionable — delete or tune anything that fires without requiring action."
  evidence: "Alert rule list plus proof one fired and reached someone."
  enforce: "Alert routing tested; on-call or notification path documented."

- id: OBS-05
  domain: D10
  tier: P1
  weight: 3
  when: [is_public]
  title: "Uptime and synthetic monitoring check the real user journey, not just a 200"
  risk: "A health check that returns 200 while the database is down is worse than no health check."
  fix: "Separate liveness (is the process up) from readiness (are dependencies reachable). Add a synthetic check that performs a real login or core action on a schedule."
  evidence: "Monitor configuration plus an incident where it detected before a user did."
  enforce: "Monitors configured with alerting and reviewed."

- id: OBS-06
  domain: D10
  tier: P2
  weight: 3
  when: [always]
  title: "Distributed tracing covers the slow and complex paths"
  risk: "Without traces, 'the app is slow' is an unanswerable question in a system with more than three hops."
  fix: "OpenTelemetry auto-instrumentation exporting to your backend. Instrument database calls, external APIs, jobs, and AI calls. Expect GenAI semantic conventions to keep changing; instrument anyway."
  evidence: "A trace for the slowest core endpoint showing where time goes."
  enforce: "Tracing enabled in production with a sampling policy."

- id: OBS-07
  domain: D10
  tier: P2
  weight: 2
  when: [is_public]
  title: "Product analytics track the core funnel"
  risk: "Without funnel data, you optimize whatever you happen to notice."
  fix: "Instrument signup, activation, core action, and conversion. Respect consent requirements."
  evidence: "Funnel report for the last 30 days."
  enforce: "Events defined in a tracking plan; new features add events by default."

# ============================================================
# D11 - RELIABILITY, BACKUP & INCIDENT RESPONSE
# ============================================================
- id: REL-01
  domain: D11
  tier: P1
  weight: 4
  when: [is_public]
  title: "RTO and RPO are defined, written down, and consistent with the backup configuration"
  risk: "Everyone assumes recovery is fast until they measure it. Nightly backups mean up to 24 hours of data loss — decide that consciously."
  fix: "State the maximum tolerable downtime and data loss. Configure backups and failover to meet them. If they do not match, either change the configuration or change the promise."
  evidence: "RTO/RPO statement plus the measured restore time from DATA-02."
  enforce: "Reviewed when the architecture or the business promise changes."

- id: REL-02
  domain: D11
  tier: P1
  weight: 4
  when: [is_public]
  title: "An incident runbook exists covering the realistic failure set"
  risk: "At 2am with users complaining, nobody invents a good process."
  fix: "Write procedures for: app down, database down, deploy gone bad, payment webhook failing, third-party provider outage, spend spike, secret leaked, suspected data exposure, restore from backup. Use knowledge file X5-operational-templates.md section `RUNBOOK.md`."
  evidence: "Completed runbook with real commands, dashboard links, and provider support contacts."
  enforce: "Runbook reviewed after every incident."

- id: REL-03
  domain: D11
  tier: P1
  weight: 3
  when: [is_public]
  title: "Someone is on call, or there is an explicit documented decision that nobody is"
  risk: "Ambiguity about who responds guarantees a slow response."
  fix: "Name who gets paged, how, and the expected response window. If the honest answer is 'best effort during business hours', write that down and set customer expectations accordingly."
  evidence: "Named owner and notification path, tested end to end."
  enforce: "Escalation path documented and rehearsed."

- id: REL-04
  domain: D11
  tier: P1
  weight: 3
  when: [has_pii]
  title: "A breach and data-exposure response plan exists with notification timelines"
  risk: "GDPR requires notification to the supervisory authority within 72 hours of awareness. US state laws and sector rules impose their own clocks. You cannot draft this during the incident."
  fix: "Written plan: contain, assess scope, preserve evidence, determine notification obligations, notify, remediate, post-mortem. Identify who makes the notification call and which counsel to contact."
  evidence: "The plan, with named roles."
  enforce: "Reviewed annually and after any near-miss."

- id: REL-05
  domain: D11
  tier: P2
  weight: 2
  when: [is_public]
  title: "Incidents get blameless post-mortems and produce concrete follow-up actions"
  risk: "Without them the same outage happens repeatedly."
  fix: "Timeline, impact, root cause, what made detection or recovery slow, action items with owners and dates. Use knowledge file X5-operational-templates.md section `INCIDENT-POSTMORTEM.md`."
  evidence: "The most recent post-mortem, or a statement that no incidents have occurred."
  enforce: "Post-mortem is a required step for any user-visible incident."

- id: REL-06
  domain: D11
  tier: P2
  weight: 2
  when: [is_public]
  title: "There is a way to tell customers what is happening"
  risk: "Silence during an outage costs more trust than the outage."
  fix: "Status page or a pre-agreed communication channel and a template message. Decide the threshold for posting."
  evidence: "Status page URL or the documented communication plan and template."
  enforce: "Included in the runbook's first steps."

- id: REL-07
  domain: D11
  tier: P2
  weight: 2
  when: [has_third_party]
  title: "Third-party outage behavior is defined and degraded mode is tested"
  risk: "Your app's availability is the product of every dependency's availability unless you design otherwise."
  fix: "For each critical provider decide: fail closed, fail open, queue, or serve stale. Test by pointing the client at a failing endpoint."
  evidence: "Dependency table with the degraded behavior, plus a test showing it works."
  enforce: "Chaos-style dependency failure test in the suite."

# ============================================================
# D12 - PERFORMANCE, CACHING & SCALE
# ============================================================
- id: PERF-01
  domain: D12
  tier: P1
  weight: 4
  when: [always]
  title: "Database connection pooling is configured and the connection math works"
  risk: "Serverless plus a connection-per-invocation pattern exhausts Postgres connections at a traffic level far below what you expect. This is the most common first-scale failure."
  fix: "Use a pooler (PgBouncer, Supavisor, RDS Proxy, or your provider's). Compute: max concurrent instances x connections per instance must stay under the database limit with headroom."
  evidence: "The arithmetic, the configured pool size, and the database max_connections."
  enforce: "Alert on connection-pool saturation."

- id: PERF-02
  domain: D12
  tier: P1
  weight: 3
  when: [always]
  title: "N+1 queries and unindexed slow queries have been found and fixed"
  risk: "ORM-generated N+1 patterns are invisible at ten rows and fatal at ten thousand. AI-generated data access is especially prone to them."
  fix: "Enable slow-query logging and pg_stat_statements or equivalent. Profile the top three pages. Add eager loading and the indexes the data demands."
  evidence: "Before/after query counts and timings for the heaviest endpoints."
  enforce: "Slow-query alert threshold configured; query-count assertions on hot paths."

- id: PERF-03
  domain: D12
  tier: P1
  weight: 3
  when: [is_public]
  title: "Static assets are served from a CDN with correct cache headers"
  risk: "Serving assets from the application server wastes compute and produces a slow experience far from your region."
  fix: "Immutable, content-hashed asset filenames with long max-age. Short or no-cache for HTML. Image optimization and modern formats."
  evidence: "Response headers for a hashed asset and for an HTML document."
  enforce: "Set by the framework/platform configuration."

- id: PERF-04
  domain: D12
  tier: P1
  weight: 4
  when: [is_public]
  title: "Private data is never cached where another user can receive it"
  risk: "A CDN or shared cache serving user A's dashboard to user B is a data breach caused by a cache header."
  fix: "Cache-Control: private, no-store on authenticated responses. Any cache key for user-specific data must include the user or tenant identity. Audit CDN rules for paths that bypass authentication."
  evidence: "Header inspection on an authenticated response plus a two-user cache test."
  enforce: "Test asserting no-store on authenticated routes."

- id: PERF-05
  domain: D12
  tier: P2
  weight: 3
  when: [is_public]
  title: "A load test has been run at a realistic launch multiple and the breaking point is known"
  risk: "'It works for me' is a sample size of one. You need the number where it stops working."
  fix: "k6, Artillery, or Locust against staging. Ramp until something breaks. Record where latency degrades, where connections saturate, and where third-party limits trigger."
  evidence: "Load test report with the ramp profile and the identified breaking point."
  enforce: "Re-run before major launches and after architecture changes."

- id: PERF-06
  domain: D12
  tier: P2
  weight: 2
  when: [always]
  title: "Expensive repeated work is cached with a defined invalidation strategy"
  risk: "Recomputing the same expensive result per request wastes money and latency; caching it wrong serves stale or wrong-user data."
  fix: "Cache read-heavy, slow, tolerably-stale results. Always define the invalidation trigger before adding the cache. Include tenant/user in the key when data is scoped."
  evidence: "Cache hit rate plus the documented invalidation rule."
  enforce: "Hit rate monitored."

- id: PERF-07
  domain: D12
  tier: P2
  weight: 2
  when: [is_public]
  title: "A scaling plan exists for the next order of magnitude"
  risk: "Success is the most common outage cause."
  fix: "Identify the next bottleneck (connections, a single worker, an external rate limit, a queue) and write down what you would do. Autoscaling configured where available."
  evidence: "One page naming the next three bottlenecks and the response to each."
  enforce: "Revisited when traffic doubles."

# ============================================================
# D13 - COST CONTROL & ABUSE PREVENTION
# ============================================================
- id: COST-01
  domain: D13
  tier: P0
  weight: 5
  when: [has_ai]
  title: "No paid inference endpoint is publicly reachable without authentication and a rate limit"
  risk: "Unbounded Consumption is LLM10 in the OWASP LLM Top 10. A public AI endpoint is a credit card someone else is holding."
  fix: "Require authentication. Per-user and per-IP limits. A global circuit breaker that disables the feature above a spend threshold."
  evidence: "Call the endpoint unauthenticated (rejected) and hammer it authenticated (throttled). Show both."
  enforce: "Limits enforced at the gateway; breaker tested."

- id: COST-02
  domain: D13
  tier: P0
  weight: 4
  when: [has_ai, has_third_party]
  title: "Hard spend caps and billing alerts exist at every paid provider"
  risk: "Providers will happily bill you for a runaway loop. The story of the $12,000 weekend is common and entirely preventable."
  fix: "Set provider-side hard limits where available and budget alerts everywhere. Alert at 50%, 80%, and 100% of expected monthly spend. Include hosting, database, storage, and egress, not just AI."
  evidence: "Screenshot or config of the caps and alert thresholds per provider."
  enforce: "Alerts route to a person; caps configured provider-side."

- id: COST-03
  domain: D13
  tier: P1
  weight: 4
  when: [is_public]
  title: "Rate limiting exists on all public and expensive endpoints"
  risk: "Without limits, one script can exhaust your database connections, your third-party quota, and your budget simultaneously."
  fix: "Layered limits: per IP, per authenticated user, per account/tenant, and global. Return 429 with Retry-After. Apply at the edge where possible so the request never reaches your compute."
  evidence: "Load a public endpoint past the limit; show 429s."
  enforce: "Limits configured in edge/gateway config with tests."

- id: COST-04
  domain: D13
  tier: P1
  weight: 3
  when: [has_ai, has_third_party]
  title: "Cost per user and per action is measured, not estimated"
  risk: "A unit economics surprise at scale is a business failure, not a technical one."
  fix: "Attribute every paid call to a user, account, and feature. Log tokens or units and an estimated cost. Build a cost-per-active-user figure and watch it."
  evidence: "The cost attribution table from knowledge file D14-ai-and-agents.md, populated with real numbers."
  enforce: "Cost dashboard exists and is reviewed."

- id: COST-05
  domain: D13
  tier: P1
  weight: 3
  when: [is_public]
  title: "Abuse paths have been tested: signup spam, scraping, resource exhaustion"
  risk: "Free tiers, signup flows, and file processing are abused within days of any public launch."
  fix: "Bot protection or CAPTCHA on signup, email verification before resource-consuming actions, quotas on free tiers, size limits on anything processed."
  evidence: "Attempt each abuse path; document what stopped it."
  enforce: "Protections enabled with monitoring on signup anomalies."

- id: COST-06
  domain: D13
  tier: P2
  weight: 2
  when: [has_payments]
  title: "Billing events reconcile with usage and entitlements"
  risk: "Silent revenue leakage: cancelled subscriptions still serving, failed renewals still granting access, usage not billed."
  fix: "Handle the full webhook set: created, updated, cancelled, payment failed, refunded, disputed. Test each in the provider's test mode. Reconcile entitlements against the provider as the source of truth."
  evidence: "Test-mode run of every subscription lifecycle event with the resulting entitlement state."
  enforce: "Automated reconciliation job comparing local entitlements to the provider."

- id: COST-07
  domain: D13
  tier: P2
  weight: 2
  when: [always]
  title: "Infrastructure spend is forecast for the next 90 days at expected growth"
  risk: "Pricing cliffs (egress, function invocations, log ingestion, vector storage) surface at exactly the wrong moment."
  fix: "Model current cost per active user and project it. Identify which line item grows fastest and what the mitigation is."
  evidence: "A simple forecast table with the top three cost drivers."
  enforce: "Reviewed monthly."

# ============================================================
# D14 - AI & AGENT SAFETY AND ECONOMICS
# ============================================================
- id: AI-01
  domain: D14
  tier: P0
  weight: 5
  when: [has_ai]
  title: "Model provider calls happen server-side only, through a single gateway module"
  risk: "A provider key in client code is stolen immediately and billed to you. A scattered call pattern makes quotas, caching, and cost tracking impossible."
  fix: "One provider wrapper. All calls route through it. Authentication, quota enforcement, cost logging, retry, fallback, and telemetry live there."
  evidence: "Grep for direct SDK usage outside the wrapper and for keys in the client bundle; both empty."
  enforce: "Lint rule blocking direct SDK imports; bundle scan in CI."

- id: AI-02
  domain: D14
  tier: P0
  weight: 5
  when: [has_agents]
  title: "The lethal trifecta is broken: no single agent context combines private data, untrusted content, and an external communication channel"
  risk: "Prompt injection is unsolved. Independent 2025-2026 evaluations found over 90% attack success against published defenses under adaptive attack. The only reliable protection is architectural: deny the attacker a path to exfiltrate."
  fix: "Apply Meta's Rule of Two — at most two of (untrusted input, sensitive data access, ability to change state or communicate externally) without human supervision. Egress allowlist. Separate the agent that reads untrusted content from the agent holding credentials. Consider plan-then-execute, dual-LLM, or map-reduce isolation patterns."
  evidence: "A data-flow diagram per agent workflow marking which of the three properties it holds and how the third is prevented."
  enforce: "Egress allowlist enforced at the network layer; architecture reviewed when tools are added."

- id: AI-03
  domain: D14
  tier: P0
  weight: 4
  when: [has_agents]
  title: "Agent tools are individually scoped and no agent holds production credentials"
  risk: "The best-documented AI coding disaster deleted a production database. The root cause was not the deletion — it was that the agent had production credentials at all. Instructions in a prompt are not a security control."
  fix: "Each tool gets its own least-privilege credential. No blanket database or shell access. Read and write are separate tools. Destructive operations require an out-of-band confirmation the model cannot issue itself."
  evidence: "Tool inventory listing each tool, its credential, its blast radius, and whether it requires approval."
  enforce: "Credentials issued per tool by infrastructure, not shared from a single environment variable."

- id: AI-04
  domain: D14
  tier: P1
  weight: 4
  when: [has_agents]
  title: "Irreversible and externally visible actions require human approval with full parameter visibility"
  risk: "An approval prompt that says 'Allow?' without showing the payload trains users to click yes. Approval fatigue is itself a documented attack technique."
  fix: "Show exactly what will happen — recipient, amount, target, full command. Rate-limit approval requests so flooding cannot exhaust attention. Log every approval and denial."
  evidence: "Screenshot of an approval prompt showing complete parameters."
  enforce: "Approval is enforced server-side, not by the model choosing to ask."

- id: AI-05
  domain: D14
  tier: P1
  weight: 3
  when: [has_ai]
  title: "Model output is treated as untrusted input everywhere it is used"
  risk: "LLM05 Improper Output Handling. Model output rendered as HTML is XSS; passed to a shell is command injection; passed to SQL is injection; used in a redirect is an open redirect."
  fix: "Validate and encode model output at every sink exactly as you would user input. Parse structured output against a schema. Never eval, never interpolate into a shell."
  evidence: "Inventory of output sinks and the validation applied at each."
  enforce: "Schema validation on structured outputs; SAST rules on the sinks."

- id: AI-06
  domain: D14
  tier: P1
  weight: 3
  when: [has_ai]
  title: "Token usage and cost are logged per request with full attribution"
  risk: "Without attribution you cannot find the expensive feature, the abusive user, or the runaway loop."
  fix: "Log provider, model, feature, user, account, input tokens, output tokens, cached tokens, latency, and estimated cost for every call."
  evidence: "Sample log lines plus an aggregate by feature."
  enforce: "Emitted by the gateway wrapper for every call."

- id: AI-07
  domain: D14
  tier: P1
  weight: 3
  when: [has_ai]
  title: "Per-user and per-tier quotas are token-budgeted, not request-counted"
  risk: "One agentic user turn can fan out to hundreds of model calls. Request counting is meaningless for agents."
  fix: "Token budgets per user per period, separate ceilings for input and output, a per-session cost cap, and hard limits on agent loop iterations and tool-call depth."
  evidence: "Quota configuration plus a test showing enforcement and a graceful message at the limit."
  enforce: "Enforced in the gateway; breach alerts."

- id: AI-08
  domain: D14
  tier: P1
  weight: 3
  when: [has_ai]
  title: "Provider failure degrades gracefully"
  risk: "Model providers have outages and rate limits. An unhandled 429 or 503 becomes a broken product."
  fix: "Timeouts, bounded retries with backoff, a fallback model or provider, and a clear user-facing message or queued retry. Never silently return an empty result."
  evidence: "Simulate a provider failure; show the degraded behavior."
  enforce: "Fallback path covered by a test."

- id: AI-09
  domain: D14
  tier: P1
  weight: 3
  when: [has_ai]
  title: "An eval set exists for the AI feature and runs before releases"
  risk: "Prompt and model changes are untestable by intuition. Non-determinism means a change that looks fine can degrade a whole category of inputs."
  fix: "Build a golden set of 50-150 real examples from actual usage, weighted toward observed failure modes. Prefer deterministic assertions and code-based checks over LLM judges. If you use a judge, validate it against human labels and keep it a scoped binary question."
  evidence: "The eval set, the pass criteria, and a run result."
  enforce: "Evals run in CI on any prompt, model, or retrieval change."

- id: AI-10
  domain: D14
  tier: P1
  weight: 3
  when: [has_ai]
  title: "Prompt injection has been tested against your actual attack surface"
  risk: "Every place untrusted content enters the model context — documents, web pages, emails, tickets, tool output, other users' content — is an injection surface. Tool schemas are injection surface too, not just descriptions."
  fix: "Build an injection test suite reflecting your real inputs. Test instruction override, data exfiltration attempts, tool misuse, and system prompt extraction. Track the success rate as a metric across releases."
  evidence: "Test suite with attempt/result and a measured success rate."
  enforce: "Injection suite runs in CI; success rate tracked over time."

- id: AI-11
  domain: D14
  tier: P2
  weight: 3
  when: [has_ai]
  title: "Cost is engineered: caching, routing, and batching where they apply"
  risk: "Sending every request to the largest model with a cold cache is typically 5-20x more expensive than necessary."
  fix: "Prompt caching on stable prefixes — verify you exceed the model's minimum cacheable size and that no per-request value sits inside the cached prefix, which silently zeroes hit rate. Route simple requests to cheaper models. Use batch APIs for anything not latency-sensitive. Cap output tokens, since output is the dominant cost term."
  evidence: "Cache hit rate, model distribution by tier, and the before/after cost per action."
  enforce: "Cache hit rate and cost per action monitored."

- id: AI-12
  domain: D14
  tier: P2
  weight: 2
  when: [has_ai]
  title: "AI behavior is traced and reviewed against real production traffic"
  risk: "Failure modes you have not seen cannot be in your eval set. Error analysis on real traces is the highest-value evaluation activity."
  fix: "Trace every AI request with inputs, outputs, tool calls, latency, and cost. Sample and manually review 20-100 traces on a regular cadence; group failures into a taxonomy; promote recurring failures into the eval suite."
  evidence: "Trace samples plus a failure taxonomy with counts."
  enforce: "Review cadence scheduled with an owner."

- id: AI-13
  domain: D14
  tier: P2
  weight: 2
  when: [has_ai]
  title: "AI features are disclosed to users where required and outputs are labelled"
  risk: "EU AI Act Article 50 transparency obligations apply to systems that interact with people or generate synthetic content. Verify the current status and dates against primary sources before relying on any timeline."
  fix: "Disclose that the user is interacting with an AI system. Mark AI-generated or manipulated content. Document the disclosure in your privacy policy."
  evidence: "Screenshot of the disclosure in product."
  enforce: "Part of the release checklist for AI features."

- id: AI-14
  domain: D14
  tier: P2
  weight: 2
  when: [has_agents]
  title: "Third-party tool and MCP server integrations are vetted and pinned"
  risk: "Tool poisoning, rug pulls where a server changes its tool definitions after approval, and cross-server shadowing are documented attack classes with real incidents including a CVSS 9.6 remote code execution in a popular MCP proxy."
  fix: "Maintain a registry of approved servers/tools. Pin tool definitions by hash and alert on drift. Run local servers sandboxed. Require OAuth with audience-bound tokens rather than shared credentials. Human approval for adding any tool."
  evidence: "Approved tool registry with pinned definition hashes."
  enforce: "Drift detection alerting on tool definition changes."

- id: AI-15
  domain: D14
  tier: P2
  weight: 2
  when: [has_agents]
  title: "Agent memory and retrieved context cannot be poisoned across users or sessions"
  risk: "Memory poisoning is a top-ranked agentic threat. Content written by one user that persists into another user's context is a cross-user injection channel."
  fix: "Scope memory and vector stores by user or tenant in the retrieval filter, not just at write time. Treat anything retrieved as untrusted. Expire memory. Store only what changes future behavior."
  evidence: "Test: user A stores an injection payload; user B's retrieval does not surface it."
  enforce: "Tenant filter enforced in the retrieval layer with a test."

# ============================================================
# D15 - PRIVACY, LEGAL & COMPLIANCE
# ============================================================
# NOT LEGAL ADVICE. Verify current requirements and dates against primary
# sources and qualified counsel. Regulations in this domain change frequently.
- id: LEG-01
  domain: D15
  tier: P0
  weight: 4
  when: [has_pii]
  title: "A privacy policy and terms of service are published and accurate"
  risk: "Collecting personal data without a privacy notice is a violation in most jurisdictions and blocks app store review."
  fix: "Publish both. The privacy policy must actually describe what you collect, why, who you share it with (list your processors), how long you keep it, and how users exercise their rights. A generic template that misdescribes your processing is worse than none."
  evidence: "Live URLs plus a mapping from each policy claim to the actual system behavior."
  enforce: "Reviewed when data flows change."

- id: LEG-02
  domain: D15
  tier: P0
  weight: 4
  when: [has_pii]
  title: "A data inventory exists: what you collect, where it lives, who it goes to"
  risk: "You cannot honor a deletion request, answer a security questionnaire, or assess breach scope without knowing where data is."
  fix: "Table of data element, purpose, store, retention, and every third party that receives it (analytics, error tracking, AI providers, email, support tools). Error trackers and AI providers are the most commonly forgotten processors."
  evidence: "The completed inventory."
  enforce: "Updated when a new vendor or data field is added; part of the PR template for schema changes."

- id: LEG-03
  domain: D15
  tier: P1
  weight: 3
  when: [has_pii]
  title: "Data subject rights are actually operable: access, deletion, correction, export"
  risk: "Rights requests carry statutory deadlines. A manual process you have never run will miss them."
  fix: "A documented procedure, ideally self-service in product. Must reach every store including backups (with a stated expiry window), analytics, and downstream processors."
  evidence: "Execute each request type against a test account end to end; document elapsed time."
  enforce: "Self-service in product, or a tracked queue with SLA monitoring."

- id: LEG-04
  domain: D15
  tier: P1
  weight: 3
  when: [eu_users]
  title: "GDPR basics are in place: lawful basis, processor agreements, transfer mechanism, cookie consent"
  risk: "Processor agreements with every vendor handling personal data are mandatory, as is a valid international transfer mechanism."
  fix: "Identify the lawful basis per processing purpose. Execute a DPA with every processor. Confirm your transfer mechanism. Cookie/tracker consent must be genuine opt-in for non-essential trackers, with refusal as easy as acceptance. Verify current requirements — this area moves."
  evidence: "DPA list, lawful basis table, consent banner behavior verified with a network trace showing no non-essential trackers fire before consent."
  enforce: "Consent gating enforced in code; new vendors require a DPA."

- id: LEG-05
  domain: D15
  tier: P1
  weight: 3
  when: [us_state_privacy]
  title: "US state privacy obligations are handled, including universal opt-out signals"
  risk: "The number of US states with comprehensive privacy laws has grown substantially and several require honoring browser-level opt-out signals such as Global Privacy Control. Verify which states apply to you and their current thresholds."
  fix: "Determine applicability by your consumer counts and revenue. Implement opt-out of sale/sharing, honor GPC, publish the required notices, and handle sensitive-data limits."
  evidence: "Applicability analysis plus a test showing GPC is detected and honored."
  enforce: "GPC handling covered by a test."

- id: LEG-06
  domain: D15
  tier: P1
  weight: 3
  when: [has_payments]
  title: "Payment card scope is minimized and the applicable PCI obligations are known"
  risk: "Embedding payment fields on your own page rather than using a hosted field or redirect materially expands your PCI scope, including requirements around managing and monitoring scripts on payment pages. Verify current PCI DSS requirements."
  fix: "Prefer a hosted checkout or the provider's iframe/hosted fields so card data never touches your servers or DOM. Never log or store card numbers. Confirm which self-assessment questionnaire actually applies to your integration."
  evidence: "Integration type documented, plus confirmation no card data touches your systems or logs."
  enforce: "CSP restricting scripts on payment pages; script inventory maintained."

- id: LEG-07
  domain: D15
  tier: P1
  weight: 3
  when: [has_payments]
  title: "Subscription, refund, and cancellation terms are clear and cancellation is easy"
  risk: "Consumer protection regulators and app stores both take an interest in hard-to-cancel subscriptions. Requirements vary by jurisdiction and change; verify current rules."
  fix: "Disclose price, renewal cadence, and cancellation method before purchase. Make cancellation available through the same channel as signup. Send renewal reminders where required."
  evidence: "Screenshots of the disclosure and the cancellation flow."
  enforce: "Part of the release checklist for billing changes."

- id: LEG-08
  domain: D15
  tier: P2
  weight: 2
  when: [is_regulated]
  title: "Sector-specific obligations are identified and the controls mapped"
  risk: "HIPAA, FERPA, GLBA, SOC 2, and similar regimes impose specific controls. Discovering them during an enterprise sales cycle costs months."
  fix: "Identify the regime, obtain necessary agreements (e.g. a BAA before any regulated data flows), and map each required control to a specific implementation. Compliance automation platforms help but do not substitute for the controls."
  evidence: "Control mapping document."
  enforce: "Evidence collection automated where possible; owner assigned."

- id: LEG-09
  domain: D15
  tier: P2
  weight: 2
  when: [is_public]
  title: "Accessibility obligations have been assessed for your markets"
  risk: "Accessibility requirements now carry legal force in multiple jurisdictions with staggered deadlines and exemptions that may or may not apply to you. Verify current scope and dates."
  fix: "Determine which regimes apply. WCAG 2.2 Level AA is the practical target in most cases. Publish an accessibility statement if required."
  evidence: "Applicability note plus the current conformance status from FE-05 and FE-06."
  enforce: "Accessibility checks in CI; statement maintained."

- id: LEG-10
  domain: D15
  tier: P2
  weight: 2
  when: [has_ugc]
  title: "Content moderation, reporting, and takedown paths exist"
  risk: "Any surface where users publish to other users attracts abuse, illegal content, and copyright claims. Platform obligations vary by jurisdiction and scale."
  fix: "A reporting mechanism, a defined review process, a takedown path, and terms that permit removal. Copyright agent designation where applicable."
  evidence: "Reporting flow and the documented review process."
  enforce: "Reports route to a monitored queue with an owner."

# ============================================================
# D16 - TESTING & VERIFICATION
# ============================================================
- id: TEST-01
  domain: D16
  tier: P0
  weight: 5
  when: [always]
  title: "Automated tests cover authorization on every endpoint"
  risk: "This is the single highest-value test suite in an AI-built codebase, because missing authorization is the most common and most damaging AI omission."
  fix: "Parameterized test iterating every endpoint x (anonymous, wrong user, wrong tenant, wrong role) asserting the correct rejection."
  evidence: "The test file and a passing run showing the endpoint coverage count."
  enforce: "Test fails when a new endpoint is added without an entry."

- id: TEST-02
  domain: D16
  tier: P1
  weight: 4
  when: [always]
  title: "The critical user journeys have end-to-end tests"
  risk: "Unit tests pass while the product is broken, because AI-generated code fails at wiring rather than at logic."
  fix: "Playwright (or equivalent) covering the three to six journeys that would put you on the phone with customers. Seed data via API or direct database access, reuse authenticated state, never drive login through the UI except in the login test."
  evidence: "Test run output listing the covered journeys."
  enforce: "Smoke subset runs on every PR; full suite on merge and nightly."

- id: TEST-03
  domain: D16
  tier: P1
  weight: 4
  when: [has_payments]
  title: "The full payment lifecycle is tested in the provider's test mode"
  risk: "Payment bugs are the most expensive category: they lose money invisibly and destroy trust."
  fix: "Test success, decline, 3DS challenge, webhook signature verification, duplicate webhook delivery, subscription cancellation, failed renewal, refund, dispute, and double-submit idempotency."
  evidence: "Completed payment test matrix with results."
  enforce: "Automated where the provider supports it; manual matrix re-run before billing changes."

- id: TEST-04
  domain: D16
  tier: P1
  weight: 3
  when: [always]
  title: "Tests actually assert; coverage is measured on the diff, not chased globally"
  risk: "AI-generated tests are disproportionately prone to executing code with vacuous assertions, inflating coverage while detecting nothing."
  fix: "Review AI-written tests for real assertions. Gate on coverage of changed lines rather than a global percentage. Run mutation testing (e.g. Stryker) once as an audit of the existing suite to find the hollow tests."
  evidence: "Diff coverage report plus a mutation score for the core modules."
  enforce: "Diff coverage threshold as a required check."

- id: TEST-05
  domain: D16
  tier: P1
  weight: 3
  when: [is_public]
  title: "The API has been fuzzed against its schema"
  risk: "Edge-case inputs producing 500s, responses that drift from the documented contract, and validation that accepts invalid data are exactly the AI-generated handler failure profile."
  fix: "Run a schema-driven fuzzer (e.g. Schemathesis) against your OpenAPI spec. It requires no test authoring and finds this class immediately."
  evidence: "Fuzzer run output and the issues fixed."
  enforce: "Fuzz run in CI or nightly against staging."

- id: TEST-06
  domain: D16
  tier: P1
  weight: 3
  when: [always]
  title: "Tests run against a real database, not mocks, for data-layer behavior"
  risk: "Mocked database tests validate your mocks. Constraint violations, transaction behavior, and RLS policies only appear against the real engine."
  fix: "Testcontainers or a dedicated test database. Isolate via per-test transactions, template databases, or per-worker schemas so tests can run in parallel."
  evidence: "Test setup showing the real engine, plus a parallel run."
  enforce: "CI provisions the database automatically."

- id: TEST-07
  domain: D16
  tier: P2
  weight: 2
  when: [always]
  title: "Flaky tests are quarantined and fixed, not retried into silence"
  risk: "A suite that fails randomly gets ignored, and then it is worse than no suite."
  fix: "Retries with trace capture on first retry so you can actually diagnose. Tag persistent flakes into a non-blocking project and fix them on a schedule. Never leave a permanently red check."
  evidence: "Flake list with owners and the trend."
  enforce: "Flake rate tracked; quarantine has an expiry."

- id: TEST-08
  domain: D16
  tier: P2
  weight: 2
  when: [always]
  title: "A human has read the security-critical code, not just the tests"
  risk: "METR's randomized trial found experienced developers were 19% slower with AI assistance while believing they were 20% faster — self-assessment of AI-assisted work is demonstrably unreliable. External verification is required."
  fix: "Line-by-line human review of auth, authorization, payment, migration, and any code touching secrets. Use knowledge file X2-ai-code-failure-modes.md as the review checklist."
  evidence: "Review record naming the reviewer, the files, and the date."
  enforce: "CODEOWNERS requires review on those paths."

# ============================================================
# D17 - MOBILE & APP STORE
# ============================================================
# Store policies change frequently. Verify every requirement against the
# current Apple App Store Review Guidelines and Google Play policy pages
# before submission; treat the items below as the checklist, not the spec.
- id: MOB-01
  domain: D17
  tier: P0
  weight: 4
  when: [has_mobile]
  title: "Account deletion is available in-app for any app that supports account creation"
  risk: "This is a standing Apple review requirement and a Google Play policy requirement. It is one of the most common avoidable rejections."
  fix: "In-app initiation of full account and data deletion, not merely deactivation, not email-only. Provide a web-accessible deletion path where required."
  evidence: "Screen recording of the in-app deletion flow completing."
  enforce: "Part of the release checklist."

- id: MOB-02
  domain: D17
  tier: P0
  weight: 4
  when: [has_mobile]
  title: "Privacy declarations match actual data collection, including every SDK"
  risk: "Apple privacy labels and manifests and Google Play's Data safety form must reflect reality including third-party SDK behavior. Mismatches cause rejection and, later, enforcement."
  fix: "Enumerate every SDK and what it collects. Complete the privacy declarations honestly. Provide required-reason API declarations and SDK privacy manifests where mandated. Verify current requirements with Apple and Google directly."
  evidence: "SDK inventory mapped to each declared data category."
  enforce: "Inventory updated whenever a dependency is added."

- id: MOB-03
  domain: D17
  tier: P0
  weight: 3
  when: [has_mobile]
  title: "Monetization complies with current store rules"
  risk: "Payment rules — in-app purchase requirements, external link entitlements, and anti-steering provisions — have changed repeatedly through litigation and vary by region. Assumptions here get apps removed."
  fix: "Determine which purchase mechanism your content requires. Verify current rules for your regions directly from the store policies before shipping. Implement receipt validation server-side, never client-side."
  evidence: "Policy determination note plus server-side receipt validation code."
  enforce: "Reviewed before every release that touches monetization."

- id: MOB-04
  domain: D17
  tier: P1
  weight: 3
  when: [has_mobile]
  title: "Target SDK/API level and platform technical requirements meet current store minimums"
  risk: "Both stores enforce rolling minimum SDK/API levels and periodic technical requirements. Missing a deadline blocks updates entirely — including security fixes."
  fix: "Check the current required target API level and build SDK for both stores, and any active platform requirements. Calendar the next deadline."
  evidence: "Build configuration values plus the current published requirement."
  enforce: "Calendar reminder ahead of each announced deadline."

- id: MOB-05
  domain: D17
  tier: P1
  weight: 3
  when: [has_mobile]
  title: "A forced-update mechanism exists"
  risk: "Without one, a client-side bug or an API breaking change strands users on a broken version indefinitely."
  fix: "Server-driven minimum-version check that blocks the app with an update prompt. Version your API so old clients degrade rather than break."
  evidence: "Demonstrate the block by lowering the client version."
  enforce: "Minimum version is a server-side configuration value."

- id: MOB-06
  domain: D17
  tier: P1
  weight: 3
  when: [has_mobile]
  title: "Crash reporting and release-tagged error tracking are live on mobile"
  risk: "Mobile crashes are invisible without instrumentation, and store review surfaces crash rate."
  fix: "Crashlytics, Sentry, or equivalent with symbolication and release tagging. Watch crash-free-session rate per release."
  evidence: "Dashboard showing crash-free rate for the current release."
  enforce: "Alert on crash-rate regression after release."

- id: MOB-07
  domain: D17
  tier: P1
  weight: 3
  when: [has_mobile]
  title: "Secrets are not embedded in the app binary and the API does not trust the client"
  risk: "Mobile binaries are trivially decompiled. Anything shipped is public. API keys in an app are public keys."
  fix: "No privileged keys in the binary. Every mobile-facing API endpoint enforces authentication and authorization independently. Use platform attestation (App Attest / Play Integrity) if you need to limit access to genuine clients — but never as the only control."
  evidence: "String extraction on the built binary showing no privileged secrets."
  enforce: "Binary secret scan in the release pipeline."

- id: MOB-08
  domain: D17
  tier: P1
  weight: 2
  when: [has_mobile]
  title: "Sensitive data uses platform secure storage, and offline behavior is defined"
  risk: "Tokens in plain preferences or unencrypted local databases are readable on a compromised device."
  fix: "Keychain / Keystore for credentials. Define what works offline, how conflicts resolve, and what the app shows with no connectivity."
  evidence: "Storage code plus an airplane-mode walkthrough of core screens."
  enforce: "Covered by device tests."

- id: MOB-09
  domain: D17
  tier: P2
  weight: 2
  when: [has_mobile]
  title: "Deep links and universal links are verified and handle unauthenticated and cold-start cases"
  risk: "A broken universal link silently falls back to the browser and breaks every email and notification flow."
  fix: "Verify the association files. Test cold start, warm start, logged out, and invalid target for each link type."
  evidence: "Link test matrix with results."
  enforce: "Included in the release checklist."

- id: MOB-10
  domain: D17
  tier: P2
  weight: 2
  when: [has_mobile]
  title: "Push notification credentials and their expiry are tracked, and rollout is staged"
  risk: "Expired push credentials silently kill notifications. A full-population release with no staged rollout has no abort option."
  fix: "Record credential expiry dates with calendar reminders. Use phased/staged rollout on both stores and define the halt criteria."
  evidence: "Credential expiry register plus the staged rollout configuration."
  enforce: "Expiry monitored; staged rollout is the default release mode."

# ============================================================
# D18 - DOCUMENTATION & HANDOFF
# ============================================================
- id: DOC-01
  domain: D18
  tier: P1
  weight: 4
  when: [always]
  title: "README lets a new developer run the project locally from zero"
  risk: "Undocumented setup is the most common reason a project stalls when the original builder is unavailable."
  fix: "Prerequisites, install, environment variable names (never values), database setup and seed, run, test, and common problems. Verify by following it on a clean machine or container."
  evidence: "Someone other than the author followed it successfully, or a clean-container run of the documented steps."
  enforce: "Setup steps exercised by CI (the CI workflow is the executable README)."

- id: DOC-02
  domain: D18
  tier: P1
  weight: 3
  when: [always]
  title: "Architecture notes exist: system diagram, data model, vendor map, auth model"
  risk: "Without them, every change requires re-deriving the system from source, which is where regressions come from."
  fix: "Use knowledge file X5-operational-templates.md section `ARCHITECTURE.md`. Include the request path, the data model, every third-party vendor and what it does, the permission model, background jobs, and where money and personal data flow."
  evidence: "The completed document."
  enforce: "Updated as part of any architectural change PR."

- id: DOC-03
  domain: D18
  tier: P1
  weight: 3
  when: [is_public]
  title: "Deploy and rollback procedures are written down and executable by someone else"
  risk: "If only one person can deploy, that person is a single point of failure for every incident."
  fix: "Exact commands or console steps, environment by environment, including the migration procedure and the rollback path."
  evidence: "Another person executed a deploy following only the document."
  enforce: "Deployment is automated; the document describes the pipeline and the manual override."

- id: DOC-04
  domain: D18
  tier: P2
  weight: 2
  when: [has_team]
  title: "Significant decisions are recorded with their reversal path"
  risk: "Six months later nobody remembers why the odd choice was made, so it gets undone and the original problem returns."
  fix: "A short ADR per significant decision: context, decision, alternatives, consequences, reversal plan. Use knowledge file X5-operational-templates.md section `ADR.md`."
  evidence: "ADR directory with entries for the major choices."
  enforce: "ADR required for architectural PRs."

- id: DOC-05
  domain: D18
  tier: P2
  weight: 2
  when: [always]
  title: "Known limitations, deliberate shortcuts, and technical debt are listed honestly"
  risk: "Undocumented shortcuts become production incidents that surprise everyone including the person who took them."
  fix: "A LIMITATIONS section listing what is not handled, what will break at scale, and what was deliberately deferred with the trigger for revisiting it."
  evidence: "The list."
  enforce: "Reviewed each FINISHER run."

# ============================================================
# D19 - PRODUCT TRUTH & OUTCOME MEASUREMENT
# ============================================================
- id: PROD-01
  domain: D19
  tier: P1
  weight: 4
  when: [always]
  title: "The problem, the user, and the success metric are written down in one paragraph"
  risk: "A technically perfect product solving a problem nobody has is still a failure. This is the check most engineering checklists omit."
  fix: "One paragraph: who, what problem, what they do today instead, and the single number that proves it worked."
  evidence: "The paragraph, with the metric named and its current value."
  enforce: "Revisited each FINISHER run."

- id: PROD-02
  domain: D19
  tier: P1
  weight: 3
  when: [always]
  title: "A baseline was captured before changes so improvement is provable"
  risk: "Without a before, every after is an anecdote."
  fix: "Record time on task, error rate, volume handled, cost per task, completion rate, and support burden before optimizing."
  evidence: "The baseline table with the date it was captured."
  enforce: "Baseline recorded in the FINISHER ledger at run 1."

- id: PROD-03
  domain: D19
  tier: P2
  weight: 3
  when: [is_public]
  title: "Real user outcomes are measured after launch, not just system health"
  risk: "Green dashboards and zero adoption is the most common launch outcome for a technically sound product."
  fix: "Track activation, retention, and the core success metric. Set a review date and a decision rule for what you do if it is not met."
  evidence: "Post-launch metric report against the target."
  enforce: "Scheduled review with a named owner."

- id: PROD-04
  domain: D19
  tier: P2
  weight: 2
  when: [is_public]
  title: "There is a way for users to report problems and it is monitored"
  risk: "Users who cannot tell you it is broken simply leave."
  fix: "A support address, in-app feedback, or a form, routed somewhere a human reads with a stated response expectation."
  evidence: "The channel and its owner."
  enforce: "Response time tracked."

# ============================================================
# EMAIL / MESSAGING (spread across domains; all require has_email)
# ============================================================
- id: EMAIL-01
  domain: D06
  tier: P1
  weight: 3
  when: [has_email]
  title: "Sending domain is authenticated with SPF, DKIM, and an enforcing DMARC policy"
  risk: "Without DMARC enforcement anyone can spoof your domain to phish your own customers, and your transactional mail lands in spam — which silently breaks password reset and email verification, taking auth down with it."
  fix: "Publish SPF, sign with DKIM, and move DMARC from p=none to p=quarantine then p=reject once reports are clean. Send transactional mail from a dedicated subdomain so marketing reputation cannot poison password resets. Warm the domain before bulk sending."
  evidence: "dig TXT output for the SPF, DKIM selector, and DMARC records, plus a DMARC aggregate report showing alignment."
  enforce: "DNS records in infrastructure-as-code; DMARC reports monitored with an owner."

- id: EMAIL-02
  domain: D06
  tier: P1
  weight: 3
  when: [has_email]
  title: "User input never reaches mail headers, and links in mail are not open redirects"
  risk: "Header injection via a newline in a name or subject field lets an attacker add recipients or forge headers. A tracking or redirect link that accepts an arbitrary destination turns your authenticated domain into a phishing launcher."
  fix: "Strip CR/LF from every value that reaches a header. Never build headers by concatenation. Validate redirect targets against an allowlist. Render user content in the body only, escaped for HTML mail."
  evidence: "Submit a name containing a newline and a Bcc header; show it rejected or neutralised. Attempt a redirect to an external host; show it blocked."
  enforce: "Tests covering header injection and redirect validation."

- id: EMAIL-03
  domain: D13
  tier: P1
  weight: 3
  when: [has_email]
  title: "Any user-triggerable send is rate limited per recipient and per actor"
  risk: "Signup, password reset, invite, and share-by-email flows are mail-bombing tools. Abuse costs you money, gets your sending domain blocked, and harasses third parties who never used your product."
  fix: "Per-recipient-address and per-IP limits on every endpoint that can cause a send. Cap invites per account per day. Require verification before an account can send to arbitrary addresses."
  evidence: "Trigger 50 resets to one address; show throttling. Trigger invites past the cap; show rejection."
  enforce: "Limits enforced at the gateway or provider with a test."

- id: EMAIL-04
  domain: D10
  tier: P1
  weight: 3
  when: [has_email]
  title: "Bounces, complaints, and suppressions are processed and monitored"
  risk: "Continuing to send to hard bounces and complainers destroys sender reputation, and once reputation is gone transactional mail stops arriving. This is an invisible outage: nothing errors, users simply never receive the reset link."
  fix: "Consume the provider's bounce and complaint webhooks, maintain a suppression list, and never send to a suppressed address. Alert on bounce rate, complaint rate, and delivery-rate drops."
  evidence: "Suppression list with entries, plus the dashboard showing bounce and complaint rates."
  enforce: "Alert configured on bounce and complaint thresholds."

- id: EMAIL-05
  domain: D15
  tier: P1
  weight: 2
  when: [has_email]
  title: "Marketing mail is separated from transactional, carries an honest unsubscribe, and honours it immediately"
  risk: "Mixing the two means an unsubscribe either kills the receipts users need or is ignored — and ignoring it is a violation in most jurisdictions. Requirements vary by market and change; verify what applies to you."
  fix: "Separate sending streams and separate consent records. One-click unsubscribe in marketing mail, honoured within the required window, with an accurate physical address and sender identity. Never require login to unsubscribe."
  evidence: "Unsubscribe from a test address; show suppression applied and transactional mail unaffected."
  enforce: "Suppression checked in the send path; covered by a test."

```
