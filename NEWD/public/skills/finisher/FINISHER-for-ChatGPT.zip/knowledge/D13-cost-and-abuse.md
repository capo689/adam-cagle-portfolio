# Cost Control and Abuse Prevention

> Covers checks COST-01..07. Domain D13, weight 5.

Two problems with one control point. The rate limiter that stops a scraper is the same rate limiter that stops a runaway inference bill, and the gateway that enforces per-tenant quotas is the same place you meter cost.

---

## 1. The P0: no unmetered paid endpoint

An unauthenticated, unlimited endpoint that costs money per call is a credit card someone else is holding. This applies to inference, but also to SMS, email, geocoding, enrichment, image processing, and any third-party API billed per request.

Every one of those endpoints needs, in this order:

1. **Authentication** — no anonymous access to paid operations
2. **Per-user and per-IP rate limits**
3. **Per-account quotas** with a hard ceiling
4. **A global circuit breaker** that disables the feature above a spend threshold

The circuit breaker is the one people skip and the one that saves you. Rate limits bound one user; a breaker bounds the incident.

## 2. Layered rate limiting

| Layer | Purpose | Where |
|---|---|---|
| Per IP | Blunt anti-bot | Edge or WAF |
| Per authenticated user | Fair use | Application or gateway |
| Per account/tenant | Contractual limits, protects other tenants | Application |
| Per endpoint | Protects expensive operations specifically | Application |
| Global | Protects the whole system | Edge |

Enforce at the edge where you can, so an abusive request never reaches your compute — otherwise you are paying to reject traffic.

Return `429` with a `Retry-After` header, and make the client handle it with backoff. A client that retries a 429 immediately turns rate limiting into a tighter loop.

Different limits for different endpoints. Login gets a tight per-identity limit. A search endpoint gets a moderate one. An export or an inference call gets a very tight one. A single global limit is either too loose for the expensive endpoints or too tight for the cheap ones.

## 3. Spend caps and alerts

Set them at every provider, not just the obvious one:

- Model providers (hard limits where offered, budget alerts always)
- Hosting — function invocations, bandwidth, build minutes
- Database — compute, storage, and especially egress
- Object storage — storage plus egress
- Log ingestion, which scales with success and surprises people
- Email and SMS
- Any per-request third-party API

Alert at 50%, 80%, and 100% of expected monthly spend, routed to a human. Then add a daily anomaly alert: today's spend more than some multiple of the trailing average. Monthly caps are too coarse to catch a runaway loop, which can do a month's budget in an afternoon.

## 4. Attribute cost to a user and a feature

You cannot control what you cannot attribute. Log, for every paid call: provider, operation or model, feature, user, account, units consumed, and estimated cost.

That gives you three numbers worth watching:

- **Cost per active user** — the unit economics
- **Cost per feature** — what to optimize, and occasionally what to remove
- **Top spenders** — abuse detection and enterprise-pricing signal

A single user consuming 40% of your inference budget is either your best customer or your worst problem, and you should know which.

## 5. Abuse paths, tested

Free tiers, signup flows, and anything that processes a file get abused within days of a public launch. Test each:

| Path | Attack | Control |
|---|---|---|
| Signup | Automated account creation for free-tier resources | Bot protection, email verification before resource-consuming actions |
| Email verification | Using your service as a mail relay or spam amplifier | Rate limit sends per IP and per address |
| Public search or list | Full-database scraping via pagination | Rate limits, page-size caps, anomaly detection on volume |
| File processing | Zip bombs, decompression bombs, malformed media | Size caps before processing, timeouts, out-of-process handling |
| Inference | Prompt-based resource exhaustion, very long inputs | Token caps on input and output, per-user budgets |
| Password reset | Mail bombing a third party | Per-address and per-IP limits |
| Referral or credit systems | Self-referral loops | Verification, caps, manual review over a threshold |

Attempt each yourself. What stopped you is the evidence.

## 6. Billing correctness

Revenue leaks silently. Cancelled subscriptions that keep serving, failed renewals that keep granting access, usage that never gets billed — none of these produce an error.

Handle the full webhook lifecycle: created, updated, cancelled, payment succeeded, payment failed, refunded, disputed. Test every one in the provider's test mode. Verify signatures and deduplicate by event ID.

Treat the provider as the source of truth for entitlements and reconcile on a schedule. A nightly job comparing local entitlement state against the provider's subscription state finds the drift before your accountant does.

## 7. Forecasting

Model cost per active user and project it at expected growth. The output that matters is not the total — it is **which line item grows fastest**, because that is the one that will eventually force an architecture change.

Watch for pricing cliffs specifically: egress charges, function invocation tiers, log ingestion volume, vector storage, and per-seat third-party tools that scale with your team rather than your revenue.
