# 01 — MANIFEST: every check, its domain, and the knowledge file that explains it

> Retrieval index. Given a check ID, this tells you which knowledge file to open before scoring it.
> Catalog 1.1.0 · 173 checks · 19 domains

## Knowledge files

| File | Contains |
|---|---|
| `00-METHOD-AND-RUN-LOOP.md` | Method, operating principles, run loop, triage list |
| `01-MANIFEST-check-index.md` | This file |
| `02-SCORING-SYSTEM.md` | Scale, ceilings, coverage, anti-gaming rules |
| `03-INTAKE-AND-RISK-TIERING.md` | Intake, applicability conditions, risk levels, run scoping |
| `D01-auth-and-authorization.md` | D01 Identity, Auth & Authorization (weight 12) |
| `D02-secrets-and-keys.md` | D02 Secrets & Key Management (weight 8) |
| `D03-data-migrations-backups.md` | D03 Data Layer, Migrations & Backups (weight 9) |
| `D04-api-and-backend.md` | D04 API & Backend Correctness (weight 7) |
| `D05-frontend-ux-accessibility.md` | D05 Frontend, UX & Accessibility (weight 6) |
| `D06-application-security.md` | D06 Application Security (weight 9) |
| `D07-supply-chain.md` | D07 Supply Chain & Dependency Integrity (weight 6) |
| `D08-cicd-and-release.md` | D08 CI/CD & Release Engineering (weight 6) |
| `D09-environments-and-infra.md` | D09 Environments, Config & Infrastructure (weight 5) |
| `D10-observability.md` | D10 Observability & Error Tracking (weight 7) |
| `D11-reliability-and-incidents.md` | D11 Reliability, Backup & Incident Response (weight 7) |
| `D12-performance-and-scale.md` | D12 Performance, Caching & Scale (weight 5) |
| `D13-cost-and-abuse.md` | D13 Cost Control & Abuse Prevention (weight 5) |
| `D14-ai-and-agents.md` | D14 AI & Agent Safety and Economics (weight 6) |
| `D15-privacy-legal-compliance.md` | D15 Privacy, Legal & Compliance (weight 6) |
| `D16-testing-and-verification.md` | D16 Testing & Verification (weight 6) |
| `D17-mobile-and-app-store.md` | D17 Mobile & App Store (weight 6) |
| `D18-D19-handoff-docs-product.md` | D18 Documentation & Handoff (weight 4) |
| `D18-D19-handoff-docs-product.md` | D19 Product Truth & Outcome Measurement (weight 3) |
| `X1-manual-test-scripts.md` | The scripts scanners cannot replace |
| `X2-ai-code-failure-modes.md` | Code-review checklist for AI-generated code |
| `X3-command-appendix.md` | Copy-paste commands |
| `X4-evidence-and-sources.md` | Citations + volatile-facts list |
| `X5-operational-templates.md` | Runbook, architecture, ADR, threat model, postmortem, README, scorecard, run report, state/context/actions templates |
| `X6-checks-catalog.md` | The catalog |

## Domain → weight → file

| Domain | Weight | Applies when | Knowledge file |
|---|---:|---|---|
| D01 Identity, Auth & Authorization | 12 | has_users | `D01-auth-and-authorization.md` |
| D02 Secrets & Key Management | 8 | always | `D02-secrets-and-keys.md` |
| D03 Data Layer, Migrations & Backups | 9 | always | `D03-data-migrations-backups.md` |
| D04 API & Backend Correctness | 7 | always | `D04-api-and-backend.md` |
| D05 Frontend, UX & Accessibility | 6 | always | `D05-frontend-ux-accessibility.md` |
| D06 Application Security | 9 | always | `D06-application-security.md` |
| D07 Supply Chain & Dependency Integrity | 6 | always | `D07-supply-chain.md` |
| D08 CI/CD & Release Engineering | 6 | always | `D08-cicd-and-release.md` |
| D09 Environments, Config & Infrastructure | 5 | always | `D09-environments-and-infra.md` |
| D10 Observability & Error Tracking | 7 | always | `D10-observability.md` |
| D11 Reliability, Backup & Incident Response | 7 | always | `D11-reliability-and-incidents.md` |
| D12 Performance, Caching & Scale | 5 | always | `D12-performance-and-scale.md` |
| D13 Cost Control & Abuse Prevention | 5 | always | `D13-cost-and-abuse.md` |
| D14 AI & Agent Safety and Economics | 6 | has_ai | `D14-ai-and-agents.md` |
| D15 Privacy, Legal & Compliance | 6 | has_pii | `D15-privacy-legal-compliance.md` |
| D16 Testing & Verification | 6 | always | `D16-testing-and-verification.md` |
| D17 Mobile & App Store | 6 | has_mobile | `D17-mobile-and-app-store.md` |
| D18 Documentation & Handoff | 4 | always | `D18-D19-handoff-docs-product.md` |
| D19 Product Truth & Outcome Measurement | 3 | always | `D18-D19-handoff-docs-product.md` |

## Check index

| Check | Tier | Wt | Applies when | Read before scoring |
|---|---|---:|---|---|
| **AUTH-01** Authentication uses a battle-tested provider or framework, not hand-rolled cod | P0 | 5 | has_users | `D01-auth-and-authorization.md` |
| **AUTH-02** Every non-public route and API endpoint enforces authentication server-side | P0 | 5 | has_users | `D01-auth-and-authorization.md` |
| **AUTHZ-01** Every resource access checks ownership, not just authentication | P0 | 5 | has_users | `D01-auth-and-authorization.md` |
| **AUTHZ-02** Tenant isolation is enforced at the database layer, not only in application co | P0 | 4 | is_multi_tenant | `D01-auth-and-authorization.md` |
| **AUTHZ-03** Admin capability is server-verified and cannot be obtained by client-side mani | P0 | 4 | has_admin | `D01-auth-and-authorization.md` |
| **AUTHZ-04** Authorization model is written down and matches the code | P1 | 3 | has_users | `D01-auth-and-authorization.md` |
| **AUTH-03** Sessions expire, logout truly invalidates, and session IDs rotate on privilege | P0 | 4 | has_users | `D01-auth-and-authorization.md` |
| **AUTH-04** Session cookies use Secure, HttpOnly, SameSite, and the __Host- prefix where p | P1 | 3 | has_users | `D01-auth-and-authorization.md` |
| **AUTH-05** Password reset and email verification tokens are single-use, short-lived, and  | P0 | 4 | has_users | `D01-auth-and-authorization.md` |
| **AUTH-06** Login, reset, signup, and OTP endpoints are rate limited per account and per I | P1 | 3 | has_users | `D01-auth-and-authorization.md` |
| **AUTH-07** Password policy follows current guidance: length over composition, breach-list | P1 | 2 | has_users | `D01-auth-and-authorization.md` |
| **AUTH-08** MFA or passkeys available for users, mandatory for admins | P1 | 2 | has_users, has_admin | `D01-auth-and-authorization.md` |
| **AUTH-09** OAuth/OIDC integrations use PKCE, exact redirect URI matching, and state/nonce | P2 | 2 | has_users | `D01-auth-and-authorization.md` |
| **AUTH-10** Tokens are validated with a pinned algorithm and are revocable | P1 | 3 | has_users | `D01-auth-and-authorization.md` |
| **AUTH-11** Account deletion and data export exist and actually work end to end | P1 | 2 | has_users | `D01-auth-and-authorization.md` |
| **AUTH-12** Privileged actions are recorded in an append-only audit log | P2 | 2 | has_admin | `D01-auth-and-authorization.md` |
| **SEC-01** No secret is reachable from browser or mobile client code | P0 | 5 | always | `D02-secrets-and-keys.md` |
| **SEC-02** Secret scan of the full git history passes, and anything ever exposed has been | P0 | 5 | always | `D02-secrets-and-keys.md` |
| **SEC-03** Secrets live in a secret manager or platform env store, scoped per environment | P1 | 4 | always | `D02-secrets-and-keys.md` |
| **SEC-04** CI/CD uses short-lived federated credentials (OIDC), not long-lived cloud keys | P1 | 3 | always | `D02-secrets-and-keys.md` |
| **SEC-05** Service accounts and database credentials follow least privilege | P1 | 3 | always | `D02-secrets-and-keys.md` |
| **SEC-06** Secrets never appear in logs, error messages, traces, screenshots, or AI promp | P1 | 3 | always | `D02-secrets-and-keys.md` |
| **SEC-07** Key rotation is documented, rehearsed, and possible without downtime | P2 | 2 | always | `D02-secrets-and-keys.md` |
| **SEC-08** Webhook endpoints verify provider signatures and reject replays | P1 | 3 | has_payments | `D02-secrets-and-keys.md` |
| **DATA-01** Automated backups exist for every production datastore | P0 | 5 | always | `D03-data-migrations-backups.md` |
| **DATA-02** A restore has actually been performed and the result verified | P0 | 5 | always | `D03-data-migrations-backups.md` |
| **DATA-03** Production, staging, and development use separate datastores | P0 | 4 | always | `D03-data-migrations-backups.md` |
| **DATA-04** No human or agent has standing write access to the production database | P0 | 4 | always | `D03-data-migrations-backups.md` |
| **DATA-05** Every schema change is a versioned migration file in the repo | P1 | 4 | always | `D03-data-migrations-backups.md` |
| **DATA-06** Migrations are linted for locking and destructive operations | P1 | 4 | always | `D03-data-migrations-backups.md` |
| **DATA-07** Rollback strategy for schema changes is defined and it is roll-forward-safe | P1 | 3 | always | `D03-data-migrations-backups.md` |
| **DATA-08** Constraints and indexes reflect real access patterns | P1 | 3 | always | `D03-data-migrations-backups.md` |
| **DATA-09** File uploads enforce size, type, and content validation, and are stored outsid | P1 | 3 | has_uploads | `D03-data-migrations-backups.md` |
| **DATA-10** Data retention and deletion rules are defined per data class | P1 | 3 | has_pii | `D03-data-migrations-backups.md` |
| **DATA-11** Sensitive fields are encrypted at rest beyond disk-level encryption where warr | P2 | 2 | has_pii | `D03-data-migrations-backups.md` |
| **DATA-12** Idempotency keys prevent duplicate side effects from retries and double-clicks | P1 | 3 | always | `D03-data-migrations-backups.md` |
| **API-01** All privileged operations execute server-side; the client is never trusted | P0 | 5 | always | `D04-api-and-backend.md` |
| **API-02** Every input is validated against a schema at the trust boundary, at runtime | P1 | 4 | always | `D04-api-and-backend.md` |
| **API-03** Errors return safe messages; stack traces and internals never reach clients | P1 | 3 | always | `D04-api-and-backend.md` |
| **API-04** Every external call has a timeout, bounded retries with backoff and jitter, an | P1 | 3 | has_third_party | `D04-api-and-backend.md` |
| **API-05** Each external provider is wrapped in a single service module | P1 | 3 | has_third_party | `D04-api-and-backend.md` |
| **API-06** Work that can exceed the request timeout runs in a background job, not in the  | P1 | 3 | has_jobs | `D04-api-and-backend.md` |
| **API-07** Background jobs, crons, and webhooks are observable and alert on failure | P1 | 3 | has_jobs | `D04-api-and-backend.md` |
| **API-08** An API contract exists (OpenAPI or typed RPC) and responses conform to it | P2 | 2 | is_public | `D04-api-and-backend.md` |
| **API-09** Pagination, sorting, and filtering are bounded | P2 | 2 | is_public | `D04-api-and-backend.md` |
| **FE-01** Every async surface has loading, error, empty, and success states | P1 | 4 | always | `D05-frontend-ux-accessibility.md` |
| **FE-02** Error boundaries prevent one component failure from blanking the app | P1 | 3 | always | `D05-frontend-ux-accessibility.md` |
| **FE-03** Core flows verified on real mobile devices, Safari, and a throttled network | P1 | 3 | always | `D05-frontend-ux-accessibility.md` |
| **FE-04** Forms survive hostile and messy input | P1 | 3 | always | `D05-frontend-ux-accessibility.md` |
| **FE-05** Automated accessibility scan passes on core pages | P1 | 3 | is_public | `D05-frontend-ux-accessibility.md` |
| **FE-06** Keyboard-only and screen-reader passes completed on critical journeys | P1 | 3 | is_public | `D05-frontend-ux-accessibility.md` |
| **FE-07** Core Web Vitals measured on real users and within thresholds | P2 | 2 | is_public | `D05-frontend-ux-accessibility.md` |
| **FE-08** Five target users complete the core flow unaided | P2 | 2 | always | `D05-frontend-ux-accessibility.md` |
| **APPSEC-01** Injection is prevented structurally, not by escaping strings | P0 | 4 | always | `D06-application-security.md` |
| **APPSEC-02** Output encoding prevents XSS in every rendering context | P0 | 4 | has_ugc | `D06-application-security.md` |
| **APPSEC-03** Security headers are set, including a strict Content-Security-Policy | P1 | 4 | is_public | `D06-application-security.md` |
| **APPSEC-04** CORS is restricted to known origins and credentials are not exposed to wildcar | P1 | 3 | is_public | `D06-application-security.md` |
| **APPSEC-05** CSRF protection is present on state-changing requests | P1 | 3 | has_users | `D06-application-security.md` |
| **APPSEC-06** SAST runs on pull requests and blocks new high/critical findings | P1 | 3 | always | `D06-application-security.md` |
| **APPSEC-07** SSRF is prevented anywhere the server fetches a user-supplied URL | P1 | 3 | is_public | `D06-application-security.md` |
| **APPSEC-08** A DAST baseline scan has been run against staging and findings triaged | P1 | 3 | is_public | `D06-application-security.md` |
| **APPSEC-09** Manual authorization tampering has been attempted and failed | P1 | 3 | always | `D06-application-security.md` |
| **APPSEC-10** A written threat model exists for the highest-value assets | P2 | 2 | always | `D06-application-security.md` |
| **APPSEC-11** A vulnerability disclosure path exists | P2 | 2 | is_public | `D06-application-security.md` |
| **SUP-01** Install scripts do not run for arbitrary transitive dependencies | P0 | 4 | always | `D07-supply-chain.md` |
| **SUP-02** Lockfile is committed and CI installs are frozen and reproducible | P1 | 4 | always | `D07-supply-chain.md` |
| **SUP-03** A dependency cooldown / minimum release age is configured | P1 | 3 | always | `D07-supply-chain.md` |
| **SUP-04** Dependency vulnerability scanning runs in CI and on a schedule | P1 | 3 | always | `D07-supply-chain.md` |
| **SUP-05** Every dependency actually exists and was not hallucinated | P1 | 3 | always | `D07-supply-chain.md` |
| **SUP-06** GitHub Actions are pinned to full commit SHAs | P2 | 2 | always | `D07-supply-chain.md` |
| **SUP-07** CI workflow token permissions are least-privilege and untrusted input is never | P2 | 2 | always | `D07-supply-chain.md` |
| **SUP-08** An SBOM is generated per release and retained | P2 | 2 | always | `D07-supply-chain.md` |
| **SUP-09** Published artifacts carry build provenance | P2 | 2 | always | `D07-supply-chain.md` |
| **CI-01** Code is in version control with a clean, complete history | P0 | 4 | always | `D08-cicd-and-release.md` |
| **CI-02** CI runs lint, typecheck, tests, and build on every pull request | P1 | 4 | always | `D08-cicd-and-release.md` |
| **CI-03** The main branch is protected: no direct pushes, no force pushes, review requir | P1 | 3 | has_team | `D08-cicd-and-release.md` |
| **CI-04** CODEOWNERS protects auth, payments, migrations, and CI workflow paths | P1 | 3 | always | `D08-cicd-and-release.md` |
| **CI-05** Deployments can be rolled back quickly, and rollback has been tested | P0 | 4 | is_public | `D08-cicd-and-release.md` |
| **CI-06** Changes are previewable before production | P1 | 3 | always | `D08-cicd-and-release.md` |
| **CI-07** Deploys are small, frequent, and attributable to a commit | P1 | 3 | is_public | `D08-cicd-and-release.md` |
| **CI-08** Risky changes ship behind feature flags with a kill switch | P2 | 2 | is_public | `D08-cicd-and-release.md` |
| **CI-09** Post-deploy verification watches error rate, latency, and key funnels | P2 | 2 | is_public | `D08-cicd-and-release.md` |
| **ENV-01** Development, staging, and production are genuinely separate | P0 | 4 | always | `D09-environments-and-infra.md` |
| **ENV-02** Required configuration is validated at startup and the app refuses to boot if  | P1 | 3 | always | `D09-environments-and-infra.md` |
| **ENV-03** Infrastructure changes are reproducible, not clicked | P1 | 3 | always | `D09-environments-and-infra.md` |
| **ENV-04** TLS everywhere, HTTP redirects to HTTPS, and certificate renewal is automated | P1 | 3 | is_public | `D09-environments-and-infra.md` |
| **ENV-05** Serverless and platform timeouts are known and no core action exceeds them | P1 | 3 | always | `D09-environments-and-infra.md` |
| **ENV-06** DNS, domains, and registrar access are documented and secured | P2 | 2 | always | `D09-environments-and-infra.md` |
| **OBS-01** Error tracking is installed on both frontend and backend and receives producti | P0 | 5 | is_public | `D10-observability.md` |
| **OBS-02** Logs are structured and carry a correlation ID across the request path | P1 | 4 | always | `D10-observability.md` |
| **OBS-03** Logs redact secrets and personal data and have a defined retention period | P1 | 3 | always | `D10-observability.md` |
| **OBS-04** Alerts exist for the failures that matter, and they reach a human | P1 | 4 | is_public | `D10-observability.md` |
| **OBS-05** Uptime and synthetic monitoring check the real user journey, not just a 200 | P1 | 3 | is_public | `D10-observability.md` |
| **OBS-06** Distributed tracing covers the slow and complex paths | P2 | 3 | always | `D10-observability.md` |
| **OBS-07** Product analytics track the core funnel | P2 | 2 | is_public | `D10-observability.md` |
| **REL-01** RTO and RPO are defined, written down, and consistent with the backup configur | P1 | 4 | is_public | `D11-reliability-and-incidents.md` |
| **REL-02** An incident runbook exists covering the realistic failure set | P1 | 4 | is_public | `D11-reliability-and-incidents.md` |
| **REL-03** Someone is on call, or there is an explicit documented decision that nobody is | P1 | 3 | is_public | `D11-reliability-and-incidents.md` |
| **REL-04** A breach and data-exposure response plan exists with notification timelines | P1 | 3 | has_pii | `D11-reliability-and-incidents.md` |
| **REL-05** Incidents get blameless post-mortems and produce concrete follow-up actions | P2 | 2 | is_public | `D11-reliability-and-incidents.md` |
| **REL-06** There is a way to tell customers what is happening | P2 | 2 | is_public | `D11-reliability-and-incidents.md` |
| **REL-07** Third-party outage behavior is defined and degraded mode is tested | P2 | 2 | has_third_party | `D11-reliability-and-incidents.md` |
| **PERF-01** Database connection pooling is configured and the connection math works | P1 | 4 | always | `D12-performance-and-scale.md` |
| **PERF-02** N+1 queries and unindexed slow queries have been found and fixed | P1 | 3 | always | `D12-performance-and-scale.md` |
| **PERF-03** Static assets are served from a CDN with correct cache headers | P1 | 3 | is_public | `D12-performance-and-scale.md` |
| **PERF-04** Private data is never cached where another user can receive it | P1 | 4 | is_public | `D12-performance-and-scale.md` |
| **PERF-05** A load test has been run at a realistic launch multiple and the breaking point | P2 | 3 | is_public | `D12-performance-and-scale.md` |
| **PERF-06** Expensive repeated work is cached with a defined invalidation strategy | P2 | 2 | always | `D12-performance-and-scale.md` |
| **PERF-07** A scaling plan exists for the next order of magnitude | P2 | 2 | is_public | `D12-performance-and-scale.md` |
| **COST-01** No paid inference endpoint is publicly reachable without authentication and a  | P0 | 5 | has_ai | `D13-cost-and-abuse.md` |
| **COST-02** Hard spend caps and billing alerts exist at every paid provider | P0 | 4 | has_ai, has_third_party | `D13-cost-and-abuse.md` |
| **COST-03** Rate limiting exists on all public and expensive endpoints | P1 | 4 | is_public | `D13-cost-and-abuse.md` |
| **COST-04** Cost per user and per action is measured, not estimated | P1 | 3 | has_ai, has_third_party | `D13-cost-and-abuse.md` |
| **COST-05** Abuse paths have been tested: signup spam, scraping, resource exhaustion | P1 | 3 | is_public | `D13-cost-and-abuse.md` |
| **COST-06** Billing events reconcile with usage and entitlements | P2 | 2 | has_payments | `D13-cost-and-abuse.md` |
| **COST-07** Infrastructure spend is forecast for the next 90 days at expected growth | P2 | 2 | always | `D13-cost-and-abuse.md` |
| **AI-01** Model provider calls happen server-side only, through a single gateway module | P0 | 5 | has_ai | `D14-ai-and-agents.md` |
| **AI-02** The lethal trifecta is broken: no single agent context combines private data,  | P0 | 5 | has_agents | `D14-ai-and-agents.md` |
| **AI-03** Agent tools are individually scoped and no agent holds production credentials | P0 | 4 | has_agents | `D14-ai-and-agents.md` |
| **AI-04** Irreversible and externally visible actions require human approval with full p | P1 | 4 | has_agents | `D14-ai-and-agents.md` |
| **AI-05** Model output is treated as untrusted input everywhere it is used | P1 | 3 | has_ai | `D14-ai-and-agents.md` |
| **AI-06** Token usage and cost are logged per request with full attribution | P1 | 3 | has_ai | `D14-ai-and-agents.md` |
| **AI-07** Per-user and per-tier quotas are token-budgeted, not request-counted | P1 | 3 | has_ai | `D14-ai-and-agents.md` |
| **AI-08** Provider failure degrades gracefully | P1 | 3 | has_ai | `D14-ai-and-agents.md` |
| **AI-09** An eval set exists for the AI feature and runs before releases | P1 | 3 | has_ai | `D14-ai-and-agents.md` |
| **AI-10** Prompt injection has been tested against your actual attack surface | P1 | 3 | has_ai | `D14-ai-and-agents.md` |
| **AI-11** Cost is engineered: caching, routing, and batching where they apply | P2 | 3 | has_ai | `D14-ai-and-agents.md` |
| **AI-12** AI behavior is traced and reviewed against real production traffic | P2 | 2 | has_ai | `D14-ai-and-agents.md` |
| **AI-13** AI features are disclosed to users where required and outputs are labelled | P2 | 2 | has_ai | `D14-ai-and-agents.md` |
| **AI-14** Third-party tool and MCP server integrations are vetted and pinned | P2 | 2 | has_agents | `D14-ai-and-agents.md` |
| **AI-15** Agent memory and retrieved context cannot be poisoned across users or sessions | P2 | 2 | has_agents | `D14-ai-and-agents.md` |
| **LEG-01** A privacy policy and terms of service are published and accurate | P0 | 4 | has_pii | `D15-privacy-legal-compliance.md` |
| **LEG-02** A data inventory exists: what you collect, where it lives, who it goes to | P0 | 4 | has_pii | `D15-privacy-legal-compliance.md` |
| **LEG-03** Data subject rights are actually operable: access, deletion, correction, expor | P1 | 3 | has_pii | `D15-privacy-legal-compliance.md` |
| **LEG-04** GDPR basics are in place: lawful basis, processor agreements, transfer mechani | P1 | 3 | eu_users | `D15-privacy-legal-compliance.md` |
| **LEG-05** US state privacy obligations are handled, including universal opt-out signals | P1 | 3 | us_state_privacy | `D15-privacy-legal-compliance.md` |
| **LEG-06** Payment card scope is minimized and the applicable PCI obligations are known | P1 | 3 | has_payments | `D15-privacy-legal-compliance.md` |
| **LEG-07** Subscription, refund, and cancellation terms are clear and cancellation is eas | P1 | 3 | has_payments | `D15-privacy-legal-compliance.md` |
| **LEG-08** Sector-specific obligations are identified and the controls mapped | P2 | 2 | is_regulated | `D15-privacy-legal-compliance.md` |
| **LEG-09** Accessibility obligations have been assessed for your markets | P2 | 2 | is_public | `D15-privacy-legal-compliance.md` |
| **LEG-10** Content moderation, reporting, and takedown paths exist | P2 | 2 | has_ugc | `D15-privacy-legal-compliance.md` |
| **TEST-01** Automated tests cover authorization on every endpoint | P0 | 5 | always | `D16-testing-and-verification.md` |
| **TEST-02** The critical user journeys have end-to-end tests | P1 | 4 | always | `D16-testing-and-verification.md` |
| **TEST-03** The full payment lifecycle is tested in the provider's test mode | P1 | 4 | has_payments | `D16-testing-and-verification.md` |
| **TEST-04** Tests actually assert; coverage is measured on the diff, not chased globally | P1 | 3 | always | `D16-testing-and-verification.md` |
| **TEST-05** The API has been fuzzed against its schema | P1 | 3 | is_public | `D16-testing-and-verification.md` |
| **TEST-06** Tests run against a real database, not mocks, for data-layer behavior | P1 | 3 | always | `D16-testing-and-verification.md` |
| **TEST-07** Flaky tests are quarantined and fixed, not retried into silence | P2 | 2 | always | `D16-testing-and-verification.md` |
| **TEST-08** A human has read the security-critical code, not just the tests | P2 | 2 | always | `D16-testing-and-verification.md` |
| **MOB-01** Account deletion is available in-app for any app that supports account creatio | P0 | 4 | has_mobile | `D17-mobile-and-app-store.md` |
| **MOB-02** Privacy declarations match actual data collection, including every SDK | P0 | 4 | has_mobile | `D17-mobile-and-app-store.md` |
| **MOB-03** Monetization complies with current store rules | P0 | 3 | has_mobile | `D17-mobile-and-app-store.md` |
| **MOB-04** Target SDK/API level and platform technical requirements meet current store mi | P1 | 3 | has_mobile | `D17-mobile-and-app-store.md` |
| **MOB-05** A forced-update mechanism exists | P1 | 3 | has_mobile | `D17-mobile-and-app-store.md` |
| **MOB-06** Crash reporting and release-tagged error tracking are live on mobile | P1 | 3 | has_mobile | `D17-mobile-and-app-store.md` |
| **MOB-07** Secrets are not embedded in the app binary and the API does not trust the clie | P1 | 3 | has_mobile | `D17-mobile-and-app-store.md` |
| **MOB-08** Sensitive data uses platform secure storage, and offline behavior is defined | P1 | 2 | has_mobile | `D17-mobile-and-app-store.md` |
| **MOB-09** Deep links and universal links are verified and handle unauthenticated and col | P2 | 2 | has_mobile | `D17-mobile-and-app-store.md` |
| **MOB-10** Push notification credentials and their expiry are tracked, and rollout is sta | P2 | 2 | has_mobile | `D17-mobile-and-app-store.md` |
| **DOC-01** README lets a new developer run the project locally from zero | P1 | 4 | always | `D18-D19-handoff-docs-product.md` |
| **DOC-02** Architecture notes exist: system diagram, data model, vendor map, auth model | P1 | 3 | always | `D18-D19-handoff-docs-product.md` |
| **DOC-03** Deploy and rollback procedures are written down and executable by someone else | P1 | 3 | is_public | `D18-D19-handoff-docs-product.md` |
| **DOC-04** Significant decisions are recorded with their reversal path | P2 | 2 | has_team | `D18-D19-handoff-docs-product.md` |
| **DOC-05** Known limitations, deliberate shortcuts, and technical debt are listed honestl | P2 | 2 | always | `D18-D19-handoff-docs-product.md` |
| **PROD-01** The problem, the user, and the success metric are written down in one paragrap | P1 | 4 | always | `D18-D19-handoff-docs-product.md` |
| **PROD-02** A baseline was captured before changes so improvement is provable | P1 | 3 | always | `D18-D19-handoff-docs-product.md` |
| **PROD-03** Real user outcomes are measured after launch, not just system health | P2 | 3 | is_public | `D18-D19-handoff-docs-product.md` |
| **PROD-04** There is a way for users to report problems and it is monitored | P2 | 2 | is_public | `D18-D19-handoff-docs-product.md` |
| **EMAIL-01** Sending domain is authenticated with SPF, DKIM, and an enforcing DMARC policy | P1 | 3 | has_email | `D06-application-security.md` |
| **EMAIL-02** User input never reaches mail headers, and links in mail are not open redirect | P1 | 3 | has_email | `D06-application-security.md` |
| **EMAIL-03** Any user-triggerable send is rate limited per recipient and per actor | P1 | 3 | has_email | `D13-cost-and-abuse.md` |
| **EMAIL-04** Bounces, complaints, and suppressions are processed and monitored | P1 | 3 | has_email | `D10-observability.md` |
| **EMAIL-05** Marketing mail is separated from transactional, carries an honest unsubscribe, | P1 | 2 | has_email | `D15-privacy-legal-compliance.md` |
