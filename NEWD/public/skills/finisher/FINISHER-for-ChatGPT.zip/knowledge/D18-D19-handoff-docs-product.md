# Documentation, Handoff and Product Truth

> Covers checks DOC-01..05 (D18, weight 4) and PROD-01..04 (D19, weight 3).

The test for this domain is concrete: **could someone who has never seen this project run it, deploy it, debug it, and extend it using only the documentation?** For an AI-built project the question is sharper than usual, because there may be no institutional memory at all — the "author" was a conversation that has scrolled away.

---

## 1. README

Not a feature list. An operating manual. It must contain, at minimum:

- What the application does, in two sentences, and who uses it
- The stack, with versions
- Prerequisites — runtime versions, database, any required services
- Local setup, step by step, from a clean machine
- **Environment variables by name with a description of each — never values**
- Database setup, migration, and seed commands
- How to run, test, lint, and build
- How to deploy and how to roll back
- Known limitations
- Where to find the runbook, the architecture notes, and the scorecard

Verify it by following it on a clean container. The CI workflow is a good forcing function here: if CI can build and test the project from scratch, the setup steps are correct by construction, and that is what moves DOC-01 from 3 to 4.

## 2. Architecture notes

Use `knowledge file X5-operational-templates.md section `ARCHITECTURE.md``. The sections that get used most in practice:

- **Request path** — a diagram or numbered list from browser to database and back, including edge, auth, and any queue
- **Data model** — entities, relationships, and which tables carry ownership columns
- **Auth and permission model** — the roles × resources × actions matrix
- **Vendor map** — every third party, what it does, what data it receives, who owns the account, what happens if it is down
- **Background jobs** — what runs, when, what it touches, what happens if it fails
- **AI calls** — where, which model, what context, what it costs, what the fallback is
- **Where money flows** and **where personal data flows** — two separate diagrams, both worth having

The vendor map is the one that saves the most time later. It is also most of a security questionnaire and most of a data inventory.

## 3. Runbook

Covered in knowledge file `D11-reliability-and-incidents.md` §2. The only thing to add here: the runbook lives with the code, not in someone's notes app, and it contains actual commands rather than descriptions of commands.

## 4. Decision records

A short record per significant decision — context, decision, alternatives considered, consequences, and how to reverse it. Use `knowledge file X5-operational-templates.md section `ADR.md``.

The reversal plan is the field people skip and the one that matters. Six months later, nobody remembers why the odd choice was made, so it gets undone, and the original problem comes back.

For AI-built projects, ADRs are unusually valuable because many decisions were made implicitly by a model rather than deliberately by a person. Writing them down converts an accident into a choice, and sometimes reveals that the choice was wrong.

## 5. Known limitations, honestly

A section listing what is not handled, what will break at scale, and what was deliberately deferred with the trigger for revisiting it.

This is not an admission of failure. It is the difference between a shortcut and a landmine. "We do not handle concurrent edits; last write wins; revisit if we get multi-user teams" is a documented design decision. The same code without that sentence is a bug waiting to surprise someone.

Review it every FINISHER run. Items that graduate into real problems should become checks.

---

## 6. Product truth

The checks in D19 exist because a technically perfect product solving a problem nobody has is still a failure, and most engineering checklists omit this entirely.

### One paragraph

Who is this for, what problem does it solve, what do they do today instead, and what single number proves it worked?

If that paragraph is hard to write, that is the finding. It is much cheaper to discover an unclear value proposition now than after three months of hardening.

### Baseline before you change things

Capture, before optimizing:

- Time on task
- Error rate
- Volume handled
- Cost per task
- Completion or conversion rate
- Support burden

Without a before, every after is an anecdote. This is also the honest way to evaluate whether an AI feature is worth its cost — "users like it" is not a number.

### Measure outcomes after launch

Green dashboards and zero adoption is the most common outcome for a technically sound launch. Track activation, retention, and the core success metric. Set a review date and a decision rule in advance: *if the metric is below X by date Y, we do Z.* Deciding the rule before you see the data is what stops it becoming a rationalization exercise.

### Give users a way to tell you it is broken

A support address, in-app feedback, or a form — routed somewhere a human reads, with a stated response expectation. Users who cannot report a problem do not report it. They leave.
