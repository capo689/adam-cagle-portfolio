# Secrets and Key Management

> Covers checks SEC-01..08. Domain D02, weight 8.

**A secret that has ever been in a repository, a client bundle, a log, a screenshot, or an AI prompt is compromised.** Not "at risk" — compromised. Deleting it does not help. Rotation is the only remediation, and it is cheap. Do it.

---

## 1. The client-side rule

Anything shipped to a browser or a mobile binary is public. Not obscured — public. The framework prefixes exist to make this explicit:

```
NEXT_PUBLIC_*    VITE_*    REACT_APP_*    EXPO_PUBLIC_*    PUBLIC_*
```

Every one of those is compiled into the bundle. If a service key ever ends up behind one of those prefixes, it is on the internet.

The check:

```bash
npm run build
# adjust the output dir to your framework
grep -rohE "(sk_live_|sk_test_|rk_live_|xox[baprs]-|ghp_|github_pat_|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_-]{35}|SG\.[A-Za-z0-9_-]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)" \
  dist/ build/ .next/static/ .output/ 2>/dev/null | sort -u
# expect: nothing

# then the manual pass
grep -riE "(secret|api_?key|password|token|credential)" dist/ .next/static/ 2>/dev/null | head -30
```

Then open DevTools on the running app, look at the Sources tab, and read the Network tab for outbound requests carrying an `Authorization` header your server did not add.

**Publishable keys are fine.** Stripe publishable keys, Supabase anon keys, Firebase web config, PostHog project keys — these are designed for client exposure. What matters is that the *secret* counterpart never appears, and that anon-key access is constrained by policy (RLS, security rules) rather than by nobody noticing.

## 2. Git history

```bash
gitleaks git -v .                             # whole history
gitleaks dir --redact --report-format sarif --report-path gitleaks.sarif .
trufflehog git file://. --results=verified    # verifies live credentials against providers
git log --all --full-history -- .env .env.local .env.production
find . -name "*.env*" -not -path "*/node_modules/*"
```

`trufflehog --results=verified` is worth the extra run: it actually calls the provider to check whether a found credential is still live, which turns a wall of maybes into a short list of emergencies.

**On a hit:** rotate first, then decide about history. Rewriting history with `git filter-repo` or BFG is disruptive and does not help if the repository was ever cloned, forked, or mirrored. Rotation is what actually closes the exposure.

## 3. Where secrets should live

In ascending order of maturity:

1. Platform environment variables, scoped per environment (fine for most projects)
2. A managed secret manager — AWS Secrets Manager, GCP Secret Manager, Azure Key Vault, HashiCorp Vault, Doppler, Infisical
3. **Short-lived credentials generated per session or deployment**, so a stolen credential expires on its own

Level 3 is the direction of travel and the reason OIDC federation matters: the best rotation policy is not needing one.

Non-negotiables at any level:

- `.env` in `.gitignore`; `.env.example` lists **names only**
- Different values per environment — no shared keys between staging and production
- Production secrets not present on any developer machine
- Access to the secret store is itself restricted and logged

## 4. CI/CD: stop using long-lived cloud keys

A static cloud access key in CI is a permanent credential that has been the payload of every major registry worm of the last two years. Replace it with OIDC federation.

```yaml
permissions:
  id-token: write        # without this, no token is minted
  contents: read

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: aws-actions/configure-aws-credentials@<full-commit-sha>  # pin the SHA
        with:
          role-to-assume: arn:aws:iam::<account>:role/deploy
          aws-region: us-east-1
```

The trust policy on the cloud side should be scoped to repository **and** branch or environment, e.g. subject `repo:org/repo:environment:production`. A trust policy scoped only to the repository lets any branch — including one from a fork in some configurations — assume the role.

Grant `id-token: write` only on the jobs that need it. Default the workflow to `contents: read`.

## 5. Keeping secrets out of logs and prompts

Redaction belongs in the logger, not at the call sites:

```ts
const REDACT = /^(authorization|cookie|set-cookie|x-api-key|password|token|secret|.*_key)$/i;
function scrub(o: unknown, depth = 0): unknown {
  if (depth > 6 || o === null || typeof o !== "object") return o;
  return Object.fromEntries(Object.entries(o as Record<string, unknown>)
    .map(([k, v]) => [k, REDACT.test(k) ? "[REDACTED]" : scrub(v, depth + 1)]));
}
```

Also scrub: error-tracking payloads (request bodies and headers are attached by default in most SDKs), analytics events, and anything sent to a model provider. **Pasting a `.env` file into an AI chat is an exposure event** — treat it exactly like a commit.

## 6. Least privilege

- Separate database roles for migrations, application reads, and application writes
- Third-party API keys scoped to the minimum permission set, and IP-restricted where supported
- Distinct keys per environment so a staging leak cannot touch production
- Separate keys per service, so revoking one does not take down everything

The test question: *for each credential, what is the worst thing its holder can do?* If the answer is "anything," it is over-privileged.

## 7. Rotation

Rotation must be possible without downtime, or it will not happen during the incident when it matters. Support two valid credentials during rollover: add the new one, deploy, verify, remove the old one.

Guidance has moved away from calendar-based rotation of user passwords toward rotation on suspected compromise — but **application secrets are different**. API keys and database credentials should rotate on a real cadence, and always immediately on: staff departure, vendor breach disclosure, any exposure, and any suspicion.

Write the runbook, then rehearse it once while nothing is on fire. The rehearsal is what makes SEC-07 a 3.

## 8. Webhook signature verification

Any endpoint a third party calls needs to prove the call came from them:

- Verify the signature using the provider's library, against the **raw request body** — most frameworks parse JSON before you get to it, and re-serializing changes the bytes and breaks verification
- Enforce a timestamp tolerance to reject replays
- Store processed event IDs so a duplicate delivery produces one side effect
- Return 2xx quickly and do the work asynchronously; providers retry on timeout, which is how you get duplicates

An unverified payment webhook means anyone who can guess your URL can mark invoices paid. This is a P0 every time.
