# CI/CD and Release Engineering

> Covers checks CI-01..09. Domain D08, weight 6.

The goal is narrow: **every change is previewable, every deploy is attributable, and every deploy is reversible.** Everything else in this domain serves those three properties.

---

## 1. The gate

One workflow, running on every pull request, fast enough that nobody wants to skip it (under ten minutes is the practical threshold):

```yaml
name: ci
on: [pull_request]
permissions: { contents: read }
jobs:
  gate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@<sha>
      - uses: actions/setup-node@<sha>
        with: { node-version: '22', cache: 'npm' }
      - run: npm ci --ignore-scripts
      - run: npm run lint
      - run: npm run typecheck
      - run: npm test -- --coverage
      - run: npm run build
      - run: npx playwright test --grep @smoke     # 3-8 critical journeys only
      - uses: gitleaks/gitleaks-action@<sha>
      - run: npx semgrep scan --config auto --error
```

Split full E2E, mutation testing, DAST, and load tests into scheduled or merge-triggered workflows. The pull request gate protects speed; the nightly protects depth.

If lint, typecheck, or test scripts do not exist, creating them is the first task. An AI-built codebase without a typecheck step is running without its cheapest available safety net.

## 2. Branch protection

Configure it as a ruleset:

- Require a pull request before merging
- Require status checks to pass, and require branches to be up to date (otherwise a green check on a stale base merges an untested combination)
- Require review from Code Owners on sensitive paths
- Block force pushes and branch deletion
- Audit the bypass list quarterly — bypass actors are where this quietly stops working

CODEOWNERS is the highest-value piece for AI-assisted work:

```
.github/workflows/   @security-owner
/src/auth/           @security-owner
/src/payments/       @security-owner
/migrations/         @db-owner
/infra/              @infra-owner
```

Workflow files first. Most CI compromises in the recent incident record involved modifying them.

## 3. Preview before production

Branch previews or a staging environment that genuinely mirrors production configuration — same runtime version, same feature flags, same edge configuration, seeded with production-shaped (not production) data.

A staging environment that differs from production in configuration will not catch configuration bugs, which are the ones staging exists to catch.

## 4. Rollback

**Know the rollback path before you deploy, and test it while nothing is on fire.** Discovering that rollback does not work during an outage is the single most avoidable form of prolonged downtime.

Write down and rehearse:

- The exact command or console action, per environment
- Elapsed time from decision to restored service
- What rollback does *not* undo — this is the important part

The migration interaction is the trap. If a deploy included a destructive schema change, rolling back the code does not roll back the schema, and the old code may not work against the new schema. This is why expand/contract migrations matter: they preserve the property that version N-1 still runs against version N's schema, which is what makes code rollback a real option.

## 5. Attribution

Every deploy should be traceable to a commit, and every error traceable to a deploy.

- Inject the commit SHA at build time and expose it (a `/version` endpoint, a meta tag, a console line)
- Send release metadata to error tracking so a stack trace maps to a specific deploy
- Tag releases in git
- Small deploys — one meaningful change at a time. Batched deploys make attribution guesswork: something broke, and it was one of forty things.

## 6. Feature flags

For anything risky, ship the code dark and enable it separately. The value is a kill switch that does not require a deploy — when a feature misbehaves at 2am you want a toggle, not a build.

Keep it simple at small scale: a config-backed boolean set is a legitimate implementation. Reach for a flag platform when you need percentage rollouts, per-tenant targeting, or an audit trail.

The discipline that makes flags work is deleting them. A codebase with forty stale flags has forty untested code paths. Set an expiry when you create one.

## 7. After the deploy

Deploying successfully is not the same as working. Define the watch window and what you are watching:

- Error rate versus the pre-deploy baseline
- Latency at p95 and p99
- The core conversion event — a deploy that breaks signup returns 200 for everything
- Third-party and inference spend, which is where a runaway loop shows up first
- Support signals

Automate the rollback trigger where you can. Otherwise a named human watches for a defined period, and the runbook says who.

Staged rollouts — canary, percentage, or blue-green — turn a bad deploy from an outage into an incident affecting 5% of traffic. Worth it once you have enough traffic for a 5% sample to be meaningful.

## 8. Measuring delivery

If you want a delivery-health signal, the durable ones are: how long a change takes from commit to production, how often you deploy, what fraction of deploys require immediate intervention, and how long recovery takes when one does. A fifth — the share of deploys that are unplanned responses to a production incident — is a good early warning that quality is degrading.

Be careful quoting industry benchmark tiers. The research that popularized them has since restructured its model away from a simple performance ladder, so figures like "elite means lead time under an hour" are dated. **Use these metrics to measure your own trend, not to grade yourself against a table.**
