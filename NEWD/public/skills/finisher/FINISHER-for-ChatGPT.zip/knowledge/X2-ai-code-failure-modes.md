# Failure Modes of AI-Generated Code

This is the review checklist. When a human reads AI-written code — which check TEST-08 requires for anything security-critical — these are the things to look for, ordered by how often they appear and how much they cost.

The evidence behind the ordering is worth knowing, because it changes where you point your attention.

---

## What the research actually shows

**Security has not improved with model capability.** A longitudinal study running since 2023 across more than 150 models, using 80 coding tasks in four languages, found the security pass rate flat at around 55% — meaning roughly **45% of generated code contains a vulnerability** — while syntactic correctness rose above 95%. Frontier models cluster at the same security number as their predecessors. Reasoning-focused models reach around 70–72%, better but not production-acceptable.

**The per-vulnerability breakdown is the actionable part.** SQL injection defense passes around 82% of the time and insecure cryptography around 86%. **Cross-site scripting passes around 15%, and log injection around 13%.** Models learned to parameterize queries and never learned to encode output. If you audit one thing, audit output encoding.

**Defects moved up the stack.** A large enterprise study comparing AI-assisted repositories before and after adoption found syntax errors down 76% and logic bugs down 60%, alongside roughly ten times more security findings — **privilege escalation paths up 322%** and **architectural design flaws up 153%**, with exposed credentials roughly twice as common. The summary line is the most useful one-sentence description of the problem: AI is fixing the typos and creating the timebombs.

**Maintainability is degrading measurably.** An analysis of 623 million changed lines from 2023 to 2026 found duplicated code blocks up 81%, copy-paste share rising from 9.4% to 15.7%, and — the striking one — **moved code, the proxy for refactoring, collapsing from 21% to 3.8%**. Cross-file function calls are down 35%, meaning new code increasingly does not call your existing code. It reimplements it. That is how you end up with five slightly different `formatCurrency` functions and a fix that lands in one of them.

**Self-assessment is unreliable.** A randomized trial of experienced developers on their own repositories found them 19% *slower* with AI assistance while predicting a 24% speedup — and still believing afterwards they had been sped up by 20%. A separate controlled study found participants with an AI assistant wrote less secure code and were *more* confident it was secure.

That last finding is the one that justifies this entire skill. **Verification cannot be delegated to the judgement of the person who wrote it with AI**, because that judgement has been measured and it is wrong in a consistent direction.

---

## The review checklist

### Authorization and access — check first, always

- [ ] Handler checks **ownership**, not just authentication
- [ ] Tenant filter present in list **and** detail **and** search **and** export queries
- [ ] Role read from server state, never from a client-supplied claim
- [ ] New endpoint added to the route inventory and to the authorization test matrix
- [ ] Nested/related-record access does not traverse past the ownership boundary
- [ ] Bulk endpoints apply the same scoping as single-record ones

### Output encoding — the statistically weakest area

- [ ] No unsanitized raw-HTML sink (`dangerouslySetInnerHTML`, `v-html`, `innerHTML`)
- [ ] User-supplied URLs validated for scheme before rendering
- [ ] Markdown renderer has raw HTML disabled or output sanitized
- [ ] Values encoded for the context they land in, not just HTML-escaped
- [ ] Log statements do not interpolate unescaped user input

### Input and trust boundaries

- [ ] Runtime schema validation, not just a TypeScript annotation
- [ ] Strict mode — unknown fields rejected, not silently ignored
- [ ] No mass assignment (`Object.assign(model, req.body)`)
- [ ] Price, role, tier, ownership, and status recomputed server-side
- [ ] File uploads validated by content, not extension

### Data integrity

- [ ] Migration is a file, not a console command
- [ ] Migration linted for locks and destructive operations
- [ ] Foreign keys, unique constraints, and `NOT NULL` present where meaningful
- [ ] Ownership columns on any table holding user data
- [ ] Idempotency for anything with an external side effect
- [ ] Transactions wrap multi-step writes; no partial-state windows

### Error handling

- [ ] Every `catch` either handles or rethrows — no silent swallow
- [ ] Authorization code **fails closed** on exception
- [ ] Client responses carry no stack trace, path, or schema detail
- [ ] Empty result distinguished from error result
- [ ] Promise rejections handled; no unhandled rejection warnings

### External calls

- [ ] Explicit timeout
- [ ] Retries bounded, with backoff, and only for idempotent operations
- [ ] Defined behavior when the provider is down
- [ ] Call goes through the provider wrapper, not a direct SDK import

### Dependencies

- [ ] Every newly added package **actually exists** and is the one intended
- [ ] Package predates the pull request; not created last week with a plausible name
- [ ] No unnecessary new dependency for something the standard library does
- [ ] Lockfile updated; install scripts not newly enabled

### Secrets

- [ ] No credential in the diff, in any form
- [ ] No credential behind a client-exposed environment prefix
- [ ] No credential in a log line, error message, or test fixture

### Duplication and integration

- [ ] Does this reimplement something that already exists in the codebase?
- [ ] Does it call existing helpers, or a parallel private copy?
- [ ] Are there now two sources of truth for the same rule?

### Agent-specific

- [ ] No production credential reachable by an agent
- [ ] New tool scoped to its own least-privilege credential
- [ ] Irreversible action gated behind approval showing full parameters
- [ ] Model output validated before reaching any sink

---

## Specific patterns to grep for

```bash
# authorization omissions: findUnique/findById without a scoping clause
grep -rn "find\(Unique\|First\|ById\)\?(" --include="*.ts" src/ | grep -v "userId\|tenantId\|ownerId\|accountId"

# raw HTML sinks
grep -rn "dangerouslySetInnerHTML\|v-html\|innerHTML\s*=\|insertAdjacentHTML\|document.write" src/

# swallowed errors
grep -rn "catch\s*(\s*\(.*\)\?\s*)\s*{\s*}" -A1 src/
grep -rn "except.*:\s*pass" --include="*.py" .

# string-built queries
grep -rn "\(query\|execute\|raw\)(.*\(\`\|+\).*\${\?" src/

# shell execution
grep -rn "exec(\|execSync(\|shell\s*[:=]\s*[Tt]rue\|os.system(" src/

# client-exposed env vars
grep -rn "NEXT_PUBLIC_\|VITE_\|REACT_APP_\|EXPO_PUBLIC_" src/ | grep -iE "secret|key|token|password"

# TODO/FIXME left by the model
grep -rn "TODO\|FIXME\|XXX\|HACK\|for now\|temporary" src/ | head -40
```

That last one is worth running. Models leave honest markers about the shortcuts they took, and nobody reads them.

---

## Process implications

Three changes to how work is reviewed, each following directly from the evidence:

1. **Review the wiring, not the syntax.** The compiler and the linter already cover what AI got better at. Human attention belongs on authorization, transactions, error paths, and integration — where the defects moved.

2. **Keep pull requests small.** AI-assisted changes concentrate in fewer, larger pull requests, and large diffs get rubber-stamped. One documented case had a single AI-driven pull request altering authorization headers across multiple services. A 40-file diff does not get reviewed; it gets approved.

3. **Prefer external verification to judgement.** Tests, CI gates, fuzzers, linters, and scanners do not have the confidence-calibration problem that measurement has repeatedly found in humans working with AI. Build the gate rather than resolving to be careful.
