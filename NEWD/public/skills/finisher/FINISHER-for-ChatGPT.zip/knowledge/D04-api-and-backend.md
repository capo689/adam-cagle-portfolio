# API and Backend Correctness

> Covers checks API-01..09. Domain D04, weight 7.

The backend is the only place a rule is real. Everything the client enforces is a suggestion that a determined user, a scripted client, or a modified mobile binary will decline.

---

## 1. Never trust the client, specifically

The abstract version of this advice is useless. The concrete version is a list of things AI-generated handlers accept that they must not:

| Client-supplied field | What must happen instead |
|---|---|
| `price`, `amount`, `total` | Recompute server-side from the catalog and the cart |
| `role`, `isAdmin`, `plan`, `tier` | Read from the server's own record for the authenticated user |
| `userId`, `ownerId`, `tenantId` | Derive from the session; never accept from the body |
| `status`, `verified`, `approved` | Set only by the server-side state machine |
| `createdAt`, `updatedAt` | Server clock |
| `discount`, `credits` | Look up and validate server-side |

Mass assignment is the mechanism. `Object.assign(user, req.body)` or `Model.update(**request.json)` hands the caller your entire schema. Use explicit allowlists or strict schemas that reject unknown fields.

```ts
const UpdateProfile = z.object({
  displayName: z.string().min(1).max(80),
  bio: z.string().max(500).optional(),
}).strict();                                  // unknown keys -> error, not silently ignored
```

## 2. Runtime validation at every trust boundary

TypeScript types are erased at runtime. A handler typed `(req: Request<{}, {}, CreateOrder>)` has exactly zero runtime guarantees, and AI-generated code treats that annotation as if it were enforcement.

Validate at the boundary — body, query, params, headers you read, webhook payloads, model output, and anything read from a queue. Use Zod, Valibot, Pydantic, or JSON Schema. Prefer `.strict()` so extra fields fail loudly.

The payoff beyond correctness: a validated boundary makes fuzzing productive. Point Schemathesis at your OpenAPI spec and it will find the unvalidated edges in minutes without you writing a test.

## 3. Error handling

OWASP added **A10:2025 Mishandling of Exceptional Conditions** for this. Two failure modes:

**Leaking internals.** A stack trace in a 500 response gives away file paths, library versions, and schema. Map internal errors to generic client messages carrying a correlation ID; put the detail in the log.

**Failing open.** An exception in an authorization path that gets caught by a generic handler and falls through to "allow" is a total bypass. Authorization code must fail closed by construction:

```ts
// wrong: any throw inside canAccess() becomes "allowed"
try { if (await canAccess(user, doc)) return doc; } catch { /* swallowed */ }
return doc;   // <- the bug

// right
let allowed = false;
try { allowed = await canAccess(user, doc); } catch (e) { log.error(e); allowed = false; }
if (!allowed) throw forbidden();
```

Return the same status for "not found" and "not authorized" on resources whose existence is itself sensitive — otherwise 403-vs-404 is an enumeration oracle.

## 4. External calls

Every outbound call needs four things, and AI-generated code typically has none of them:

1. **A timeout.** Default HTTP clients often have none. A hanging call holds a connection until something else breaks.
2. **Bounded retries with exponential backoff and jitter** — and only for idempotent operations. Retrying a charge is worse than failing it.
3. **A circuit breaker** so repeated failure stops hammering a struggling provider.
4. **A defined degraded behavior.** Fail closed, fail open, queue, or serve stale — decide per dependency, in writing.

Put all of it in one wrapper per provider. Scattered SDK calls make caching, cost tracking, retries, and provider swaps impossible. Enforce the boundary with a lint rule:

```json
"no-restricted-imports": ["error", {
  "paths": [{ "name": "stripe", "message": "Use src/services/payments instead." }]
}]
```

## 5. Long work does not belong in a request

Serverless platforms have hard timeouts. PDF generation, bulk email, imports, image processing, and multi-step AI chains all exceed them at realistic sizes, and the failure mode is a 504 with half-completed state.

Measure p95 per endpoint. Anything approaching the platform limit moves to a queue: accept the request, return an ID, do the work in a worker, expose status via polling or a realtime channel.

Jobs need: idempotency, bounded retries, a dead-letter queue, visibility into depth and age, and alerts on failure. **Silent job failure is the most common invisible outage** — nothing returns 500, work just stops happening. Add a dead-man's-switch monitor for crons: the alert fires when a job *does not* run.

## 6. Bounded responses

An unbounded list endpoint is a denial-of-service primitive and a convenient exfiltration tool. CWE-770 (allocation without limits) is on the 2025 CWE Top 25.

- Enforce a maximum page size server-side; clamp rather than error
- Allowlist sortable and filterable fields — passing user input into `ORDER BY` is injection
- Cap request body size at the edge
- Cap the depth and cost of GraphQL queries, and disable introspection in production

## 7. Contracts

For anything with a separate frontend, a mobile client, or an external consumer, an explicit contract is the difference between a change that breaks a client at deploy time and one that breaks it in CI.

OpenAPI plus generated client types, or a typed RPC layer (tRPC, ts-rest) where both ends are TypeScript. Then:

```bash
uvx schemathesis run https://staging.example.com/openapi.json   # property-based fuzzing
oasdiff breaking old.yaml new.yaml                              # breaking-change detection in CI
```

Schemathesis is unusually high-value for AI-built APIs: it requires no test authoring, and it finds precisely the failure profile these codebases have — edge-case inputs producing 500s, responses that drift from the documented shape, and validation that accepts data it should reject.

Full consumer-driven contract testing (Pact) is usually overkill below several independently-deployed services. Schema-first plus runtime validation gets most of the value at a fraction of the operational cost.
