#!/usr/bin/env python3
"""
FINISHER scoring engine v2.

Deterministic, auditable production-readiness scoring. The same state file always
produces the same number, regardless of who or what runs the assessment.

Usage
-----
  finisher_score.py init     [--catalog checks.yaml] --context context.json -o state.json
  finisher_score.py validate [--catalog checks.yaml] --state state.json
  finisher_score.py score    [--catalog checks.yaml] --state state.json [--json]
  finisher_score.py commit   [--catalog checks.yaml] --state state.json \
                             --run-id 2026-07-25-a [--actions actions.json]
  finisher_score.py history  [--dir finisher]

Catalog resolution order: --catalog, then FINISHER_CATALOG, then ./checks.yaml,
then ../assets/checks.yaml relative to this script. This works both inside the
skill bundle and in a flat upload directory.

Integrity properties this program tries to hold
-----------------------------------------------
* Unknown applicability conditions INCLUDE the check and flag it. Excluding a check
  is the fail-open direction; inclusion is fail-closed.
* `na` on a check the context says applies is an ERROR for P0/P1, not a warning.
* `commit --force` never writes the authoritative ledger or SCORE.md. It produces a
  clearly-marked UNOFFICIAL report only.
* Every ledger entry records the applicability context, a context hash, a catalog
  hash, and a state hash, so two runs under different scopes are never silently
  compared.
* Every committed run snapshots the full state file next to its report.
* Writes are atomic; commits take an exclusive lock.

No third-party dependencies required (falls back to a narrow YAML reader that
raises rather than silently skipping content it does not understand).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
import time
from datetime import datetime, timezone

SCALE_MAX = 4
LEVELS = {0: "ABSENT", 1: "CLAIMED", 2: "IMPLEMENTED", 3: "VERIFIED", 4: "ENFORCED"}
SCHEMA_VERSION = 2


class FinisherError(Exception):
    """Fatal, user-facing error."""


# --------------------------------------------------------------------------
# YAML loading
# --------------------------------------------------------------------------
try:
    import yaml  # type: ignore

    def load_yaml(path):
        with open(path, "r", encoding="utf-8-sig") as fh:
            return yaml.safe_load(fh)

except ImportError:  # pragma: no cover - exercised by test_finisher_score.py

    def _coerce(v):
        v = v.strip()
        if v.startswith("[") and v.endswith("]"):
            inner = v[1:-1].strip()
            return [] if not inner else [_coerce(x) for x in _split_flow(inner)]
        if v.startswith("{") and v.endswith("}"):
            out = {}
            for part in _split_flow(v[1:-1]):
                if ":" in part:
                    k, _, val = part.partition(":")
                    out[_coerce(k)] = _coerce(val)
            return out
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            return v[1:-1]
        if v in ("true", "True"):
            return True
        if v in ("false", "False"):
            return False
        if v in ("null", "~", ""):
            return None
        for cast in (int, float):
            try:
                return cast(v)
            except ValueError:
                pass
        return v

    def _split_flow(s):
        parts, depth, cur, quote = [], 0, "", None
        for ch in s:
            if quote:
                cur += ch
                if ch == quote:
                    quote = None
                continue
            if ch in "\"'":
                quote, cur = ch, cur + ch
                continue
            if ch in "[{":
                depth += 1
            elif ch in "]}":
                depth -= 1
            if ch == "," and depth == 0:
                parts.append(cur)
                cur = ""
            else:
                cur += ch
        if cur.strip():
            parts.append(cur)
        return [p.strip() for p in parts]

    def load_yaml(path):
        """Parse the subset of YAML the FINISHER catalog uses.

        Raises FinisherError on any line it cannot account for, rather than
        skipping it. Silent skipping is how a catalog loses checks.
        """
        with open(path, "r", encoding="utf-8-sig") as fh:
            raw = fh.read().replace("\ufeff", "")
        lines = [ln.rstrip() for ln in raw.split("\n")]
        root = {}
        stack = [(-1, root)]
        i = 0
        while i < len(lines):
            line = lines[i]
            lineno = i + 1
            i += 1
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            indent = len(line) - len(line.lstrip())
            body = line.strip()
            is_item = body.startswith("- ")
            while len(stack) > 1:
                top_indent, top_obj = stack[-1]
                if indent < top_indent or (
                    indent == top_indent and not (is_item and isinstance(top_obj, list))
                ):
                    stack.pop()
                else:
                    break
            parent = stack[-1][1]
            if is_item:
                item_body = body[2:]
                if not isinstance(parent, list):
                    raise FinisherError(
                        f"{path}:{lineno}: list item under a non-list parent: {body[:60]}"
                    )
                if ":" in item_body and not item_body.startswith(("{", "[")):
                    obj = {}
                    parent.append(obj)
                    stack.append((indent, obj))
                    k, _, v = item_body.partition(":")
                    obj[k.strip()] = _coerce(v)
                else:
                    parent.append(_coerce(item_body))
                continue
            if ":" not in body:
                raise FinisherError(f"{path}:{lineno}: cannot parse line: {body[:60]}")
            key, _, val = body.partition(":")
            key, val = key.strip(), val.strip()
            if val == "":
                nxt = None
                for j in range(i, len(lines)):
                    if lines[j].strip() and not lines[j].lstrip().startswith("#"):
                        nxt = lines[j]
                        break
                is_list = bool(
                    nxt
                    and nxt.strip().startswith("- ")
                    and (len(nxt) - len(nxt.lstrip())) <= indent + 2
                )
                container = [] if is_list else {}
                if not isinstance(parent, dict):
                    raise FinisherError(f"{path}:{lineno}: mapping key inside a list item")
                parent[key] = container
                stack.append((indent, container))
            else:
                if val.startswith((">", "|")):
                    raise FinisherError(
                        f"{path}:{lineno}: block scalars are not supported by the fallback "
                        f"parser. Install PyYAML (pip install pyyaml) or quote the value."
                    )
                if not isinstance(parent, dict):
                    raise FinisherError(f"{path}:{lineno}: mapping key inside a list item")
                parent[key] = _coerce(val)
        return root


# --------------------------------------------------------------------------
# Hashing and atomic IO
# --------------------------------------------------------------------------
def sha(obj) -> str:
    if isinstance(obj, (dict, list)):
        blob = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    elif isinstance(obj, bytes):
        blob = obj
    else:
        blob = str(obj).encode()
    return hashlib.sha256(blob).hexdigest()[:16]


def file_sha(path) -> str:
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()[:16]


def atomic_write(path, text):
    d = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".finisher-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def atomic_append(path, line):
    """Append one line durably. Called under lock, so read-modify-write is safe."""
    existing = ""
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as fh:
            existing = fh.read()
        if existing and not existing.endswith("\n"):
            existing += "\n"
    atomic_write(path, existing + line + "\n")


PENDING = ".pending"


def promote_pending(root):
    """Recover from a commit interrupted between staging and the ledger append.

    A .pending file whose run_id is in a ledger is promoted (the commit point was
    reached). One that is not is deleted (it never committed)."""
    committed = set()
    for name in ("ledger.jsonl", "ledger-unofficial.jsonl"):
        for e in read_ledger(os.path.join(root, name), strict=False):
            committed.add(e.get("run_id"))
    for sub in ("runs", "unofficial"):
        d = os.path.join(root, sub)
        if not os.path.isdir(d):
            continue
        for f in os.listdir(d):
            if not f.endswith(PENDING):
                continue
            src = os.path.join(d, f)
            final = src[: -len(PENDING)]
            rid = os.path.basename(final).split(".")[0].replace("-UNOFFICIAL", "")
            if rid in committed:
                os.replace(src, final)
                print(f"NOTE  recovered interrupted commit: {final}")
            else:
                os.unlink(src)


class Lock:
    """Exclusive lock so two concurrent commits cannot interleave."""

    def __init__(self, path, timeout=30):
        self.path, self.timeout, self.fd = path, timeout, None

    def __enter__(self):
        os.makedirs(os.path.dirname(os.path.abspath(self.path)) or ".", exist_ok=True)
        deadline = time.time() + self.timeout
        while True:
            try:
                self.fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(self.fd, f"{os.getpid()}".encode())
                return self
            except FileExistsError:
                if time.time() > deadline:
                    raise FinisherError(
                        f"could not acquire {self.path} within {self.timeout}s. "
                        f"If no other commit is running, delete it."
                    )
                time.sleep(0.2)

    def __exit__(self, *exc):
        if self.fd is not None:
            os.close(self.fd)
        try:
            os.unlink(self.path)
        except OSError:
            pass


# --------------------------------------------------------------------------
# Catalog / state schema validation
# --------------------------------------------------------------------------
REQUIRED_CHECK_FIELDS = ("id", "domain", "tier", "weight", "when", "title", "risk", "fix",
                         "evidence", "enforce")


def validate_catalog(cat, path="catalog"):
    if not isinstance(cat, dict):
        raise FinisherError(f"{path}: top level is not a mapping")
    for key in ("meta", "domains", "checks", "conditions"):
        if key not in cat:
            raise FinisherError(f"{path}: missing top-level key '{key}'")
    meta = cat["meta"]
    for key in ("catalog_version", "closed_at", "ceilings", "bands"):
        if key not in meta:
            raise FinisherError(f"{path}: meta missing '{key}'")
    conds = set(cat["conditions"]) | {"always"}
    dom_ids = set()
    for d in cat["domains"]:
        for key in ("id", "name", "weight", "when"):
            if key not in d:
                raise FinisherError(f"{path}: domain {d.get('id','?')} missing '{key}'")
        if d["id"] in dom_ids:
            raise FinisherError(f"{path}: duplicate domain id {d['id']}")
        dom_ids.add(d["id"])
        for w in d["when"]:
            if str(w).lstrip("!") not in conds:
                raise FinisherError(f"{path}: domain {d['id']} unknown condition '{w}'")
    seen = set()
    for c in cat["checks"]:
        cid = c.get("id", "?")
        for key in REQUIRED_CHECK_FIELDS:
            if not c.get(key):
                raise FinisherError(f"{path}: check {cid} missing or empty '{key}'")
        if cid in seen:
            raise FinisherError(f"{path}: duplicate check id {cid}")
        seen.add(cid)
        if c["domain"] not in dom_ids:
            raise FinisherError(f"{path}: check {cid} unknown domain {c['domain']}")
        if c["tier"] not in ("P0", "P1", "P2"):
            raise FinisherError(f"{path}: check {cid} bad tier {c['tier']}")
        if not isinstance(c["weight"], int) or not 1 <= c["weight"] <= 5:
            raise FinisherError(f"{path}: check {cid} weight must be an int 1-5")
        for w in (c["when"] if isinstance(c["when"], list) else [c["when"]]):
            if str(w).lstrip("!") not in conds:
                raise FinisherError(f"{path}: check {cid} unknown condition '{w}'")
    return cat


def catalog_drift(catalog, state):
    """Compare the catalog a state was created from against the current one."""
    known = {c["id"] for c in catalog["checks"]}
    have = set(state.get("checks", {}))
    return {
        "hash_changed": bool(state.get("catalog_hash")
                             and state["catalog_hash"] != catalog.get("_hash")),
        "version_state": state.get("catalog_version"),
        "version_catalog": catalog["meta"]["catalog_version"],
        "missing_from_state": sorted(known - have),
        "stale_in_state": sorted(have - known),
    }


def load_state(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            st = json.load(fh)
    except json.JSONDecodeError as e:
        raise FinisherError(f"{path}: not valid JSON ({e})")
    if not isinstance(st, dict) or "checks" not in st:
        raise FinisherError(f"{path}: state must be an object with a 'checks' key")
    st.setdefault("context", {})
    if not isinstance(st["context"], dict):
        raise FinisherError(f"{path}: 'context' must be an object")
    if not isinstance(st["checks"], dict):
        raise FinisherError(f"{path}: 'checks' must be an object")
    return st


def drift_messages(d, for_commit=False):
    msgs = []
    if not (d["hash_changed"] or d["missing_from_state"] or d["stale_in_state"]):
        return msgs
    msgs.append(
        f"CATALOG MISMATCH: this state was created from catalog {d['version_state']} "
        f"but is being scored against {d['version_catalog']}. "
        f"{len(d['missing_from_state'])} check(s) in the catalog are absent from the state; "
        f"{len(d['stale_in_state'])} state entr(ies) are not in the catalog.")
    if d["missing_from_state"]:
        head = ", ".join(d["missing_from_state"][:10])
        extra = f", +{len(d['missing_from_state']) - 10} more" if len(d["missing_from_state"]) > 10 else ""
        msgs.append(f"  checks missing from state (scored 0, counted against you): {head}{extra}")
    if d["stale_in_state"]:
        msgs.append(f"  stale state entries (ignored): {', '.join(d['stale_in_state'][:10])}")
    msgs.append("  Run `finisher_score.py migrate --state <file>` to reconcile before committing.")
    return msgs


# --------------------------------------------------------------------------
# Applicability
# --------------------------------------------------------------------------
def applies(when, context):
    """Return (in_scope, assumed).

    `assumed` is True when a referenced condition is absent from the context.
    An absent condition INCLUDES the check: removing a check from scope is the
    fail-open direction, and a silently dropped P0 is the failure mode this
    program exists to prevent. Explicit false excludes; absent does not.
    """
    if not when:
        return True, False
    if isinstance(when, str):
        when = [when]
    assumed = False
    for cond in when:
        if cond == "always":
            continue
        neg = cond.startswith("!")
        key = cond[1:] if neg else cond
        if key not in context:
            assumed = True
            continue  # unknown -> do not exclude
        val = bool(context[key])
        if neg:
            val = not val
        if not val:
            return False, assumed
    return True, assumed


def band_for(score, bands):
    for b in bands:
        if b["min"] <= score <= b["max"]:
            return b["label"]
    return "UNKNOWN"


def coerce_score(raw, cid):
    if raw is None:
        return None
    if isinstance(raw, bool) or not isinstance(raw, (int, float)):
        raise FinisherError(f"{cid}: score must be a number 0-4, got {raw!r}")
    if raw != int(raw) or not 0 <= int(raw) <= SCALE_MAX:
        raise FinisherError(f"{cid}: score must be an integer 0-4, got {raw!r}")
    return int(raw)


# --------------------------------------------------------------------------
# Scoring
# --------------------------------------------------------------------------
def compute(catalog, state):
    meta = catalog["meta"]
    context = state.get("context", {})
    scores = state.get("checks", {})
    closed_at = meta["closed_at"]
    domains = {d["id"]: d for d in catalog["domains"]}

    per_check, per_domain = [], {}
    open_by_tier = {"P0": [], "P1": [], "P2": []}
    assumed_conditions = set()
    assessed = total_applicable = 0

    for chk in catalog["checks"]:
        cid = chk["id"]
        dom = domains.get(chk["domain"])
        entry = scores.get(cid) or {}
        if not isinstance(entry, dict):
            raise FinisherError(f"{cid}: state entry must be an object")
        na = bool(entry.get("na"))

        dom_ok, dom_assumed = applies(dom.get("when"), context) if dom else (False, False)
        chk_ok, chk_assumed = applies(chk.get("when"), context)
        was_assumed = dom_assumed or chk_assumed
        context_says_applies = dom_ok and chk_ok
        in_scope = context_says_applies and not na
        if context_says_applies and was_assumed:
            for w in (chk["when"] if isinstance(chk["when"], list) else [chk["when"]]):
                k = str(w).lstrip("!")
                if k != "always" and k not in context:
                    assumed_conditions.add(k)

        score = coerce_score(entry.get("score"), cid) or 0
        has_ev = bool((entry.get("evidence") or "").strip())
        rec = {
            "id": cid, "domain": chk["domain"], "tier": chk["tier"],
            "weight": int(chk["weight"]), "title": chk["title"],
            "score": score, "level": LEVELS[score],
            "applicable": in_scope, "assumed_applicable": in_scope and was_assumed,
            "na": na, "na_reason": entry.get("na_reason"),
            "context_says_applies": context_says_applies,
            "evidence": entry.get("evidence"), "artifact": entry.get("artifact"),
            "enforcement": entry.get("enforcement"), "notes": entry.get("notes"),
        }
        per_check.append(rec)
        if not in_scope:
            continue

        total_applicable += 1
        # A check counts as assessed when it was scored above zero, OR when a zero
        # is documented with evidence (a confirmed absence is an assessment), OR
        # when explicitly flagged assessed.
        if score > 0 or has_ev or entry.get("assessed") is True:
            assessed += 1

        d = per_domain.setdefault(chk["domain"], {
            "id": chk["domain"], "name": dom["name"], "weight": dom["weight"],
            "earned": 0, "possible": 0, "checks": 0, "open_p0": 0, "open_p1": 0})
        d["earned"] += rec["weight"] * score
        d["possible"] += rec["weight"] * SCALE_MAX
        d["checks"] += 1
        if score < closed_at.get(chk["tier"], 3):
            open_by_tier[chk["tier"]].append(rec)
            if chk["tier"] == "P0":
                d["open_p0"] += 1
            elif chk["tier"] == "P1":
                d["open_p1"] += 1

    for d in per_domain.values():
        d["score"] = round(100.0 * d["earned"] / d["possible"], 1) if d["possible"] else 0.0

    wsum = sum(d["weight"] for d in per_domain.values())
    raw_composite = (round(sum(d["weight"] * d["score"] for d in per_domain.values()) / wsum, 1)
                     if wsum else 0.0)

    ceilings = meta["ceilings"]
    cap, cap_reason = 100, None
    if open_by_tier["P0"]:
        cap, cap_reason = ceilings["open_P0"], f"{len(open_by_tier['P0'])} P0 blocker(s) open"
    elif open_by_tier["P1"]:
        cap, cap_reason = ceilings["open_P1"], f"{len(open_by_tier['P1'])} P1 issue(s) open"
    elif open_by_tier["P2"]:
        cap, cap_reason = ceilings["open_P2"], f"{len(open_by_tier['P2'])} P2 item(s) open"

    composite = min(raw_composite, float(cap))
    coverage = round(100.0 * assessed / total_applicable, 1) if total_applicable else 0.0

    return {
        "composite": round(composite, 1), "raw_composite": raw_composite,
        "cap": cap, "cap_reason": cap_reason,
        "band": band_for(composite, meta["bands"]),
        "coverage": coverage, "applicable_checks": total_applicable,
        "assessed_checks": assessed,
        "assumed_conditions": sorted(assumed_conditions),
        "assumed_checks": [c["id"] for c in per_check if c["assumed_applicable"]],
        "domains": sorted(per_domain.values(), key=lambda x: x["id"]),
        "checks": per_check,
        "open": {k: [c["id"] for c in v] for k, v in open_by_tier.items()},
        "open_detail": open_by_tier,
    }


# --------------------------------------------------------------------------
# Validation
# --------------------------------------------------------------------------
ARTIFACT_HINT = re.compile(
    r"(/|\\|\.py|\.ts|\.js|\.tsx|\.sql|\.ya?ml|\.tf|::|https?://|\$ |#\d|\btest\b|\bspec\b|\brun\b)",
    re.IGNORECASE)
ENFORCE_HINT = re.compile(
    r"(ci|job|workflow|action|pipeline|hook|gate|policy|rule|alert|monitor|cron|check|lint|"
    r"required|middleware|schedul)", re.IGNORECASE)


def validate(catalog, state):
    errors, warnings, unscored = [], [], []
    context = state.get("context", {})
    known = {c["id"] for c in catalog["checks"]}
    domains = {d["id"]: d for d in catalog["domains"]}

    for cid in state.get("checks", {}):
        if cid not in known:
            warnings.append(f"{cid}: not in catalog (stale entry from an older catalog version?)")

    referenced = set()
    for chk in catalog["checks"]:
        for w in (chk["when"] if isinstance(chk["when"], list) else [chk["when"]]):
            k = str(w).lstrip("!")
            if k != "always":
                referenced.add(k)
    for k in sorted(referenced - set(context)):
        warnings.append(
            f"context: '{k}' is unset. Checks depending on it are INCLUDED and marked "
            f"'assumed applicable'. Set it explicitly to remove that assumption.")

    for chk in catalog["checks"]:
        cid, tier = chk["id"], chk["tier"]
        dom = domains.get(chk["domain"])
        entry = state.get("checks", {}).get(cid) or {}
        if not isinstance(entry, dict):
            errors.append(f"{cid}: state entry must be an object")
            continue
        dom_ok, _ = applies(dom.get("when"), context) if dom else (False, False)
        chk_ok, _ = applies(chk.get("when"), context)
        context_says_applies = dom_ok and chk_ok

        if entry.get("na"):
            if not (entry.get("na_reason") or "").strip():
                errors.append(f"{cid}: marked N/A without na_reason")
            if context_says_applies:
                msg = (f"{cid}: marked N/A but the intake context says it APPLIES. "
                       f"Either fix the context or remove the na flag — do not exclude "
                       f"an applicable check by hand.")
                (errors if tier in ("P0", "P1") else warnings).append(msg)
            continue
        if not context_says_applies:
            continue

        try:
            s = coerce_score(entry.get("score"), cid)
        except FinisherError as e:
            errors.append(str(e))
            continue
        if s is None:
            unscored.append(cid)
            continue
        ev = (entry.get("evidence") or "").strip()
        if s == 0 and not ev and entry.get("assessed") is not True:
            warnings.append(
                f"{cid}: score 0 with no evidence — counts as UNASSESSED. If you looked and "
                f"it is genuinely absent, record that in `evidence` (or set assessed: true) "
                f"so coverage reflects the work.")
        if s >= 2 and not ev:
            errors.append(f"{cid}: score {s} requires evidence")
        if s >= 3:
            art = (entry.get("artifact") or "").strip()
            if not art:
                errors.append(f"{cid}: score {s} (VERIFIED) requires a named artifact")
            elif not ARTIFACT_HINT.search(art):
                warnings.append(
                    f"{cid}: artifact '{art[:60]}' does not look like a file, test, command "
                    f"or URL a stranger could re-run")
        if s >= 4:
            enf = (entry.get("enforcement") or "").strip()
            if not enf:
                errors.append(f"{cid}: score 4 (ENFORCED) requires a named enforcement point")
            elif not ENFORCE_HINT.search(enf):
                warnings.append(
                    f"{cid}: enforcement '{enf[:60]}' does not name a recognisable automation "
                    f"(CI job, rule, alert, hook). Level 4 is attested, not proven — name it "
                    f"precisely enough that someone can go and look.")
    if unscored:
        head = ", ".join(unscored[:8]) + (f", +{len(unscored) - 8} more" if len(unscored) > 8 else "")
        warnings.append(
            f"{len(unscored)} applicable checks are unscored — they count as 0 and as UNASSESSED "
            f"for coverage: {head}")
    return errors, warnings


# --------------------------------------------------------------------------
# Ledger
# --------------------------------------------------------------------------
def read_ledger(path, strict=True):
    if not os.path.exists(path):
        return []
    out = []
    with open(path, "r", encoding="utf-8") as fh:
        for n, line in enumerate(fh, 1):
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError as e:
                msg = f"{path}:{n}: corrupt ledger line ({e}). The run history is not trustworthy."
                if strict:
                    raise FinisherError(msg)
                print(f"WARN  {msg}", file=sys.stderr)
    return out


def diff_runs(prev, cur):
    prev_scores = (prev or {}).get("check_scores", {})
    prev_applicable = set(prev_scores)
    moved, regressed, newly_applicable = [], [], []
    for c in cur["checks"]:
        if not c["applicable"]:
            continue
        if c["id"] not in prev_applicable and prev is not None:
            newly_applicable.append(c["id"])
            continue  # not a regression: it was out of scope before
        before, after = int(prev_scores.get(c["id"], 0)), c["score"]
        row = {"id": c["id"], "title": c["title"], "from": before, "to": after,
               "tier": c["tier"], "domain": c["domain"], "weight": c["weight"]}
        if after > before:
            moved.append(row)
        elif after < before:
            regressed.append(row)
    dropped = sorted(prev_applicable - {c["id"] for c in cur["checks"] if c["applicable"]})
    moved.sort(key=lambda x: (x["tier"], -(x["to"] - x["from"])))
    regressed.sort(key=lambda x: x["tier"])
    return moved, regressed, newly_applicable, dropped


# --------------------------------------------------------------------------
# Rendering
# --------------------------------------------------------------------------
def cell(s, limit=160):
    """Make arbitrary text safe inside a markdown table cell."""
    if s is None:
        return ""
    s = str(s).replace("|", "\\|").replace("\r", " ")
    s = re.sub(r"\s*\n\s*", " ", s).strip()
    return (s[: limit - 1] + "…") if len(s) > limit else s


def bar(pct, width=20):
    return "#" * int(round(pct / 100.0 * width)) + "." * (width - int(round(pct / 100.0 * width)))


def render_scorecard(res, prev=None, scope_changed=False):
    L = ["# FINISHER Scorecard", ""]
    delta = ""
    if prev and not scope_changed:
        d = round(res["composite"] - prev.get("composite", 0), 1)
        delta = f"  ({'+' if d >= 0 else ''}{d} vs previous run)"
    elif prev and scope_changed:
        delta = "  (scope changed — not directly comparable to the previous run)"
    L.append(f"**FINISHER Score: {res['composite']} / 100** -- **{res['band']}**{delta}")
    L.append("")
    L.append(f"- Uncapped weighted score: {res['raw_composite']}")
    if res["cap_reason"]:
        L.append(f"- **Capped at {res['cap']}**: {res['cap_reason']}")
    L.append(f"- Assessment coverage: {res['coverage']}% "
             f"({res['assessed_checks']}/{res['applicable_checks']} applicable checks assessed)")
    if res["coverage"] < 80:
        L.append("- WARNING: coverage below 80%. This score reflects what was looked at, "
                 "not what is true. Do not quote it to anyone making a launch decision.")
    if res["assumed_conditions"]:
        L.append(f"- **{len(res['assumed_checks'])} checks are 'assumed applicable'** because these "
                 f"intake conditions are unset: {', '.join(res['assumed_conditions'])}. "
                 f"They are included deliberately — set them explicitly to narrow scope.")
    L.append(f"- Open blockers: P0 {len(res['open']['P0'])} | "
             f"P1 {len(res['open']['P1'])} | P2 {len(res['open']['P2'])}")
    L += ["", "## Domain scores", "",
          "| Domain | Score | | Wt | Checks | Open P0 | Open P1 |",
          "|---|---:|---|---:|---:|---:|---:|"]
    for d in res["domains"]:
        L.append(f"| {d['id']} {cell(d['name'])} | {d['score']} | `{bar(d['score'])}` | "
                 f"{d['weight']} | {d['checks']} | {d['open_p0']} | {d['open_p1']} |")
    L.append("")
    for tier, header, need in (("P0", "P0 -- blocks any launch", 3),
                               ("P1", "P1 -- blocks paid or public launch", 3),
                               ("P2", "P2 -- blocks scale", 2)):
        items = res["open_detail"][tier]
        if not items:
            L += [f"## {header}: none open", ""]
            continue
        L += [f"## {header} ({len(items)} open)", "",
              "| ID | Check | Now | Needed |", "|---|---|---:|---:|"]
        for c in items:
            L.append(f"| {c['id']} | {cell(c['title'])} | {c['score']} ({c['level']}) | {need} |")
        L.append("")
    return "\n".join(L)


def render_run_report(run_id, res, prev, moved, regressed, new_scope, dropped,
                      actions, notes, scope_changed, official=True):
    pre = prev.get("composite") if prev else None
    d = round(res["composite"] - (pre or 0), 1)
    L = [f"# FINISHER Run {run_id}" + ("" if official else "  — UNOFFICIAL"), ""]
    if not official:
        L += ["> **UNOFFICIAL RUN.** Committed with `--force` over validation errors. "
              "This report is a diagnostic only. It is NOT in the authoritative ledger and "
              "must not be quoted as a FINISHER score.", ""]
    L.append(f"- Date: {datetime.now(timezone.utc).isoformat(timespec='seconds')}")
    L.append(f"- **Pre-run score: {pre if prev else 'n/a (first run)'}**")
    L.append(f"- **Post-run score: {res['composite']}**")
    if scope_changed:
        L.append("- **Delta: not computed — the applicability context or catalog changed this "
                 "run, so the two scores measure different things.**")
    else:
        L.append(f"- **Delta: {'+' if d >= 0 else ''}{d}**")
    L.append(f"- Band: {prev.get('band') if prev else 'n/a'} -> **{res['band']}**")
    L.append(f"- Coverage: {(prev or {}).get('coverage', 0)}% -> {res['coverage']}%")
    L.append(f"- Open P0: {(prev or {}).get('open_p0', 'n/a')} -> {len(res['open']['P0'])}")
    L.append("")
    if scope_changed:
        L += ["## Scope change", "",
              "The intake context or the catalog changed since the last run. Per-check deltas below "
              "are still accurate; the composite comparison is not. Newly applicable checks appear "
              "under their own heading rather than as regressions from zero.", ""]
    if notes:
        L += ["## Summary", "", cell(notes, 4000), ""]
    L += ["## What changed the score", ""]
    if moved:
        L += ["| Check | Tier | Before | After | What was done |", "|---|---|---:|---:|---|"]
        for m in moved:
            L.append(f"| {m['id']} {cell(m['title'], 60)} | {m['tier']} | {m['from']} | "
                     f"{m['to']} | {cell(actions.get(m['id'], ''))} |")
    else:
        L.append("_No checks improved this run._")
    L.append("")
    if regressed:
        L += ["## Regressions", "", "| Check | Tier | Before | After | Why |",
              "|---|---|---:|---:|---|"]
        for m in regressed:
            L.append(f"| {m['id']} {cell(m['title'], 60)} | {m['tier']} | {m['from']} | "
                     f"{m['to']} | {cell(actions.get(m['id'], 'UNEXPLAINED — investigate'))} |")
        L.append("")
    if new_scope:
        L += ["## Newly applicable this run (scope widened)", "",
              "These were out of scope in the previous run. They are not regressions.", "",
              "- " + ", ".join(new_scope), ""]
    if dropped:
        L += ["## No longer applicable (scope narrowed)", "",
              "These were scored previously and are now out of scope. Confirm this was deliberate.",
              "", "- " + ", ".join(dropped), ""]
    accounted = {m["id"] for m in moved} | {m["id"] for m in regressed}
    unmapped = {k: v for k, v in actions.items() if k not in accounted}
    if unmapped:
        L += ["## Work done that did not move a score", ""]
        L += [f"- **{k}**: {cell(v, 500)}" for k, v in sorted(unmapped.items())]
        L.append("")
    L += ["## Next run: highest-value targets", ""]
    targets = sorted([c for t in ("P0", "P1", "P2") for c in res["open_detail"][t]],
                     key=lambda c: ({"P0": 0, "P1": 1, "P2": 2}[c["tier"]],
                                    -(c["weight"] * (SCALE_MAX - c["score"]))))[:10]
    if targets:
        L += ["| ID | Tier | Check | Now | Points available |", "|---|---|---|---:|---:|"]
        for c in targets:
            L.append(f"| {c['id']} | {c['tier']} | {cell(c['title'], 70)} | {c['score']} | "
                     f"{c['weight'] * (SCALE_MAX - c['score'])} |")
    else:
        L.append("_Nothing open. Re-verify coverage and re-run._")
    L.append("")
    return "\n".join(L)


# --------------------------------------------------------------------------
# Catalog resolution
# --------------------------------------------------------------------------
def resolve_catalog(explicit):
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [explicit, os.environ.get("FINISHER_CATALOG"),
                  os.path.join(here, "checks.yaml"),
                  os.path.join(here, "..", "assets", "checks.yaml"),
                  os.path.join(os.getcwd(), "checks.yaml"),
                  os.path.join(os.getcwd(), "assets", "checks.yaml")]
    for c in candidates:
        if c and os.path.exists(c):
            return os.path.normpath(c)
    raise FinisherError(
        "checks.yaml not found. Pass --catalog, set FINISHER_CATALOG, or place checks.yaml "
        "beside this script.")


def get_catalog(args):
    path = resolve_catalog(getattr(args, "catalog", None))
    cat = validate_catalog(load_yaml(path), path)
    cat["_path"], cat["_hash"] = path, file_sha(path)
    return cat


# --------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------
def cmd_init(args):
    catalog = get_catalog(args)
    context = {}
    if args.context:
        if not os.path.exists(args.context):
            raise FinisherError(f"context file not found: {args.context}")
        with open(args.context, "r", encoding="utf-8") as fh:
            context = {k: v for k, v in json.load(fh).items() if not k.startswith("_")}
    known = set(catalog["conditions"])
    if (not getattr(args, "allow_empty_context", False)
            and known <= set(context) and all(context.get(k) is False for k in known)):
        raise FinisherError(
            "every condition in the context is false. That reads as an explicit decision to "
            "exclude every conditional check, which is almost never what you mean and would "
            "silently drop P0 blockers.\n"
            "  Delete the keys you are unsure about — absent conditions INCLUDE their checks and "
            "are flagged 'assumed applicable'.\n"
            "  See context.example.json for a filled-in example. Pass --allow-empty-context if a "
            "genuinely static, userless, dataless project is really what you are scoring.")
    for k in set(context) - known:
        print(f"WARN  context key '{k}' is not a known condition; ignored by scoring.")
    domains = {d["id"]: d for d in catalog["domains"]}
    checks, unset = {}, set()
    for chk in catalog["checks"]:
        dom = domains.get(chk["domain"])
        dom_ok, da = applies(dom.get("when"), context)
        chk_ok, ca = applies(chk.get("when"), context)
        in_scope = dom_ok and chk_ok
        if in_scope and (da or ca):
            for w in (chk["when"] if isinstance(chk["when"], list) else [chk["when"]]):
                k = str(w).lstrip("!")
                if k != "always" and k not in context:
                    unset.add(k)
        checks[chk["id"]] = {
            "score": None, "evidence": None, "artifact": None, "enforcement": None,
            "assessed": False,
            "na": (not in_scope),
            "na_reason": (None if in_scope else "out of scope for this project context"),
            "notes": None}
    state = {
        "schema_version": SCHEMA_VERSION,
        "project": args.project or "unnamed",
        "catalog_version": catalog["meta"]["catalog_version"],
        "catalog_hash": catalog["_hash"],
        "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "context": context,
        "checks": checks}
    atomic_write(args.out, json.dumps(state, indent=2))
    n = sum(1 for c in checks.values() if not c["na"])
    print(f"Wrote {args.out}: {n} applicable checks of {len(checks)} in catalog.")
    if unset:
        print(f"NOTE  these conditions are unset and were treated as APPLICABLE (fail-closed): "
              f"{', '.join(sorted(unset))}")
        print("      Set them explicitly in the context file to narrow scope deliberately.")
    return 0


def cmd_validate(args):
    catalog = get_catalog(args)
    state = load_state(args.state)
    errors, warnings = validate(catalog, state)
    warnings = drift_messages(catalog_drift(catalog, state)) + warnings
    for w in warnings:
        print(f"WARN  {w}")
    for e in errors:
        print(f"ERROR {e}")
    print(f"\n{len(errors)} error(s), {len(warnings)} warning(s).")
    return 1 if errors else 0


def cmd_score(args):
    catalog = get_catalog(args)
    state = load_state(args.state)
    for m in drift_messages(catalog_drift(catalog, state)):
        print(f"WARN  {m}", file=sys.stderr)
    res = compute(catalog, state)
    ledger = read_ledger(os.path.join(args.dir, "ledger.jsonl"), strict=False)
    prev = ledger[-1] if ledger else None
    scope_changed = bool(prev and (prev.get("context_hash") != sha(state.get("context", {}))
                                   or prev.get("catalog_hash") != catalog["_hash"]))
    if args.json:
        res["scope_changed"] = scope_changed
        print(json.dumps(res, indent=2))
    else:
        print(render_scorecard(res, prev, scope_changed))
    return 0


def load_actions(path):
    if not path or not os.path.exists(path):
        return {}, ""
    with open(path, "r", encoding="utf-8") as fh:
        try:
            payload = json.load(fh)
        except json.JSONDecodeError as e:
            raise FinisherError(f"{path}: not valid JSON ({e})")
    if not isinstance(payload, dict):
        raise FinisherError(
            f"{path}: actions file must be a JSON object, got {type(payload).__name__}. "
            f'Expected {{"summary": "...", "actions": {{"CHECK-ID": "what you did"}}}}')
    notes = payload.get("summary", "")
    actions = payload.get("actions", {k: v for k, v in payload.items() if k != "summary"})
    if not isinstance(actions, dict):
        raise FinisherError(f"{path}: 'actions' must be an object mapping check IDs to text")
    if not isinstance(notes, str):
        raise FinisherError(f"{path}: 'summary' must be a string")
    return {str(k): str(v) for k, v in actions.items()}, notes


def cmd_commit(args):
    catalog = get_catalog(args)
    state = load_state(args.state)
    drift = catalog_drift(catalog, state)
    errors, warnings = validate(catalog, state)
    if drift["missing_from_state"] and not args.accept_catalog_drift:
        errors = drift_messages(drift) + errors
    else:
        warnings = drift_messages(drift) + warnings
    official = not errors
    if errors and not args.force:
        for e in errors:
            print(f"ERROR {e}")
        print("\nRefusing to commit an invalid state. Fix the above, or use --force to "
              "produce an UNOFFICIAL diagnostic report (it will not enter the ledger).")
        return 1
    for w in warnings:
        print(f"WARN  {w}")

    res = compute(catalog, state)
    actions, notes = load_actions(args.actions)
    ctx_hash, state_hash = sha(state.get("context", {})), sha(state.get("checks", {}))
    ledger_path = os.path.join(args.dir, "ledger.jsonl")

    with Lock(os.path.join(args.dir, ".commit.lock")):
        ledger = read_ledger(ledger_path)
        if official and any(e.get("run_id") == args.run_id for e in ledger):
            raise FinisherError(
                f"run-id '{args.run_id}' already exists in the ledger. Run IDs must be unique "
                f"or the history becomes ambiguous. Use a different one.")
        prev = ledger[-1] if ledger else None
        scope_changed = bool(prev and (prev.get("context_hash") != ctx_hash
                                       or prev.get("catalog_hash") != catalog["_hash"]))
        moved, regressed, new_scope, dropped = diff_runs(prev, res)

        subdir = "runs" if official else "unofficial"
        os.makedirs(os.path.join(args.dir, subdir), exist_ok=True)
        promote_pending(args.dir)  # finish any commit interrupted mid-flight
        report = render_run_report(args.run_id, res, prev or {}, moved, regressed,
                                   new_scope, dropped, actions, notes, scope_changed, official)
        suffix = "" if official else "-UNOFFICIAL"
        run_path = os.path.join(args.dir, subdir, f"{args.run_id}{suffix}.md")
        snap_path = os.path.join(args.dir, subdir, f"{args.run_id}{suffix}.state.json")
        # Stage first. The ledger append is the commit point; only after it succeeds do these
        # become visible under their real names. A crash before that leaves .pending files that
        # the next run cleans up, never a ledger entry pointing at a missing report.
        pend_run, pend_snap = run_path + PENDING, snap_path + PENDING
        atomic_write(pend_run, report)
        atomic_write(pend_snap, json.dumps(state, indent=2, sort_keys=True))

        entry = {
            "schema_version": SCHEMA_VERSION, "run_id": args.run_id,
            "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "official": official,
            "catalog_version": catalog["meta"]["catalog_version"],
            "catalog_hash": catalog["_hash"], "context_hash": ctx_hash,
            "state_hash": state_hash, "state_snapshot": os.path.relpath(snap_path, args.dir),
            "context": state.get("context", {}),
            "scope_changed": scope_changed,
            "commit": args.commit_sha,
            "composite": res["composite"], "raw_composite": res["raw_composite"],
            "band": res["band"], "cap": res["cap"], "coverage": res["coverage"],
            "applicable_checks": res["applicable_checks"],
            "assessed_checks": res["assessed_checks"],
            "assumed_conditions": res["assumed_conditions"],
            "open_p0": len(res["open"]["P0"]), "open_p1": len(res["open"]["P1"]),
            "open_p2": len(res["open"]["P2"]),
            "domain_scores": {d["id"]: d["score"] for d in res["domains"]},
            "check_scores": {c["id"]: c["score"] for c in res["checks"] if c["applicable"]},
            "check_evidence": {c["id"]: {"e": bool(c["evidence"]), "a": bool(c["artifact"]),
                                         "x": bool(c["enforcement"])}
                               for c in res["checks"] if c["applicable"]},
            "improved": [m["id"] for m in moved], "regressed": [m["id"] for m in regressed],
            "newly_applicable": new_scope, "no_longer_applicable": dropped,
            "actions": actions, "summary": notes,
            "validation_errors": [] if official else errors,
        }

        target = ledger_path if official else os.path.join(args.dir, "ledger-unofficial.jsonl")
        atomic_append(target, json.dumps(entry))          # <- commit point
        os.replace(pend_run, run_path)                     # <- promote
        os.replace(pend_snap, snap_path)
        if official:
            atomic_write(os.path.join(args.dir, "SCORE.md"),
                         render_scorecard(res, prev, scope_changed))

    pre = prev.get("composite") if prev else None
    d = round(res["composite"] - (pre or 0), 1)
    tag = "" if official else "  [UNOFFICIAL — not in ledger]"
    delta = "scope changed" if scope_changed else f"{'+' if d >= 0 else ''}{d}"
    print(f"Run {args.run_id}: {pre if prev else 'n/a'} -> {res['composite']} "
          f"({delta})  [{res['band']}]{tag}")
    print(f"  improved: {len(moved)}   regressed: {len(regressed)}   "
          f"newly applicable: {len(new_scope)}   dropped: {len(dropped)}")
    print(f"  open P0/P1/P2: {len(res['open']['P0'])}/{len(res['open']['P1'])}"
          f"/{len(res['open']['P2'])}   coverage: {res['coverage']}%")
    print(f"  wrote {run_path}")
    if not official:
        print("  SCORE.md and ledger.jsonl were NOT written — this run failed validation.")
    return 0 if official else 2


def cmd_migrate(args):
    catalog = get_catalog(args)
    state = load_state(args.state)
    d = catalog_drift(catalog, state)
    if not (d["hash_changed"] or d["missing_from_state"] or d["stale_in_state"]):
        print("State already matches the catalog. Nothing to migrate.")
        return 0
    domains = {x["id"]: x for x in catalog["domains"]}
    context = state.get("context", {})
    added = 0
    for chk in catalog["checks"]:
        if chk["id"] in state["checks"]:
            continue
        dom = domains.get(chk["domain"])
        in_scope = applies(dom.get("when"), context)[0] and applies(chk.get("when"), context)[0]
        state["checks"][chk["id"]] = {
            "score": None, "evidence": None, "artifact": None, "enforcement": None,
            "assessed": False, "na": (not in_scope),
            "na_reason": (None if in_scope else "out of scope for this project context"),
            "notes": f"added by migrate from catalog {catalog['meta']['catalog_version']}"}
        added += 1
    for cid in d["stale_in_state"]:
        state["checks"][cid]["notes"] = ((state["checks"][cid].get("notes") or "") +
                                         " [not in current catalog]").strip()
    state["catalog_version"] = catalog["meta"]["catalog_version"]
    state["catalog_hash"] = catalog["_hash"]
    atomic_write(args.state, json.dumps(state, indent=2))
    print(f"Migrated {args.state} to catalog {catalog['meta']['catalog_version']}: "
          f"{added} check(s) added, {len(d['stale_in_state'])} stale entr(ies) flagged.")
    if added:
        print("NOTE  new checks start unscored. They lower coverage until assessed — correct, "
              "but expect a score drop, and note the catalog change in the run summary.")
    return 0


def cmd_history(args):
    ledger = read_ledger(os.path.join(args.dir, "ledger.jsonl"), strict=False)
    if not ledger:
        print("No runs recorded.")
        return 0
    print(f"{'run':<24}{'score':>7}{'delta':>9}{'P0':>5}{'P1':>5}{'cov%':>7}  band")
    prev = None
    for e in ledger:
        if prev is None:
            delta = "--"
        elif e.get("scope_changed"):
            delta = "scope!"
        else:
            d = round(e["composite"] - prev["composite"], 1)
            delta = ("+" if d >= 0 else "") + str(d)
        print(f"{e['run_id']:<24}{e['composite']:>7}{delta:>9}"
              f"{e['open_p0']:>5}{e['open_p1']:>5}{e['coverage']:>7}  {e['band']}")
        prev = e
    comparable = [e for e in ledger if not e.get("scope_changed")]
    if len(ledger) > 1:
        span = round(ledger[-1]["composite"] - ledger[0]["composite"], 1)
        per = round(span / (len(ledger) - 1), 1)
        print(f"\n{len(ledger)} runs  |  total {'+' if span >= 0 else ''}{span} points  "
              f"|  {per} points per run")
    if len(comparable) != len(ledger):
        print("NOTE  runs marked 'scope!' changed the applicability context or the catalog. "
              "Their score is not directly comparable to the run before it.")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description="FINISHER scoring engine")
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp, need_state=True):
        sp.add_argument("--catalog", default=None,
                        help="path to checks.yaml (auto-resolved if omitted)")
        sp.add_argument("--dir", default="finisher")
        if need_state:
            sp.add_argument("--state", default=os.path.join("finisher", "state.json"))

    sp = sub.add_parser("init"); common(sp, need_state=False)
    sp.add_argument("--context"); sp.add_argument("--project")
    sp.add_argument("--allow-empty-context", action="store_true",
                    help="permit an all-false context (a genuinely static project)")
    sp.add_argument("-o", "--out", default=os.path.join("finisher", "state.json"))
    sp.set_defaults(func=cmd_init)

    sp = sub.add_parser("validate"); common(sp); sp.set_defaults(func=cmd_validate)

    sp = sub.add_parser("score"); common(sp)
    sp.add_argument("--json", action="store_true"); sp.set_defaults(func=cmd_score)

    sp = sub.add_parser("commit"); common(sp)
    sp.add_argument("--run-id", required=True)
    sp.add_argument("--actions")
    sp.add_argument("--commit-sha", default=None)
    sp.add_argument("--accept-catalog-drift", action="store_true",
                    help="commit even though the state predates the current catalog "
                         "(prefer `migrate`)")
    sp.add_argument("--force", action="store_true",
                    help="produce an UNOFFICIAL diagnostic report despite validation errors; "
                         "never writes SCORE.md or the authoritative ledger")
    sp.set_defaults(func=cmd_commit)

    sp = sub.add_parser("migrate"); common(sp); sp.set_defaults(func=cmd_migrate)

    sp = sub.add_parser("history"); common(sp, need_state=False)
    sp.set_defaults(func=cmd_history)

    args = p.parse_args(argv)
    try:
        return args.func(args)
    except FinisherError as e:
        print(f"ERROR {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
