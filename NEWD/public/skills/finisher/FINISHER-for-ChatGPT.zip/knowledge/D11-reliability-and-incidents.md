# Reliability, Backup and Incident Response

> Covers checks REL-01..07. Domain D11, weight 7.

The question this domain answers: **it is 2am, the app is down, what happens?** If the honest answer involves improvisation, the domain is not done regardless of how good the architecture is.

---

## 1. State the objectives, then check reality matches

**RTO** — how long you can be down. **RPO** — how much data you can lose.

Write both numbers first, from the business, then check the infrastructure actually supports them:

- Nightly backups mean an RPO of up to 24 hours. Decide that deliberately, or turn on point-in-time recovery.
- The measured restore time from your drill is your real RTO. Not the estimate. The measurement.
- A single-region deployment has an RTO bounded by that region's recovery, which is not under your control.

Where the numbers and the configuration disagree, either change the configuration or change the promise you are making to customers. Publishing a 99.9% uptime commitment on infrastructure with a six-hour restore is a contractual problem waiting to happen.

## 2. The runbook

Written when calm, for use when not. Every procedure needs the actual command, not a description of the command.

Minimum set:

| Scenario | Must answer |
|---|---|
| App is down | How do I confirm? What are the three most likely causes and their checks? |
| Database down or unreachable | Provider status, connection limits, failover procedure |
| Bad deploy | Exact rollback command, and what rollback does not undo |
| Restore from backup | Step by step, with the measured duration |
| Payment webhooks failing | How to detect, how to replay, how to reconcile |
| Provider outage | Which providers are critical, what degraded mode looks like, how to enable it |
| Runaway spend | How to see it, how to cut it off, which switch to flip |
| Secret leaked | Rotation order, what to revoke, what to check for abuse |
| Suspected data exposure | Contain, preserve evidence, assess scope, who decides on notification |
| Queue backed up | How to see depth, how to scale workers, how to drain safely |

Use `knowledge file X5-operational-templates.md section `RUNBOOK.md``. The test of a runbook is whether someone who did not write it can follow it. Have someone else try one procedure.

## 3. Who responds

Name the person, the notification path, and the expected response window. Then test the path end to end — send a real alert and confirm it produces a phone notification.

For a one-person or two-person team, "best effort during business hours, monitored overnight for total outage only" is a legitimate answer. **Write it down and set customer expectations to match.** The failure is not having limited coverage; it is having limited coverage that nobody agreed to.

Define severity levels so the response is proportionate:

- **Sev 1** — total outage, data loss, or active security incident. Drop everything, notify customers.
- **Sev 2** — major feature broken or significant degradation. Same-day.
- **Sev 3** — minor breakage with a workaround. Next business day.

## 4. Security and data incidents

These have clocks. Several regimes require notification of a personal-data breach to a supervisory authority within a defined window measured in hours, and sector rules and contracts add their own. **Verify the obligations that apply to you before you need them** — the plan cannot be written during the incident.

The sequence:

1. **Contain** — revoke credentials, disable the affected path, block the actor
2. **Preserve** — snapshot logs before rotation deletes them; do not destroy evidence while cleaning up
3. **Assess** — what data, whose, how much, over what period, exfiltrated or only accessible
4. **Decide on notification** — who makes the call, which counsel is contacted
5. **Notify** — regulators, customers, and any processors, in the required form and window
6. **Remediate and post-mortem**

Identify the decision-maker and the lawyer now, while it is a five-minute task.

## 5. Post-mortems

Blameless, and focused on the system rather than the person. Every user-visible incident gets one.

The four questions that produce useful actions:

- What happened, in a timeline with timestamps?
- What made **detection** slow?
- What made **recovery** slow?
- What would have prevented it, and what would have contained it?

Detection and recovery are separate questions and are usually where the real improvements are. Most incidents are not caused by an exotic failure; they are made expensive by finding out late and fixing slowly.

Action items need owners and dates, and they need to appear in the FINISHER state file as check score changes. Otherwise the post-mortem is a document rather than a change.

## 6. Telling customers

Silence during an outage costs more trust than the outage does. Decide in advance:

- The threshold for posting (any Sev 1, or any incident over N minutes)
- Where you post — a status page, in-app banner, or email
- Who writes it
- A template, so nobody is drafting prose under pressure

The template only needs: what is affected, what you are doing, when you will next update. Do not diagnose publicly in real time, and do not promise a fix time you cannot hold.

## 7. Dependency failure

Your availability is the product of your dependencies' availability unless you design otherwise. For each critical provider, decide and document:

- **Fail closed** — reject the request (correct for payments)
- **Fail open** — proceed without it (correct for analytics)
- **Queue** — accept and process later (correct for email)
- **Serve stale** — return cached data (correct for reads)

Then test it. Point the client at a black-hole endpoint and confirm the app behaves as designed rather than hanging or crashing. This is the cheapest form of chaos engineering and it finds the missing timeout every time.
