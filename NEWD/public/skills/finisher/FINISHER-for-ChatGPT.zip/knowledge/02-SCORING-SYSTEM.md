# The FINISHER Score

The score exists to answer one question honestly: **is this closer to shippable than it was last time, and by how much?**

Everything here is designed so that the same project state produces the same number regardless of who or what runs the assessment. A score you can argue with is a score you can move.

---

## 1. The three numbers

Every run produces three, and reporting fewer than three is a defect.

| Number | What it means | Where it comes from |
|---|---|---|
| **Pre-score** | The score at the start of this run | The previous ledger entry. Never entered by hand. |
| **Post-score** | The score after this run's work | Computed from the updated state file |
| **Delta + change log** | Which specific checks moved and what was done to move them | Diffed automatically; the "what was done" text comes from `actions.json` |

The first run has no pre-score. Say `n/a (first run)` — do not invent a baseline.

---

## 2. The measurement scale

Every check is scored 0–4. The scale is about **proof**, not effort.

| Score | Level | What it means | What is required to claim it |
|---:|---|---|---|
| 0 | **ABSENT** | Not present, or you looked and could not find it | Nothing |
| 1 | **CLAIMED** | Something exists. Nobody has demonstrated it works. | A pointer to where it supposedly lives |
| 2 | **IMPLEMENTED** | It works. You saw it work once. | `evidence`: a sentence describing what you observed |
| 3 | **VERIFIED** | Proven by something a stranger could re-run | `artifact`: a file path, test name, command output, screenshot, or URL |
| 4 | **ENFORCED** | Automated so it cannot silently regress | `enforcement`: the CI job, runtime policy, or alert that holds the line |

Three rules that make the scale mean something:

1. **You cannot score 2+ without evidence.** The validator rejects it.
2. **You cannot score 3+ without a named artifact.** "We tested it" is a 2. "`tests/authz.spec.ts::cross-tenant-read` passes" is a 3.
3. **You cannot score 4 without naming what enforces it.** A thing a human remembers to do is a 3 forever.

The gap between 3 and 4 is where most projects quietly rot. A verified control with no enforcement point degrades to absent within about two months of active development.

### The distinction that matters most

**2 is "it works." 3 is "it is proven to work." 4 is "it cannot stop working without someone noticing."**

AI-built codebases are unusually good at producing 1s and unusually bad at producing 4s. The whole point of this exercise is to move the P0 set to 3+ and the highest-risk controls to 4.

---

## 3. Priority tiers and the ceiling rule

| Tier | Meaning | Counts as closed at |
|---|---|---:|
| **P0** | Breach, data loss, outage, money loss, or legal exposure. Blocks any launch. | 3 |
| **P1** | Stability, trust, maintainability, support burden. Blocks paid or public launch. | 3 |
| **P2** | Scale, polish, efficiency, long-horizon risk. Blocks confident growth. | 2 |

**The ceiling rule is what makes the score honest.** Weighted averages let you offset a catastrophe with polish. This one does not.

```
any P0 open  ->  composite capped at 39   (DO NOT LAUNCH)
any P1 open  ->  composite capped at 69   (cannot exceed PAID BETA WITH FIXES)
any P2 open  ->  composite capped at 89   (cannot claim SCALE READY)
```

A project with beautiful observability, exhaustive tests, and one exposed API key scores 39. That is correct. The number should refuse to flatter you.

The scorecard always shows both figures: the **uncapped weighted score** (how much work is genuinely done) and the **capped composite** (what you are allowed to claim). Watching the uncapped number rise while the capped number sits at 39 is a useful, uncomfortable signal that you are polishing instead of unblocking.

---

## 4. Readiness bands

| Score | Band | What it licenses |
|---:|---|---|
| 0–39 | **DO NOT LAUNCH** | Internal use with fake data only |
| 40–59 | **PRIVATE BETA ONLY** | Invited users who know it is early, no sensitive data, no money |
| 60–74 | **PAID BETA WITH FIXES** | Real users and money, with disclosed limitations and a fix list |
| 75–89 | **PRODUCTION READY** | Public launch, support commitment, sleep at night |
| 90–100 | **SCALE READY** | Growth, enterprise conversations, on-call rotation |

Bands are permissions, not grades. 78 does not mean "B+". It means you may launch.

---

## 5. How the composite is computed

```
check_points(c)   = weight(c) x score(c)                  # score 0-4, weight 1-5
domain_score(d)   = 100 x sum(check_points) / sum(weight x 4)      # over applicable checks
raw_composite     = sum(domain_weight x domain_score) / sum(domain_weight)
composite         = min(raw_composite, tier_ceiling)
```

**Absent conditions include the check.** If an intake condition is missing from the context, every
check depending on it stays in scope and is flagged "assumed applicable." Excluding a check is the
fail-open direction — a silently dropped P0 is precisely the failure this program exists to prevent.
Only an explicit `false` narrows scope. The scorecard lists which conditions are being assumed.

**Applicability, not zeroes.** A check that does not apply — no payments, no mobile app, no AI — is excluded from both numerator and denominator. It is not scored 0. A static marketing site is not penalized for lacking tenant isolation.

Domain weights are also conditional. `D14 AI & Agent Safety` carries weight 6; if the project has no AI, the domain drops entirely and the remaining weights renormalize. There is no manual reweighting to do.

**Assessment coverage** is reported alongside the score:

```
coverage = assessed applicable checks / total applicable checks
```

A check counts as assessed when it scored above zero, **or when a zero is documented with
evidence**, or when `assessed: true` is set. A confirmed absence is an assessment — "I looked, there
are no backups" is real work and should count. A bare zero with nothing recorded is "did not look"
and correctly does not.

This is the single most important guard against a misleading score. A 45 with 96% coverage means
*we looked hard and it is rough*. A 45 with 30% coverage means *we barely looked*. Below 80%
coverage, the scorecard prints a warning and the number should not be quoted to anyone making a
decision.

---

## 6. The state file

`finisher/state.json` is the only place scores live. One entry per check:

```json
{
  "AUTHZ-01": {
    "score": 3,
    "evidence": "Ran the User A / User B script against staging. All 14 ID-substitution attempts returned 403 and were logged.",
    "artifact": "tests/security/authz.spec.ts::cross-user-object-access (14 cases, passing) + docs/evidence/2026-07-25-authz-run.txt",
    "enforcement": null,
    "notes": "Export endpoint was the one that failed initially; fixed in a1b2c3d."
  }
}
```

Fields:

- `score` — 0–4.
- `evidence` — what you observed. Required at 2+.
- `artifact` — what a stranger could re-run or open. Required at 3+.
- `enforcement` — the automation that prevents regression. Required at 4.
- `assessed` — explicit override that counts a check toward coverage even at score 0 with no
  evidence. Rarely the right tool; documenting the zero in `evidence` is better and more useful.
- `na` / `na_reason` — excludes the check. A reason is **mandatory**. Marking a check N/A that the
  intake context says applies is a validation **ERROR for P0 and P1** and a warning for P2. This is
  the main gaming vector, so it is deliberately hard: fix the context, do not hand-exclude a blocker.
- `notes` — anything a future reader needs.

---

## 7. The run loop

```bash
# once, at the start of the project
python3 finisher_score.py init --context finisher/context.json --project "myapp" \
  -o finisher/state.json

# every run, after doing the work and updating state.json
python3 finisher_score.py validate                      # anti-gaming gate
python3 finisher_score.py commit \
  --run-id 2026-07-25-r1 \
  --actions finisher/actions.json \
  --commit-sha $(git rev-parse --short HEAD)

python3 finisher_score.py history                       # the trend
```

`commit` writes three things:

| File | Purpose |
|---|---|
| `finisher/SCORE.md` | Current scorecard. Overwritten each run. This is the file you show people. |
| `finisher/runs/<run-id>.md` | This run's pre/post/delta and change log. Never overwritten. |
| `finisher/runs/<run-id>.state.json` | Snapshot of the exact state the run was scored from. Makes any historical run reproducible. |
| `finisher/ledger.jsonl` | Append-only history: one JSON line per run with every check score, the full applicability context, and context/catalog/state hashes. The audit trail. |
| `finisher/unofficial/` | Where `--force` runs go. Never mixed with the ledger. |

`commit` **refuses to run on an invalid state.** `--force` does not override that — it redirects.
A forced run produces a report named `<run-id>-UNOFFICIAL.md` in `finisher/unofficial/`, marked at
the top, recording the validation errors, and exits non-zero. It never writes `SCORE.md` and never
appends to `ledger.jsonl`. A diagnostic is useful; an unvalidated number in the audit trail is not.

**Run IDs must be unique.** A duplicate is rejected rather than silently overwriting a report while
appending a second ledger entry.

**Scope changes are detected, not averaged over.** Each entry carries the full context plus a
context hash, catalog hash, and state hash. If either the context or the catalog changed, the delta
is suppressed, the run is marked `scope!` in `history`, checks that became applicable are listed
separately rather than counted as regressions from zero, and checks that left scope are listed so
you can confirm it was deliberate.

### actions.json

The change log. Keys are check IDs; values describe what was actually done.

```json
{
  "summary": "Closed the two auth P0s and got backups verified. Cost controls next.",
  "actions": {
    "AUTHZ-01": "Moved ownership filtering into the repository layer so an unscoped query is unrepresentable; added 14 IDOR cases.",
    "DATA-02": "Restored the 2026-07-24 snapshot into a scratch project, booted the app against it, verified row counts. 11 minutes end to end — that is our real RTO.",
    "SEC-02": "gitleaks found a Stripe test key in commit 4f2a1c from March. Rotated at the provider even though it was test mode."
  }
}
```

Any action key that does not correspond to a score change is reported separately under **"Work done that did not move a score."** Do not delete those entries. Work that did not move the number is signal: either it was not finishing work, or the check needs evidence you have not captured yet, or you are working on something the catalog does not measure — and that last case means the catalog needs a check.

---

## 8. Reading the trend

`history` gives the trajectory:

```
run                       score   delta   P0   P1   cov%  band
2026-07-25-r1               3.1    +3.1   26   88    2.5  DO NOT LAUNCH
2026-07-26-r2              12.8    +9.7   19   88    18.9 DO NOT LAUNCH
2026-07-29-r3              31.0   +18.2    6   84    61.4 DO NOT LAUNCH
2026-08-02-r4              54.2   +23.2    0   71    88.1 PRIVATE BETA ONLY
```

What to read from it:

- **Early runs should mostly raise coverage, not score.** Run 1 is an audit; a big score jump in run 1 means someone scored from optimism rather than evidence.
- **The jump when the last P0 closes is the ceiling lifting**, not a sudden burst of quality. Expect it and do not over-celebrate it.
- **A flat score with high activity** means work is going into features, not finishing. That is a legitimate choice — but now it is visible.
- **Any negative delta must have an explanation in the run report.** An unexplained regression is itself a finding: something is being undone faster than it is being built, usually by an agent that does not know the constraint exists.

Two derived metrics worth watching:

- **Points per run** — your finishing velocity. Use it to estimate runs-to-band.
- **Regression rate** — checks that went down over the last five runs. Above ~5% of moved checks, your problem is not building controls, it is holding them. Push the highest-regression controls from 3 to 4.

---

## 9. Anti-gaming rules

The score is only useful if it is hard to fake. The validator enforces the mechanical rules; these are the judgement ones.

1. **Never score from the code alone when the check asks about runtime.** "The code calls `rateLimit()`" is a 1. Hitting the endpoint 200 times and seeing 429s is a 3.
2. **Never score a check higher because a related check is strong.** Backups configured (DATA-01) does not lift restore-tested (DATA-02). They are separate checks precisely because teams conflate them.
3. **N/A requires a reason, and the reason must be about the product, not the schedule.** "No payments in this product" is valid. "Not doing payments yet" means the check is in scope and scores 0.
4. **A check regresses when its evidence goes stale.** A restore drill from eight months ago is not a current 3. Downscore it, and let the regression show in the log.
5. **When uncertain between two scores, take the lower one.** The purpose is to find work, not to look finished.
6. **Level 4 is attested, not proven.** The scorer checks that you named an enforcement point; it
   cannot confirm the CI job exists or that it is still passing. Name it precisely enough that a
   reader can verify it in one click, and treat a vague enforcement string as a 3.
7. **Do not add checks to raise the denominator.** If you extend the catalog, add checks in the catalog file with weights and tiers, and note the catalog version bump in the run report so historical comparisons stay interpretable.

---

## 10. Extending the catalog

the catalog (`checks.yaml`; also knowledge file `X6-checks-catalog.md`) is the source of truth. To add a check:

```yaml
- id: ORG-01                 # unique, domain-prefixed
  domain: D06                # existing domain, or add one with a weight
  tier: P1                   # P0 / P1 / P2
  weight: 3                  # 1-5, relative to other checks in the domain
  when: [has_users, is_public]   # ANDed; `always` for universal; `!cond` to negate
  title: "One sentence, stated as the thing being true"
  risk: "What goes wrong if it is not true, ideally with a concrete failure"
  fix: "What to actually do"
  evidence: "What proves score 3"
  enforce: "What proves score 4"
```

Bump `meta.catalog_version` when you change scoring-relevant fields. The ledger records both the
version and a hash of the catalog file per run, so any change — versioned or not — flags the
comparison as a scope change rather than silently misleading you.

Run `python3 scripts/test_finisher_score.py` after editing the catalog. It checks structural
integrity, rejects duplicate IDs and unknown conditions, and fails if a declared condition is
referenced by no check.

Stack-specific and organization-specific checks belong here. A catalog that never grows is a catalog nobody is using.
