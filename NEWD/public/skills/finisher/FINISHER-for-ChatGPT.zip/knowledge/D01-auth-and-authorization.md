# Auth and Authorization

> Covers checks AUTH-01..12, AUTHZ-01..04. Domain D01, weight 12 — the heaviest domain in the catalog.

**Authentication proves who you are. Authorization decides what you may touch.** AI-generated applications get the first right and the second wrong with startling consistency. Broken Access Control leads the OWASP Top 10 in the 2025 edition, and Missing Authorization sits at #4 on the 2025 CWE Top 25.

The failure is structural, not careless. A model asked to "add a dashboard route" produces a handler that fetches by ID. Nothing in that request says "and check the caller owns it," and nothing in the resulting code reveals the omission. It works perfectly in a single-user demo.

---

## 1. Do not build authentication

Use a battle-tested provider or your framework's first-party auth. The list of things you have to get exactly right — password hashing parameters, timing-safe comparison, session fixation, reset token entropy and single-use semantics, enumeration resistance, credential-stuffing defense — has no partial credit.

Reasonable choices in 2026: Clerk, Auth0, WorkOS, Supabase Auth, Firebase Auth, Cognito, Better Auth, Auth.js/NextAuth with a vetted adapter, Devise, Django's auth, Rails' `has_secure_password`.

If custom auth already exists in the codebase, that is a P0 finding. Migrating is usually a day of work and removes an entire category of risk permanently.

## 2. The authorization pattern that actually holds

Controller-level checks rot. Someone adds an endpoint, forgets the guard, and there is no signal. Push the constraint down until an unscoped query is **unrepresentable**:

```ts
// Fragile: the check is a line of code someone can forget
const doc = await db.document.findUnique({ where: { id } });
if (doc.ownerId !== session.userId) throw forbidden();

// Better: scoping is part of how you ask for data
const doc = await forUser(session).document.findUnique({ where: { id } });

// Best: the database refuses regardless of what the application asks
// Postgres RLS: policy USING (tenant_id = current_setting('app.tenant_id')::uuid)
```

Three layers, in ascending order of durability:

1. **Route middleware** — is there a session at all
2. **Data-access scoping** — every query carries the actor's identity
3. **Database policy (RLS or per-tenant schema)** — the backstop that survives an application bug

For multi-tenant products, layer 3 is not optional. One missing `WHERE tenant_id = ?` is a full customer-data breach, and that is a single-token mistake an AI makes routinely.

### Row-level security, concretely

```sql
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents FORCE ROW LEVEL SECURITY;   -- applies to the table owner too

CREATE POLICY tenant_isolation ON documents
  USING (tenant_id = current_setting('app.current_tenant', true)::uuid)
  WITH CHECK (tenant_id = current_setting('app.current_tenant', true)::uuid);
```

Three traps: `USING` alone protects reads but not writes — you need `WITH CHECK` too; policies do not apply to the table owner unless you `FORCE`; and a connection pooler can leak `current_setting` between requests unless you set it inside the transaction. Test all three.

A CI test worth having:

```sql
-- fails if any table with a tenant_id column lacks RLS
SELECT c.relname FROM pg_class c
JOIN pg_attribute a ON a.attrelid = c.oid AND a.attname = 'tenant_id'
WHERE c.relkind = 'r' AND NOT c.relrowsecurity;
```

## 3. The route inventory

You cannot secure what you have not enumerated. Build this table and keep it current; it is the artifact that lifts AUTH-02 to level 3.

| Method | Path | Public? | Authn | Authz rule | Rate limited | Test |
|---|---|---|---|---|---|---|
| GET | /api/documents/:id | no | session | owner or org member with `doc:read` | yes | `authz.spec.ts::doc-read` |
| POST | /api/admin/users | no | session | role=admin, MFA required | yes | `admin.spec.ts::create-user` |
| GET | /api/health | yes | none | none | yes | `health.spec.ts` |

Generate it from the router where you can. The valuable column is **Authz rule** — writing it forces you to notice the endpoints where you cannot state one.

## 4. Sessions and tokens

- **Regenerate the session identifier immediately after login and after any privilege change.** Skipping this is session fixation.
- **Logout must invalidate server-side.** Deleting a client cookie while the token stays valid is theatre. Test by capturing a token, logging out, and replaying it.
- **Cookies:** `Secure; HttpOnly; SameSite=Lax` at minimum, `Strict` where the UX allows. Use the `__Host-` prefix (which requires `Secure`, `Path=/`, and no `Domain` attribute) for the strongest binding.
- **Idle and absolute timeouts, both enforced server-side.** A client-side timer is a UX feature, not a control.
- **JWTs:** pin the expected algorithm at verification — `alg: none` and algorithm-confusion attacks persist because libraries trust the token's own header. Keep access tokens short-lived with rotating refresh tokens, or use server-side sessions. Remember JWTs have no native revocation: if you need instant logout, you need a server-side lookup or a denylist.
- **Never put a token in a URL.** It lands in logs, referrer headers, and browser history.

## 5. Password reset — the most-broken flow in AI-generated code

Requirements, all of which are commonly missing:

- Cryptographically random token, **hashed at rest** (a leaked database should not yield working reset links)
- Expires in 15–60 minutes
- **Single use** — invalidated the moment it is consumed
- Invalidated when the password changes by any other route
- **All existing sessions invalidated** on password change
- Response is identical whether or not the account exists (enumeration)
- Rate limited per account and per IP

Test every one of these. The reuse test — click the same reset link twice — catches the most common defect in about fifteen seconds.

## 6. Rate limiting the auth surface

Lock on **account identity**, not IP alone; attackers rotate IPs and a shared corporate NAT means IP locking punishes innocents. Combine per-identity throttling with per-IP limits, add exponential backoff, and keep error text generic. Add a breached-password check at registration and at password change — credential stuffing is the actual attack, and blocking known-compromised passwords defeats most of it.

## 7. Admin surfaces

Treat admin as a separate application that happens to share a database:

- Separate middleware with its own test suite
- Role verified server-side on every request, never from a client-supplied claim
- MFA mandatory
- Consider a separate hostname, IP allowlist, or SSO requirement
- Every admin action written to an append-only audit log with actor, target, before/after, and request ID

The audit log is what turns "we think nobody misused it" into an answer.

## 8. What to actually test

Run the full script in knowledge file `X1-manual-test-scripts.md`, then automate it. The automated version is the highest-value test suite in an AI-built codebase:

```ts
// The shape that matters: enumerate endpoints, enumerate actors, assert rejection
for (const ep of PROTECTED_ENDPOINTS) {
  for (const actor of [anonymous, otherUser, otherTenant, lowerRole]) {
    it(`${ep.method} ${ep.path} rejects ${actor.name}`, async () => {
      const res = await call(ep, actor);
      expect([401, 403, 404]).toContain(res.status);
      expect(res.body).not.toMatchObject({ id: ep.fixtureId });  // no partial leak
    });
  }
}
```

Make the endpoint list derive from the router, not a hand-maintained array. Then adding an unprotected route fails the build — which is what moves AUTH-02 and TEST-01 from 3 to 4.

## 9. Common findings, in the order you will find them

1. API route protected in the UI but open at the JSON endpoint
2. Ownership checked on read, forgotten on update, delete, or export
3. Tenant filter present in the list query, absent in the detail query
4. Admin flag read from a client-supplied JWT claim the client can edit
5. Reset token that never expires or works more than once
6. Logout that only clears the cookie
7. Bulk or export endpoints that skip the scoping the single-record endpoint applies
8. A "public" share link that grants more than the sharer had
9. Webhook and callback endpoints with no authentication at all
10. GraphQL resolvers or ORM includes that traverse to unauthorized related records
