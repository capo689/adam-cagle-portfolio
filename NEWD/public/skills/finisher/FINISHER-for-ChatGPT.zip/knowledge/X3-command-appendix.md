# Command Appendix

Copy-paste starting points. **Verify current flags and versions against each tool's documentation** — this appendix will drift, and the surrounding files tell you what to accomplish, not which flag spelling is current this month.

Never run a destructive command without a confirmed backup.

---

## Reconnaissance

```bash
ls -la; cat README* 2>/dev/null | head -60
cat package.json requirements.txt pyproject.toml go.mod Gemfile 2>/dev/null

# env var names only, never values
grep -rhoE "(process\.env\.|import\.meta\.env\.|os\.environ)[A-Za-z_\[\"']*[A-Z_][A-Z0-9_]*" . 2>/dev/null \
  | grep -oE "[A-Z_][A-Z0-9_]{2,}$" | sort -u

# vendors
grep -rEl "stripe|paddle|openai|anthropic|gemini|supabase|firebase|clerk|auth0|twilio|sendgrid|resend|s3|cloudinary" \
  --include="*.{ts,tsx,js,jsx,py,go,rb}" . 2>/dev/null | head -40

# surface
ls .github/workflows/ migrations/ prisma/migrations/ supabase/migrations/ 2>/dev/null
git log --oneline | head -20
git log --format='%an' | sort | uniq -c | sort -rn
```

## Secrets

```bash
gitleaks git -v .
gitleaks dir --redact --report-format sarif --report-path gitleaks.sarif .
trufflehog git file://. --results=verified
trufflehog filesystem . --results=verified,unknown

git log --all --full-history -- .env .env.local .env.production
find . -name "*.env*" -not -path "*/node_modules/*"

# client bundle
npm run build && grep -rohE "(sk_live_|sk_test_|ghp_|github_pat_|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_-]{35}|xox[baprs]-)" \
  dist/ build/ .next/static/ .output/ 2>/dev/null | sort -u
```

Pre-commit:

```yaml
repos:
  - repo: https://github.com/gitleaks/gitleaks
    rev: <current tag>
    hooks: [{ id: gitleaks }]
```

## Dependencies and supply chain

```bash
npm ci --ignore-scripts
npm audit --audit-level=high --omit=dev
npm audit signatures --include-attestations
npm outdated

trivy fs --scanners vuln,secret,misconfig .
osv-scanner scan source -r .
grype dir:.

syft . -o cyclonedx-json=sbom.cdx.json
npm sbom --sbom-format cyclonedx > sbom.cdx.json
```

Cooldown configuration:

```ini
# .npmrc — units are days
min-release-age=3
```
```yaml
# pnpm-workspace.yaml — units are minutes
minimumReleaseAge: 4320
minimumReleaseAgeStrict: true
```

## Static and dynamic analysis

```bash
semgrep scan --config auto .
semgrep scan --config auto --error .                 # exit non-zero on findings
semgrep scan --config auto --baseline-commit=origin/main   # diff-scoped

docker run -e GITHUB_AUTH_TOKEN=$TOKEN ghcr.io/ossf/scorecard:stable \
  --show-details --repo=https://github.com/ORG/REPO

docker run -t ghcr.io/zaproxy/zaproxy:stable zap-baseline.py -t https://staging.example.com
docker run -t ghcr.io/zaproxy/zaproxy:stable zap-api-scan.py -t https://staging.example.com/openapi.json -f openapi
```

## Headers and TLS

```bash
curl -sI https://yourapp.com | sed -n '1,40p'
curl -sI https://yourapp.com | grep -iE "strict-transport|content-security|x-content-type|referrer|permissions-policy|x-frame"
echo | openssl s_client -connect yourapp.com:443 -servername yourapp.com 2>/dev/null | openssl x509 -noout -dates
```

## Database

```sql
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

SELECT calls, round(mean_exec_time::numeric,2) AS avg_ms,
       round(total_exec_time::numeric) AS total_ms, query
FROM pg_stat_statements ORDER BY total_exec_time DESC LIMIT 20;

SELECT relname, indexrelname, idx_scan FROM pg_stat_user_indexes
WHERE idx_scan = 0 ORDER BY relname;

SELECT schemaname, relname, n_live_tup FROM pg_stat_user_tables
ORDER BY n_live_tup DESC LIMIT 20;

-- tables with a tenant column but no RLS
SELECT c.relname FROM pg_class c
JOIN pg_attribute a ON a.attrelid = c.oid AND a.attname IN ('tenant_id','org_id','account_id')
WHERE c.relkind = 'r' AND NOT c.relrowsecurity;

SHOW max_connections;
SELECT count(*), state FROM pg_stat_activity GROUP BY state;
```

Migration linting:

```bash
npx squawk migrations/*.sql
atlas migrate lint --dev-url "docker://postgres/16/dev" --latest 10
```

## Testing

```bash
npx playwright test
npx playwright test --grep @smoke
npx playwright test --shard=1/4
npx playwright show-trace trace.zip

uvx schemathesis run https://staging.example.com/openapi.json
npx stryker run --mutate "src/{auth,billing}/**/*.ts"
oasdiff breaking old.yaml new.yaml
```

Accessibility in Playwright:

```ts
import AxeBuilder from '@axe-core/playwright';
const r = await new AxeBuilder({ page })
  .withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa']).analyze();
expect(r.violations).toEqual([]);
```

## Load testing

```bash
k6 run --env BASE_URL=https://staging.example.com load-test.js
k6 run --vus 50 --duration 5m load-test.js
artillery run artillery.yml
```

## FINISHER itself

```bash
python3 finisher_score.py init --context finisher/context.json --project "myapp" -o finisher/state.json
python3 finisher_score.py validate
python3 finisher_score.py score
python3 finisher_score.py score --json | jq '.open.P0'
python3 finisher_score.py commit --run-id $(date +%Y-%m-%d)-r1 \
  --actions finisher/actions.json --commit-sha $(git rev-parse --short HEAD)
python3 finisher_score.py history
```
